# Check-list — PHP + MySQL backend

Firebase (Auth + Firestore + Hosting) has been replaced by a small PHP API in `api/` and a MySQL database.
The pages and UI are unchanged; they now talk to `/api/...` through `js/api.js`.

## Requirements
PHP 8.1+ (with `pdo_mysql`, `mbstring`), MySQL 5.7+/MariaDB 10.3+, Apache with `mod_rewrite` (or nginx, see below). HTTPS strongly recommended.

## Install (easiest: web installer)
1. Upload the whole folder to your web root (or a sub-folder). Make sure `api/` is writable by PHP during setup.
2. Create an empty MySQL database and a user for it (cPanel / phpMyAdmin / your host's panel).
3. Open `https://your-site/install.php` in the browser:
   - **Step 1:** enter the database host, name, user and password. It tests the connection, writes `api/config.php` and creates all tables.
   - **Step 2:** enter your name, email and password. This creates the first **admin**.
4. The installer deletes itself when it finishes (if it can't, **delete `install.php` yourself**). It also refuses to run once any account exists.
5. Sign in at `login.html`, then add controllers from the **Users** page (passwords: 8 characters minimum).

### Manual install (no browser)
`mysql -u USER -p DBNAME < database/schema.mysql.sql`, then `cp api/config.sample.php api/config.php` and edit it, then
`php tools/create_admin.php "Your Name" you@example.com 'a-long-password' admin`

Local test without Apache: `php -S localhost:8000 -t . tools/dev-router.php`

## nginx
```
location /api/ { try_files $uri /api/index.php?route=$uri; }   # adapt: route = path after /api/
location ~ ^/(database|tools)/ { deny all; }
location = /api/config.php { deny all; }
```
(`route` must receive the path *after* `/api/`, e.g. `rewrite ^/api/(.*)$ /api/index.php?route=$1 last;`)

## How it maps from Firebase
| Firebase | Now |
|---|---|
| Auth (email + password) | `users` table, `password_hash()`, own session store in the `sessions` table (HttpOnly cookie, SameSite=Lax; "Remember me" = 30 days). If a host/browser refuses cookies, the login page automatically falls back to sending the same session id in an `X-Auth-Token` header |
| Firestore rules | enforced in `api/index.php` (`require_role`), same permissions |
| `flights`, `recaps`, `auditLogs`, `shiftPlans`, `planning` | tables `flights`, `recaps`, `audit_logs`, `shift_plans`, `planning` |
| client-side audit log writes | written by the server in the same transaction as the save |
| `firebase.json`, `firestore.rules`, `firebase-config.js` | removed |

Security notes: login is throttled (8 failures / 15 min per IP+email); state-changing calls require the `X-Requested-With: fetch` header (CSRF defence); the server recomputes `status` and rejects non-AT flights; a controller save can only touch `controller` data, admins cannot edit it (same as the old rules).

## Moving existing data
Passwords cannot be copied out of Firebase Auth, so recreate users (Users page) and let them choose passwords.
Flights/recaps/planning would need a one-off Firestore export + import script — not included.

## Upload limits
Importing a big Récap sends one JSON request. If it fails with 413/500, raise `post_max_size` / `memory_limit` in php.ini.

## Troubleshooting login
If login says "La session n'a pas pu être enregistrée", the message ends with a `[diagnostic : …]` line
(API version, cookie received, session found on server, https). `GET /api/auth/diag` returns the same information.
Changing a password signs the account out on every other device.

## Plans de chargement & fiches techniques (PDF)

Admin → « Plans & fiches » (`admin/loading-plans.html`) has two upload zones:

- **Plan de chargement** — one PDF per aircraft type (`788.pdf`, `73H.pdf`…), matched to the flight's Type A/C.
  For a flight whose category is *Moyen courrier*, the `M` variant (`788M.pdf`, `786M.pdf`, `787M.pdf`, `789M.pdf`…) is used
  instead when uploaded (falls back to the regular plan otherwise). Long-courrier flights never get an `M` plan.
- **Fiche technique** — one PDF per code prestation (`DC25.pdf`, `BC55.pdf`, `CF99.pdf`, `DC99.pdf`…). In a flight, each
  PEQ / C/CL / Y/CL block shows a « Fiche technique » button for every code presta of that block that has an uploaded PDF
  (exact code match). Stored in the `tech_sheets` table (created automatically on first use).
