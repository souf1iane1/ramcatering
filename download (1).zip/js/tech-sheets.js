// « Fiche technique » — one PDF per code prestation, uploaded by an admin and named after the code:
// BC55.pdf, DC25.pdf, BC25.pdf, CF99.pdf, DC99.pdf, or any other code. A controller opening a flight gets,
// in each of the PEQ / C/CL / Y/CL blocks, a button for every code presta of that block that has an
// uploaded fiche — no extra typing. Matching is on the exact code (a fiche for DC25 is never offered for
// DC21: they are different prestations). The server only stores/serves PDFs by exact code.
import { normPlanCode } from "./loading-plans.js";

export { normPlanCode as normTechCode, planCodeFromFileName as techCodeFromFileName, isValidPlanCode as isValidTechCode, MAX_PLAN_BYTES } from "./loading-plans.js";

/** Splits a block's code presta ("DC25, CF27" / array of codes) into normalized unique codes. */
export function splitPrestaCodes(codes) {
  const list = Array.isArray(codes) ? codes : String(codes ?? "").split(/[,;\s/]+/);
  return [...new Set(list.map(normPlanCode).filter(Boolean))];
}

/** The uploaded fiches that apply to a block: `codes` = the block's code(s) presta, `available` = the list
 *  returned by GET tech-sheets (strings or {type}). Returns the matching codes in the block's own order. */
export function matchTechSheets(codes, available) {
  if (!available?.length) return [];
  const have = new Set(available.map((t) => normPlanCode(typeof t === "string" ? t : t?.type)).filter(Boolean));
  return splitPrestaCodes(codes).filter((c) => have.has(c));
}

/** Fiches to offer for a block, following its Récap cycle (see checklist-rules.js: cycleInfo): one entry per
 *  uploaded code, in aller → retour → no-cycle order, with the legs it applies to.
 *  A code used on both legs yields a single entry (legs ["aller","retour"]); a block whose aller and retour
 *  codes differ yields one entry per leg (e.g. DC25 → ["aller"], CF99 → ["retour"]).
 *  `legCount` = how many legs the block has, so the UI knows when a leg tag is needed. */
export function matchTechSheetsByCycle(info, available) {
  if (!info || !available?.length) return { entries: [], legCount: 0 };
  const have = new Set(available.map((t) => normPlanCode(typeof t === "string" ? t : t?.type)).filter(Boolean));
  const entries = [];
  const put = (code, leg) => {
    const c = normPlanCode(code);
    if (!have.has(c)) return;
    let e = entries.find((x) => x.code === c);
    if (!e) entries.push((e = { code: c, legs: [] }));
    if (leg && !e.legs.includes(leg)) e.legs.push(leg);
  };
  info.aller.codes.forEach((c) => put(c, "aller"));
  info.retour.codes.forEach((c) => put(c, "retour"));
  info.other.forEach((c) => put(c, null));
  const legCount = (info.aller.codes.length ? 1 : 0) + (info.retour.codes.length ? 1 : 0);
  return { entries, legCount };
}
