// Checklist model + auto-detection rules for PEQ, C/CL and Y/CL.
// Pure logic (no DOM) so it can be tested on its own. flight-detail.js renders what this describes.
//
// Value conventions stored in controller.checklist[key]:
//   tick items  -> "OK" (✔) or "NON" (❌)       (legacy "-" is read as ❌)
//   count items -> a number
//   text items  -> free text (numbers and/or words, e.g. "12" or "2 chariots")
//
// Item fields:
//   id        base key (slot keys are built from it, see slotsOf)
//   kind      "tick" | "count" | "text"
//   noServices true = one single field even on long courrier (no 1er/2e service split)
//   legs      true  = one slot per leg (Aller / Retour when the flight has a return leg)
//   only      "long" | "short"  = item exists only on long-courrier / only on court+moyen
//   auto      (ctx, leg) => "OK" | "NON" | number | undefined   (undefined = nothing detected → left blank)
//   group     small integer, used to draw the group's "Auto" button (PEQ)

const SPECIAL_MEAL_RE = /^[A-Z]{2,4}ML(?=[_\s]|$)/i;
const up = (s) => String(s ?? "").toUpperCase();
const isNum = (v) => v !== null && v !== undefined && v !== "" && Number.isFinite(Number(v));
const TICK = (b) => (b === undefined || b === null ? undefined : b ? "OK" : "NON");

/** Is `dateStr` (YYYY-MM-DD) in Ramadan (Hijri month 9)? null when the runtime can't tell.
 *  Uses the Umm al-Qura calendar: Morocco's moon sighting can differ by ±1 day at the edges. */
export function isRamadan(dateStr) {
  const m = String(dateStr || "").match(/^(\d{4})-(\d{2})-(\d{2})$/);
  if (!m) return null;
  try {
    const d = new Date(Date.UTC(+m[1], +m[2] - 1, +m[3], 12));
    const month = new Intl.DateTimeFormat("en-u-ca-islamic-umalqura", { month: "numeric", timeZone: "UTC" }).format(d);
    const n = parseInt(month, 10);
    return Number.isFinite(n) ? n === 9 : null;
  } catch { return null; }
}

/** Main (non special-meal) prestation codes of a cabin block, optionally for one leg. */
export function codesFor(block, leg = null) {
  const raw = Array.isArray(block?.raw) ? block.raw : [];
  const main = raw.filter((it) => it.code && !SPECIAL_MEAL_RE.test(it.code));
  let list = main;
  if (leg && main.some((it) => it.cycle)) {
    const key = leg === "aller" ? "go" : "back";
    list = main.filter((it) => String(it.cycle || "").includes(key));
  }
  const codes = list.map((it) => up(it.code));
  if (!raw.length && block?.codePrestation) {
    return [...new Set(up(block.codePrestation).split(/[,\s]+/).filter(Boolean))];
  }
  return [...new Set(codes)];
}

/** Récap cycle of a cabin block, per leg. The Récap writes one cycle token per prestation line ("1go" = aller,
 *  "1back" = retour). Returns { aller:{cycles,codes}, retour:{cycles,codes}, other:[codes], hasCycle }:
 *  `cycles` = distinct tokens of that leg (e.g. ["1go"]), `codes` = its main (non special-meal) prestation codes,
 *  `other` = codes whose line carries no cycle (then they apply to the flight as a whole). */
export function cycleInfo(block) {
  const info = { aller: { cycles: [], codes: [] }, retour: { cycles: [], codes: [] }, other: [], hasCycle: false };
  const raw = Array.isArray(block?.raw) ? block.raw : [];
  const add = (arr, v) => { if (v && !arr.includes(v)) arr.push(v); };
  for (const it of raw) {
    if (!it.code || SPECIAL_MEAL_RE.test(it.code)) continue;
    const cyc = String(it.cycle || "").toLowerCase().trim();
    const code = up(it.code);
    const go = cyc.includes("go"), back = cyc.includes("back");
    if (go) { add(info.aller.cycles, cyc); add(info.aller.codes, code); }
    if (back) { add(info.retour.cycles, cyc); add(info.retour.codes, code); }
    if (!go && !back) add(info.other, code);
  }
  if (!raw.length) for (const c of codesFor(block)) add(info.other, c); // old data without raw lines
  info.hasCycle = info.aller.codes.length > 0 || info.retour.codes.length > 0;
  return info;
}

/** Highest recap count among items whose code matches `re` (for one leg); null if none. */
export function rawCount(block, re, leg = "aller") {
  const key = leg === "aller" ? "go" : "back";
  let best = null;
  for (const it of Array.isArray(block?.raw) ? block.raw : []) {
    if (!it.code || !re.test(up(it.code))) continue;
    if (it.cycle && !String(it.cycle).includes(key)) continue;
    if (isNum(it.count)) best = Math.max(best ?? 0, Number(it.count));
  }
  return best;
}

function specialTotal(block, leg = "aller") {
  const list = block?.specialMeals || [];
  if (!list.length) return null;
  const k = leg === "retour" ? "retourPrevu" : "allerPrevu";
  const total = list.reduce((s, x) => s + (Number(x[k]) || 0), 0);
  return total || null;
}

/** Context for the auto rules. `live` may carry pax réel read from the screen:
 *  { cclAller, cclRetour, yclAller, yclRetour } where
 *    a number  = the controller typed a PAX réel (used instead of the Récap figure),
 *    null      = the field is on screen but empty (falls back to the Récap, ignoring any older saved value),
 *    undefined = not provided (the saved PAX réel, if any, is used). */
export function makeCtx(f, live = {}) {
  const imp = f.imported || {};
  const ctrl = f.controller || {};
  const paxReelKeys = { ccl: { aller: "paxAllerReelCcl", retour: "paxRetourReelCcl" }, ycl: { aller: "paxAllerReel", retour: "paxRetourReel" } };
  const block = { ccl: imp.cCl, ycl: imp.yCl };
  return {
    f, imp,
    codes: (cab, leg) => codesFor(imp[cab], leg),
    rawCount: (cab, re, leg) => rawCount(imp[cab], re, leg),
    specialCodes: (cab) => (imp[cab]?.specialMeals || []).map((s) => up(s.code)),
    specialTotal: (cab, leg) => specialTotal(imp[cab], leg),
    recapPax: (cab, leg) => { const v = block[cab]?.[leg === "retour" ? "paxRetourPrevu" : "paxAllerPrevu"]; return isNum(v) ? Number(v) : null; },
    /** PAX réel only (typed, else saved); null when the controller hasn't entered one. */
    reel: (cab, leg = "aller") => {
      const typed = live?.[`${cab}${leg === "retour" ? "Retour" : "Aller"}`];
      if (typed !== undefined) return isNum(typed) ? Number(typed) : null;
      const saved = ctrl[paxReelKeys[cab][leg]];
      return isNum(saved) ? Number(saved) : null;
    },
    /** The PAX every auto rule uses: PAX réel when entered (e.g. 18), otherwise the Récap prévu (e.g. 15). */
    pax: (cab, leg = "aller") => {
      const typed = live?.[`${cab}${leg === "retour" ? "Retour" : "Aller"}`];
      const reel = typed !== undefined ? (isNum(typed) ? Number(typed) : null) : (isNum(ctrl[paxReelKeys[cab][leg]]) ? Number(ctrl[paxReelKeys[cab][leg]]) : null);
      if (reel !== null) return reel;
      const prevu = block[cab]?.[leg === "retour" ? "paxRetourPrevu" : "paxAllerPrevu"];
      return isNum(prevu) ? Number(prevu) : null;
    },
    ramadan: isRamadan(f.date),
  };
}

const has = (codes, re) => codes.some((c) => re.test(c));
const paxCount = (x, cab, leg) => { const n = x.pax(cab, leg); return n === null ? undefined : n; };

// ------------------------------------------------------------------ item definitions
export const SECTIONS = [
  {
    id: "peq", title: "PEQ", services: true, // long courrier: every item gets 1er + 2e service
    items: [
      { id: "plateauxFruits", label: "Plateau fruits", kind: "tick", group: 1 }, // manual ✔/❌
      { id: "repasChaudsDcCc", label: "Repas chaud DC/CC/BC", kind: "tick", legs: true, group: 1,
        auto: (x, leg) => TICK(has(x.codes("peq", leg), /^(DC|CC|BC)/)) },
      { id: "repasFroid", label: "Repas froid CF", kind: "tick", legs: true, group: 2,
        auto: (x, leg) => TICK(has(x.codes("peq", leg), /^CF/)) },
      { id: "fruitsSec", label: "Fruits secs (BC)", kind: "tick", legs: true, group: 2,
        auto: (x, leg) => { const c = x.codes("peq", leg); return TICK(has(c, /^BC/) && !has(c, /^CF/)); } },
      { id: "barresChocolats", label: "Barres chocolat (CF)", kind: "tick", legs: true, group: 2,
        auto: (x, leg) => { const c = x.codes("peq", leg); return TICK(has(c, /^CF/) && !has(c, /^BC/)); } },
      { id: "dotationFtour", label: "Dotation Ftour (Ramadan)", kind: "tick", legs: true, group: 2,
        auto: (x) => TICK(x.ramadan) },
      { id: "saucesPeq", label: "Sauces PEQ", kind: "tick", group: 3 },
      { id: "painPeq", label: "Pain", kind: "tick", group: 3 },
    ],
  },
  {
    id: "ccl", title: "C/CL", services: false,
    items: [
      // ---- court + moyen courrier
      { id: "nombrePlateaux", label: "Nombre de plateaux", kind: "count", only: "short",
        auto: (x) => x.pax("ccl", "aller") ?? undefined }, // Récap figure, or the PAX réel once entered
      { id: "cartesMenu", label: "Cartes menu", kind: "tick", only: "short",
        auto: (x) => TICK(has(x.codes("cCl"), /DC25|DC21|CC27/)) },
      { id: "mentheCitron", label: "Menthe/Citron", kind: "tick", legs: true, only: "short",
        auto: (x, leg) => TICK((x.pax("ccl", leg) ?? 0) >= 1) },
      { id: "citronnade", label: "Citronnade", kind: "tick", only: "short",
        auto: (x) => TICK((x.pax("ccl") ?? 0) >= 1) },
      { id: "poml", label: "POML", kind: "tick", only: "short",
        auto: (x) => TICK(x.specialCodes("cCl").some((c) => /^POML/.test(c))) },
      { id: "plateauFromage", label: "Plateau fromage", kind: "tick", only: "short",
        auto: (x) => TICK(has(x.codes("cCl"), /DC25|DC21/) && (x.pax("ccl") ?? 0) >= 1) },
      { id: "painCcl", label: "Pain", kind: "tick", only: "short" },
      // ---- long courrier only
      { id: "canape", label: "Canapé", kind: "count", only: "long", auto: (x) => paxCount(x, "ccl", "aller") },
      { id: "fruitsIndividuels", label: "Fruits individuels", kind: "count", only: "long", auto: (x) => paxCount(x, "ccl", "aller") },
      { id: "soupe", label: "Soupe", kind: "tick", only: "long" },
      { id: "platSnackFT", label: "Plat snack F.T (SNC)", kind: "count", only: "long",
        auto: (x) => (has(x.codes("cCl"), /SNC/) ? paxCount(x, "ccl", "aller") : undefined) },
      { id: "hotMealSnc", label: "Hot Meal SNC", kind: "count", only: "long",
        auto: (x) => { const n = x.rawCount("cCl", /SNC/, "aller"); return n === null ? undefined : (x.reel("ccl", "aller") ?? n); } },
      { id: "hotMealBcc", label: "Hot Meal BCC", kind: "count", only: "long",
        auto: (x) => { const n = x.rawCount("cCl", /BCC/, "aller"); return n === null ? undefined : (x.reel("ccl", "aller") ?? n); } },
      { id: "vienoiserie", label: "Viennoiserie", kind: "tick", only: "long" },
      { id: "patisserie", label: "Pâtisserie", kind: "count", only: "long", auto: (x) => paxCount(x, "ccl", "aller") },
      { id: "spmlCcl", label: "SPML", kind: "tick", only: "long",
        auto: (x) => TICK(x.specialCodes("cCl").length > 0) },
      { id: "nombrePlateauxLong", label: "Nombre de plateaux", kind: "count", only: "long",
        auto: (x) => paxCount(x, "ccl", "aller") },
      { id: "cartesMenuLong", label: "Cartes menu", kind: "tick", only: "long" },
      { id: "fromageLong", label: "Fromage", kind: "tick", only: "long",
        auto: (x) => TICK((x.pax("ccl") ?? 0) >= 1) },
      { id: "citronnadeLong", label: "Citronnade", kind: "tick", only: "long",
        auto: (x) => TICK((x.pax("ccl") ?? 0) >= 1) },
      // ---- every category
      { id: "echangeStandardCcl", label: "Échange standard", kind: "text", noServices: true },
    ],
  },
  {
    id: "ycl", title: "Y/CL", services: true,
    items: [
      { id: "plateauxRepasDcBox", label: "Plateaux repas DC/Box", kind: "count", auto: (x) => paxCount(x, "ycl", "aller") },
      { id: "hotMeal", label: "Hot meal", kind: "count", legs: true, auto: (x, leg) => paxCount(x, "ycl", leg) },
      { id: "spmlYcl", label: "SPML Y/C", kind: "count", auto: (x) => x.specialTotal("yCl", "aller") ?? undefined },
      { id: "glaciere", label: "Glacière", kind: "tick" },
      { id: "painSupplementaire", label: "Pain supplémentaire", kind: "tick" },
      { id: "echangeStandardYcl", label: "Échange standard", kind: "text", noServices: true },
    ],
  },
];

const LEG_LABEL = { aller: "Aller", retour: "Retour" };
const cap = (leg) => (leg === "retour" ? "Retour" : "Aller");

/** Which sections / items apply to this flight, with their slots (leg × service). */
export function buildModel(f, hasRetour) {
  const isLong = f.aircraftCategory === "LONG_COURRIER";
  const legs = hasRetour ? ["aller", "retour"] : ["aller"];
  const sections = SECTIONS.map((s) => {
    const items = s.items
      .filter((it) => !it.only || (it.only === "long") === isLong)
      .map((it) => {
        const slots = [];
        for (const leg of it.legs ? legs : [null]) {
          for (const svc of isLong && s.services && !it.noServices ? [1, 2] : [null]) {
            slots.push({
              key: it.id + (leg ? cap(leg) : "") + (svc ? `S${svc}` : ""),
              label: it.label + (leg ? ` — ${LEG_LABEL[leg]}` : "") + (svc ? ` — ${svc === 1 ? "1er" : "2e"} service` : ""),
              leg, svc,
            });
          }
        }
        return { ...it, slots };
      });
    return { id: s.id, title: s.title, items };
  });
  return { isLong, hasRetour, sections };
}

/** Auto value for one slot (undefined when the item has no rule or nothing was detected). */
export function autoValue(item, slot, ctx) {
  return item.auto ? item.auto(ctx, slot.leg || "aller") : undefined;
}

/** Normalises stored tick values: legacy "-" and "NON" → "NON"; "OK" stays; anything else → "". */
export function normTick(v) {
  if (v === "OK") return "OK";
  if (v === "NON" || v === "-") return "NON";
  return "";
}
