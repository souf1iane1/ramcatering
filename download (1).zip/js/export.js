// Export of one flight check-list to Excel (.xlsx, SheetJS) and PDF (jsPDF + autoTable).
// Libraries are loaded on demand from cdnjs, so pages that never export stay light.
// The rows are read straight from the rendered form, so any field added to the page is exported too.

const CDN = "https://cdnjs.cloudflare.com/ajax/libs/";
const LIBS = {
  xlsx: [CDN + "xlsx/0.18.5/xlsx.full.min.js", () => window.XLSX],
  jspdf: [CDN + "jspdf/2.5.1/jspdf.umd.min.js", () => window.jspdf],
  autotable: [CDN + "jspdf-autotable/3.8.2/jspdf.plugin.autotable.min.js", () => window.jspdf?.jsPDF?.API?.autoTable],
};
const pending = {};
function loadLib(name) {
  const [src, ready] = LIBS[name];
  if (ready()) return Promise.resolve();
  return (pending[name] ||= new Promise((resolve, reject) => {
    const s = document.createElement("script");
    s.src = src;
    s.onload = resolve;
    s.onerror = () => { delete pending[name]; reject(new Error("Chargement impossible (connexion ?) : " + name)); };
    document.head.appendChild(s);
  }));
}

import { flightShift, shiftLabel, loadTime } from "./shifts.js";

const txt = (el) => (el?.textContent || "").replace(/\s+/g, " ").trim();

/** Reads the rendered check-list into [{section, item, prevu, valeur}] in on-screen order. */
function collectRows(root) {
  const rows = [];
  let section = "";
  const labelOf = (el) => txt(el.id && root.querySelector(`label[for="${el.id}"]`)) || el.placeholder || "";
  const valueOf = (el) => (el.tagName === "SELECT" ? (el.value ? el.selectedOptions[0].text : "") : el.value);

  root.querySelectorAll(".col-title, .section-header, .prod-group-title, .side h4, .kv-row, .pax-line, .cell, .side textarea").forEach((el) => {
    if (el.matches(".col-title")) section = txt(el);
    else if (el.matches(".section-header")) section = txt(el.querySelector("span") || el);
    else if (el.matches(".prod-group-title")) section = "Vérification produits " + txt(el.querySelector("span"));
    else if (el.matches(".side h4")) section = txt(el);
    else if (el.matches(".kv-row")) rows.push({ section, item: txt(el.querySelector(".k")), prevu: "", valeur: txt(el.querySelector(".v")) });
    else if (el.matches(".pax-line")) {
      const input = el.querySelector("input");
      rows.push({ section, item: txt(el.querySelector(".cell-label")) + (input ? " (" + txt(root.querySelector(`label[for="${input.id}"]`)).split("—")[0].trim() + ")" : ""), prevu: txt(el.querySelector(".prevu")), valeur: input ? input.value : "" });
    } else if (el.matches(".cell")) {
      if (el.classList.contains("readonly")) rows.push({ section, item: txt(el.querySelector(".cell-label")), prevu: "", valeur: txt(el.querySelector(".v")) });
      else { const inp = el.querySelector("input, select"); if (inp) rows.push({ section, item: labelOf(inp), prevu: "", valeur: valueOf(inp) }); }
    } else if (el.matches("textarea")) rows.push({ section, item: "Remarques agent contrôle", prevu: "", valeur: el.value });
  });
  return rows;
}

function meta(f) {
  const cat = String(f.aircraftCategory || "").replace(/_/g, " ");
  return [["Vol", f.flightNumber], ["Date", f.date], ["Heure dép.", f.heureDepart], ["Shift", shiftLabel(flightShift(f))], ["Heure MAD", f.heureMAD], ["Heure chargement", loadTime(f)],
          ["Type A/C", f.aircraftType], ["Catégorie", cat], ["Immat.", f.numEnregistrement]].map(([k, v]) => [k, v ?? ""]);
}
const fileBase = (f) => `checklist_${f.flightNumber || "vol"}_${String(f.date || "").replace(/[^\d-]/g, "") || new Date().toISOString().slice(0, 10)}`;
const TITLE = "CHECK LIST DE CONTRÔLE PRODUITS HOTELIER - PRESTATION";

export async function exportXlsx(root, f) {
  await loadLib("xlsx");
  const rows = collectRows(root);
  const aoa = [[TITLE], [], ...meta(f), [], ["Section", "Item", "Prévu", "Valeur / Réel"],
    ...rows.map((r) => [r.section, r.item, r.prevu, r.valeur])];
  const ws = XLSX.utils.aoa_to_sheet(aoa);
  ws["!cols"] = [{ wch: 34 }, { wch: 40 }, { wch: 10 }, { wch: 28 }];
  const wb = XLSX.utils.book_new();
  XLSX.utils.book_append_sheet(wb, ws, "Check-list");
  XLSX.writeFile(wb, fileBase(f) + ".xlsx");
}

export async function exportPdf(root, f) {
  await loadLib("jspdf");
  await loadLib("autotable");
  const { jsPDF } = window.jspdf;
  const clean = (s) => String(s ?? "").replace(/[—–]/g, "-").replace(/[^\x20-\xFF\n]/g, "");
  const doc = new jsPDF({ unit: "pt", format: "a4" });
  doc.setFontSize(13).setFont("helvetica", "bold").text(clean(TITLE), 40, 40);
  doc.autoTable({
    startY: 52, theme: "grid", styles: { fontSize: 9, cellPadding: 3 },
    body: [meta(f).slice(0, 4).flat().map(clean), meta(f).slice(4).flat().map(clean)].map((r) => { while (r.length < 8) r.push(""); return r; }),
    columnStyles: { 0: { fontStyle: "bold" }, 2: { fontStyle: "bold" }, 4: { fontStyle: "bold" }, 6: { fontStyle: "bold" } },
  });

  const body = [];
  let last = null;
  for (const r of collectRows(root)) {
    if (r.section !== last) { body.push([{ content: clean(r.section), colSpan: 3, styles: { fillColor: [138, 0, 0], textColor: 255, fontStyle: "bold" } }]); last = r.section; }
    body.push([clean(r.item), clean(r.prevu), clean(r.valeur)]);
  }
  doc.autoTable({
    startY: doc.lastAutoTable.finalY + 10, theme: "grid", head: [["Item", "Prévu", "Valeur / Réel"]], body,
    styles: { fontSize: 8.5, cellPadding: 2.5, overflow: "linebreak" },
    headStyles: { fillColor: [200, 0, 0] },
    columnStyles: { 0: { cellWidth: 230 }, 1: { cellWidth: 60 } },
    didDrawPage: () => {
      doc.setFontSize(8).setFont("helvetica", "normal");
      doc.text(`Généré le ${new Date().toLocaleString("fr-FR")}  -  page ${doc.getNumberOfPages()}`, 40, doc.internal.pageSize.getHeight() - 20);
    },
  });
  doc.save(fileBase(f) + ".pdf");
}

// ---------- Flight list export (flights page / dashboard) ----------
const LIST_HEAD = ["Vol", "Date", "Heure dép.", "Type A/C", "Catégorie", "Immat.", "Statut", "Shift", "Affecté à", "PAX Aller prévu (Y/CL)", "PAX Aller réel", "PAX Retour prévu (Y/CL)", "PAX Retour réel", "Contrôleur"];
const listRows = (list) => list.map((f) => [
  f.flightNumber, f.date || "", f.heureDepart || "", f.aircraftType || "", String(f.aircraftCategory || "").replace(/_/g, " "),
  f.numEnregistrement || "", String(f.status || "").replace(/_/g, " "),
  shiftLabel(flightShift(f)), f.assignedTo || "",
  f.imported?.yCl?.paxAllerPrevu ?? "", f.controller?.paxAllerReel ?? "", f.imported?.yCl?.paxRetourPrevu ?? "", f.controller?.paxRetourReel ?? "",
  f.updatedByName || "",
]);
const listName = () => "vols_" + new Date().toISOString().slice(0, 10);

export async function exportFlightsXlsx(list) {
  await loadLib("xlsx");
  const ws = XLSX.utils.aoa_to_sheet([LIST_HEAD, ...listRows(list)]);
  ws["!cols"] = LIST_HEAD.map((h) => ({ wch: Math.max(10, h.length + 2) }));
  const wb = XLSX.utils.book_new();
  XLSX.utils.book_append_sheet(wb, ws, "Vols");
  XLSX.writeFile(wb, listName() + ".xlsx");
}

export async function exportFlightsPdf(list) {
  await loadLib("jspdf");
  await loadLib("autotable");
  const doc = new window.jspdf.jsPDF({ unit: "pt", format: "a4", orientation: "landscape" });
  const clean = (s) => String(s ?? "").replace(/[—–]/g, "-").replace(/[^\x20-\xFF]/g, "");
  doc.setFontSize(13).setFont("helvetica", "bold").text("Liste des vols - Check-list", 40, 36);
  doc.autoTable({
    startY: 48, theme: "grid", head: [LIST_HEAD.map(clean)], body: listRows(list).map((r) => r.map(clean)),
    styles: { fontSize: 8, cellPadding: 2.5 }, headStyles: { fillColor: [200, 0, 0] },
  });
  doc.save(listName() + ".pdf");
}
