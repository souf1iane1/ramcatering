// Parses the Récap .xls/.xlsx sheet (SheetJS `XLSX` must already be loaded as a global).
// The PDF importer (pdf-parser.js) rebuilds the same rows and calls parseRecapRows() too.
// Design: the sheet packs three parallel multi-line lists per cabin (Code Prestation /
// Cycle / Nombre), one "cycle" token per line reading "Ngo" (aller) or "Nback" (retour).
// We zip those lines into items, then split each cabin into its main product line(s)
// (PAX counts) vs special-meal codes (…ML / …ML_xx) without guessing numbers that
// aren't in the sheet.

// Note: underscore counts as a "word" character in JS regex, so a plain \b boundary
// would miss the common "CHML_BC_RAM_YC" form — match on underscore/space/end instead.
const SPECIAL_MEAL_RE = /^[A-Z]{2,4}ML(?=[_\s]|$)/i;

function splitLines(cell) {
  if (cell === undefined || cell === null) return [];
  return String(cell)
    .split("\n")
    .map((s) => s.trim())
    .filter(Boolean);
}

function excelTimeToHHMM(v) {
  if (v === undefined || v === null || v === "") return "";
  if (typeof v === "number") {
    const totalMin = Math.round(v * 24 * 60);
    const hh = String(Math.floor(totalMin / 60) % 24).padStart(2, "0");
    const mm = String(totalMin % 60).padStart(2, "0");
    return `${hh}:${mm}`;
  }
  return String(v).trim();
}

/** Zips presta/cycle/nombre multi-line cells into {code, cycle, count} items,
 *  then separates "main" (PAX) lines from special-meal lines. */
function parseCabinBlock(prestaCell, cycleCell, nombreCell) {
  const codes = splitLines(prestaCell);
  const cycles = splitLines(cycleCell);
  const nums = splitLines(nombreCell);
  const n = Math.max(codes.length, cycles.length, nums.length);
  const items = [];
  for (let i = 0; i < n; i++) {
    const code = codes[i] || "";
    const cycle = (cycles[i] || "").toLowerCase();
    const count = parseInt(nums[i], 10);
    items.push({ code, cycle, count: Number.isFinite(count) ? count : null });
  }
  const main = items.filter((it) => it.code && !SPECIAL_MEAL_RE.test(it.code));
  const special = items.filter((it) => it.code && SPECIAL_MEAL_RE.test(it.code));

  // Long-courrier rows often list the SAME pax group twice under two different
  // product codes for the same cycle (e.g. "DCC"/"BCC", or "DC53"/"BF53" — one
  // line per meal service, dinner vs breakfast). Those are NOT extra passengers,
  // so we take the highest count per cycle instead of summing every line.
  const maxWhere = (list, matchGo) =>
    list.reduce((max, it) => {
      const isGo = it.cycle.includes("go");
      const isBack = it.cycle.includes("back");
      if ((matchGo && isGo) || (!matchGo && isBack)) return Math.max(max, it.count || 0);
      return max;
    }, 0);

  const allerPrevu = main.length ? maxWhere(main, true) || null : null;
  const retourPrevu = main.length ? maxWhere(main, false) || null : null;
  const codePrestation = [...new Set(main.map((m) => m.code))].join(", ");

  // group special meals by their first token (e.g. "CHML_BC_RAM_YC" -> "CHML");
  // same duplicate-service-line logic applies (see maxWhere above), so within a
  // group we take the max per cycle rather than summing the DC/BF variants.
  const groups = {};
  for (const it of special) {
    const prefix = it.code.split(/[_\s]/)[0].toUpperCase();
    if (!groups[prefix]) groups[prefix] = { code: prefix, allerPrevu: 0, retourPrevu: 0, hasAller: false, hasRetour: false };
    if (it.cycle.includes("go")) { groups[prefix].allerPrevu = Math.max(groups[prefix].allerPrevu, it.count || 0); groups[prefix].hasAller = true; }
    else if (it.cycle.includes("back")) { groups[prefix].retourPrevu = Math.max(groups[prefix].retourPrevu, it.count || 0); groups[prefix].hasRetour = true; }
  }
  const specialMeals = Object.values(groups).map((g) => ({
    code: g.code,
    allerPrevu: g.hasAller ? g.allerPrevu : null,
    retourPrevu: g.hasRetour ? g.retourPrevu : null,
  }));

  return { items, codePrestation, allerPrevu, retourPrevu, specialMeals };
}

/** Sums the (already deduped) per-type special-meal counts into one headcount —
 *  used for the checklist's single "SPML" total. Pass `leg` "aller" or "retour". */
export function totalSpecialMeals(specialMeals, leg = "aller") {
  if (!specialMeals || !specialMeals.length) return null;
  const key = leg === "retour" ? "retourPrevu" : "allerPrevu";
  const total = specialMeals.reduce((sum, s) => sum + (s[key] || 0), 0);
  return total || null;
}

export function classifyAircraft(machineCode) {
  const code = (machineCode || "").toUpperCase().trim();
  if (!code) return "";
  // Strip formatting separators (spaces/dashes/dots) before testing, so
  // "789", "78-9", "788-8", "B787-9", "7 8 9" all normalize to the same
  // digits and reliably match the long-courrier fleet (786/787/788/789).
  const compact = code.replace(/[\s.\-]/g, "");
  if (/78[6-9]/.test(compact)) return "LONG_COURRIER";
  if (/^(AT[4-9]|E7\d|E9\d|ATR)/.test(code)) return "COURT_COURRIER";
  return "MOYEN_COURRIER";
}

function extractRecapDate(titleText) {
  const m = String(titleText || "").match(/(\d{1,2})[-\/](\d{1,2})[-\/](\d{2,4})/);
  if (!m) return null;
  let [, d, mo, y] = m;
  if (y.length === 2) y = "20" + y;
  else if (y.length === 3) y = "2" + y; // guards against a stray-digit typo like "026"
  return `${y}-${mo.padStart(2, "0")}-${d.padStart(2, "0")}`;
}

const isTimeCell = (v) => (typeof v === "number" ? v > 0 && v < 1 : /^\s*\d{1,2}\s*[:hH]\s*\d{2}(\s*:\s*\d{2})?\s*$/.test(String(v ?? "")));

const HEADER_MATCHERS = [
  { key: "flightNumber", test: (h) => /num[ée]ro\s*de\s*vol/i.test(h) },
  { key: "heureDepart", test: (h) => /heure\s*d[ée]p/i.test(h) },
  { key: "heureMAD", test: (h) => /(^|[^a-z])m\.?a\.?d([^a-z]|$)/i.test(h) }, // "Heure MAD", "Heure\nMAD", "H. MAD", "MAD", "Heure M.A.D"…
  { key: "fcPresta", test: (h) => /^fc presta/i.test(h) },
  { key: "fcCycle", test: (h) => /^fc cycle/i.test(h) },
  { key: "fcNombre", test: (h) => /^fc nombre/i.test(h) },
  { key: "jcPresta", test: (h) => /^jc presta/i.test(h) },
  { key: "jcCycle", test: (h) => /^jc cycle/i.test(h) },
  { key: "jcNombre", test: (h) => /^jc nombre/i.test(h) },
  { key: "ycPresta", test: (h) => /^yc presta/i.test(h) },
  { key: "ycCycle", test: (h) => /^yc cycle/i.test(h) },
  { key: "ycNombre", test: (h) => /^yc nombre/i.test(h) },
  { key: "peqPresta", test: (h) => /^peq presta/i.test(h) },
  { key: "peqCycle", test: (h) => /^peq cycle/i.test(h) },
  { key: "peqNombre", test: (h) => /^peq nombre/i.test(h) },
  { key: "bobPresta", test: (h) => /^bob presta/i.test(h) },
  { key: "bobCycle", test: (h) => /^bob cycle/i.test(h) },
  { key: "bobNombre", test: (h) => /^bob nombre/i.test(h) },
  { key: "machine", test: (h) => /machine/i.test(h) },
  { key: "numEnregistrement", test: (h) => /enregistrement/i.test(h) },
  { key: "note", test: (h) => /^note/i.test(h) },
];

/** @param {ArrayBuffer} arrayBuffer  @returns {{date:string|null, flights: object[]}} */
export function parseRecapWorkbook(arrayBuffer) {
  const wb = XLSX.read(arrayBuffer, { type: "array", cellText: true });
  const sheet = wb.Sheets[wb.SheetNames[0]];
  const rows = XLSX.utils.sheet_to_json(sheet, { header: 1, defval: "", raw: true });
  return parseRecapRows(rows);
}

/** Shared by the Excel and PDF importers: `rows` is an array of arrays (title row(s), header row, one row per
 *  flight with multi-line cells joined by "\n"). @returns {{date:string|null, flights: object[]}} */
// ---------------------------------------------------------------------------------------------------------------------
// SPML in the Note column. Lunch-box (LB) flights list their special meals in the note instead of the presta
// lines, one per line, in several spellings:
//   "2 GFML _LB_RAM_YC ALLER"   "5 AVML_LB_RAM_YC RETOUR"   "01 DBML LB YC RTR"   "01 POML RAM JC ALLER"
//   "1 BBML_BF_RAM_YC ALLER"    "01 HNML BF YC"             "01 DBML-LB-RTR-Y"    "02 POML RAM JC"
// = <count> <CODE>ML … <cabin: YC / JC> … <leg: ALLER / RETOUR / RTR>. No leg written -> ALLER; no cabin -> Y/CL.
// (Description lines such as "Beef tajine with peas…" or "PREVISION RTR PAR MSG" do not start with count + code.)
const NOTE_SPML_RE = /^\s*(\d{1,3})\s+([A-Z]{2}ML?)(?=[\s_-]|$)(.*)$/i; // "VGM" (typo for VGML) is accepted too
const NOTE_SEP = "(?:^|[\\s_-])";
const NOTE_END = "(?=$|[\\s_-])";
const NOTE_CABIN_RE = new RegExp(`${NOTE_SEP}(YC|JC|CC|Y|J|C)${NOTE_END}`, "i");
const NOTE_LEG_RE = new RegExp(`${NOTE_SEP}(ALLER|ALL|RETOUR|RTR|RET)${NOTE_END}`, "i");

/** Reads the SPML lines of a note -> [{ cabin: "yCl"|"cCl", code, leg: "aller"|"retour", count, line }]. */
export function parseNoteSpecialMeals(note) {
  const out = [];
  for (const line of String(note || "").split(/\r?\n/)) {
    const m = line.match(NOTE_SPML_RE);
    if (!m) continue;
    const count = parseInt(m[1], 10);
    if (!Number.isFinite(count)) continue;
    const rest = m[3] || "";
    const cab = rest.match(NOTE_CABIN_RE)?.[1]?.toUpperCase();
    const leg = rest.match(NOTE_LEG_RE)?.[1]?.toUpperCase();
    out.push({
      cabin: cab === "JC" || cab === "J" || cab === "CC" || cab === "C" ? "cCl" : "yCl",
      code: m[2].toUpperCase().replace(/M$/, "ML"),
      leg: leg && /^(RETOUR|RTR|RET)$/.test(leg) ? "retour" : "aller",
      count,
      line: line.trim(),
    });
  }
  return out;
}

/** Adds the note's special meals to the cabins' specialMeals (same code + leg already listed -> keeps the larger count). */
export function mergeNoteSpecialMeals(cCl, yCl, note) {
  const found = parseNoteSpecialMeals(note);
  const blocks = { cCl, yCl };
  for (const it of found) {
    const list = blocks[it.cabin].specialMeals;
    const key = it.leg === "retour" ? "retourPrevu" : "allerPrevu";
    const cur = list.find((s) => s.code === it.code);
    if (cur) cur[key] = Math.max(cur[key] || 0, it.count);
    else list.push({ code: it.code, allerPrevu: it.leg === "aller" ? it.count : null, retourPrevu: it.leg === "retour" ? it.count : null, fromNote: true });
  }
  return found.length;
}

export function parseRecapRows(rows, fallbackDateText = "") {
  const titleText = rows.slice(0, 3).map((r) => r[0]).join(" ");
  const date = extractRecapDate(titleText) || extractRecapDate(fallbackDateText);

  let headerRowIdx = -1;
  let colMap = {};
  for (let r = 0; r < Math.min(rows.length, 15); r++) {
    const map = {};
    rows[r].forEach((cell, c) => {
      const h = String(cell || "").replace(/[\s\u00a0]+/g, " ").trim(); // multi-line headers ("Heure\nMAD") -> one line
      if (!h) return;
      const matcher = HEADER_MATCHERS.find((m) => m.test(h));
      if (matcher && map[matcher.key] === undefined) map[matcher.key] = c; // first column wins
    });
    if (map.flightNumber !== undefined && map.heureDepart !== undefined) {
      headerRowIdx = r;
      colMap = map;
      break;
    }
  }
  if (headerRowIdx === -1) throw new Error("En-tête du fichier Récap introuvable (colonne 'Numéro de vol' manquante).");

  const flights = [];
  let madGuessed = 0;
  for (let r = headerRowIdx + 1; r < rows.length; r++) {
    const row = rows[r];
    // IMPORTANT: only Royal Air Maroc flight numbers are imported.
    // Accept AT followed by 3 or 4 digits, with an optional space (e.g. AT208 / AT 208).
    // Reject AF, QR, TU, IB, or any other airline prefix.
    const rawFlightNumber = String(row[colMap.flightNumber] || "").trim().toUpperCase();
    const flightMatch = rawFlightNumber.match(/^AT\s*(\d{3,4})$/);
    if (!flightMatch) continue;
    const flightNumber = `AT${flightMatch[1]}`;

    const cCl = parseCabinBlock(row[colMap.jcPresta], row[colMap.jcCycle], row[colMap.jcNombre]);
    const yCl = parseCabinBlock(row[colMap.ycPresta], row[colMap.ycCycle], row[colMap.ycNombre]);
    const noteText = String(row[colMap.note] || "").trim();
    const noteSpml = mergeNoteSpecialMeals(cCl, yCl, noteText);
    const peq = parseCabinBlock(row[colMap.peqPresta], row[colMap.peqCycle], row[colMap.peqNombre]);
    const bob = parseCabinBlock(row[colMap.bobPresta], row[colMap.bobCycle], row[colMap.bobNombre]);
    const machine = String(row[colMap.machine] || "").trim();
    // Heure MAD: from its column; if that column is missing/empty, fall back on the first OTHER time found on the row.
    let heureMAD = colMap.heureMAD !== undefined ? excelTimeToHHMM(row[colMap.heureMAD]) : "";
    if (!heureMAD) {
      const alt = row.find((v, c) => c !== colMap.heureDepart && c !== colMap.flightNumber && isTimeCell(v));
      if (alt !== undefined) { heureMAD = excelTimeToHHMM(alt); madGuessed++; }
    }

    flights.push({
      flightNumber,
      date,
      heureDepart: excelTimeToHHMM(row[colMap.heureDepart]),
      heureMAD,
      aircraftType: machine,
      aircraftCategory: classifyAircraft(machine),
      numEnregistrement: String(row[colMap.numEnregistrement] || "").trim(),
      note: noteText,
      noteSpml, // number of SPML lines read from the note
      imported: {
        cCl: { codePrestation: cCl.codePrestation, paxAllerPrevu: cCl.allerPrevu, paxRetourPrevu: cCl.retourPrevu, specialMeals: cCl.specialMeals, raw: cCl.items },
        yCl: { codePrestation: yCl.codePrestation, paxAllerPrevu: yCl.allerPrevu, paxRetourPrevu: yCl.retourPrevu, specialMeals: yCl.specialMeals, raw: yCl.items },
        peq: { codePrestation: peq.codePrestation, allerPrevu: peq.allerPrevu, retourPrevu: peq.retourPrevu, raw: peq.items },
        bob: { codePrestation: bob.codePrestation, allerPrevu: bob.allerPrevu, retourPrevu: bob.retourPrevu, raw: bob.items },
      },
    });
  }
  const headers = rows[headerRowIdx].map((c) => String(c || "").replace(/[\s\u00a0]+/g, " ").trim()).filter(Boolean);
  return { date, flights, headers, madColumn: colMap.heureMAD !== undefined, madGuessed, madMissing: flights.filter((f) => !f.heureMAD).length, noteSpmlFlights: flights.filter((f) => f.noteSpml).length };
}
