// Shared by the flights page and the dashboard: saved shift plans (made by the admin with « Répartition manuelle »)
// and the planning (Excel), which only tells which controllers are on each shift. There is NO automatic split.
import { listShiftPlans, listPlanning } from "./api.js";
import { SHIFT_ORDER, flightShift, planDateFor, addDays } from "./shifts.js";

// Saved shift plans, cached per date: { morning: {controllers, assignments}, ... }
export const plansCache = new Map();
export async function loadPlans(date) {
  if (!date) return {};
  if (plansCache.has(date)) return plansCache.get(date);
  const out = {};
  try {
    (await listShiftPlans(date)).forEach((p) => { out[p.shift] = p; });
  } catch (e) { console.warn("shiftPlans:", e); }
  plansCache.set(date, out);
  return out;
}

// Shift planning imported from the planning Excel: { "2026-10-05": {morning:[..], afternoon:[..], night:[..]} }
export const planningCache = new Map();
export async function loadPlanning(date) {
  if (!date) return;
  const need = [date, addDays(date, -1)].filter((d) => !planningCache.has(d));
  if (!need.length) return;
  try {
    (await listPlanning(need)).forEach((d) => planningCache.set(d.date, d));
  } catch (e) { console.warn("planning:", e); }
  need.forEach((d) => { if (!planningCache.has(d)) planningCache.set(d, null); });
}
export const planningNames = (date, shift) => planningCache.get(date)?.[shift] || [];

export function flightDateOf(f) {
  const raw = f?.date;
  const iso = (d) => `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, "0")}-${String(d.getDate()).padStart(2, "0")}`;
  if (raw && typeof raw.toDate === "function") return iso(raw.toDate());
  if (raw instanceof Date) return iso(raw);
  const v = String(raw || "").trim();
  if (/^\d{4}-\d{2}-\d{2}$/.test(v)) return v;
  let m = v.match(/^(\d{2})[\/-](\d{2})[\/-](\d{4})$/);
  if (m) return `${m[3]}-${m[2]}-${m[1]}`;
  m = String(f?.id || "").match(/^(\d{4}-\d{2}-\d{2})_AT\d{3,4}$/i);
  return m ? m[1] : "";
}

/** Sets f.shift / f.planDate / f.assignedTo on the flights of ONE date.
 *  The shift is detected from the loading time; f.assignedTo comes ONLY from the plan saved by the admin
 *  (Répartition manuelle) — nothing is split automatically.
 *  Returns { saved, effective } = saved plans and, per shift, the controllers that have flights. */
export async function assignDay(dayFlights, date, dateOf = flightDateOf) {
  const saved = await loadPlans(date);
  await loadPlanning(date);
  dayFlights.forEach((f) => { f.shift = flightShift(f); f.planDate = planDateFor(f, dateOf(f), f.shift); f.assignedTo = ""; });
  const effective = {};
  for (const k of SHIFT_ORDER) {
    const items = dayFlights.filter((f) => f.shift === k);
    if (!items.length) continue;
    items.forEach((f) => { f.assignedTo = saved[k]?.assignments?.[f.flightNumber] || ""; });
    effective[k] = { controllers: [...new Set(items.map((f) => f.assignedTo).filter(Boolean))], saved: !!saved[k] };
  }
  return { saved, effective };
}
