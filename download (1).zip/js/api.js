// Client for the PHP backend in /api (replaces Firebase Auth + Firestore).
// All calls are same-origin and use the PHP session cookie.

const BASE = new URL("../api/", import.meta.url).href;   // js/api.js -> <site>/api/
const LOGIN_URL = new URL("../login.html", import.meta.url).href;

// Fallback for browsers/hosts that refuse the session cookie: the login page stores the session id here
// and every request sends it as a header instead. Normally empty (the HttpOnly cookie is used).
const TOKEN_KEY = "checklist_token";
let authToken = null;
try { authToken = localStorage.getItem(TOKEN_KEY); } catch { /* storage blocked */ }
export function setAuthToken(t) {
  authToken = t || null;
  try { t ? localStorage.setItem(TOKEN_KEY, t) : localStorage.removeItem(TOKEN_KEY); } catch { /* ignore */ }
}

export class ApiError extends Error {
  constructor(message, status) { super(message); this.name = "ApiError"; this.status = status; }
}

/** Firestore-like timestamp so existing code can keep calling `.toDate()`. */
export class Timestamp {
  constructor(iso) { this._d = new Date(iso); }
  toDate() { return new Date(this._d.getTime()); }
  toMillis() { return this._d.getTime(); }
  get seconds() { return Math.floor(this._d.getTime() / 1000); }
}
const TS_KEYS = new Set(["createdAt", "updatedAt", "uploadedAt", "timestamp"]);
const ISO_RE = /^\d{4}-\d{2}-\d{2}T\d{2}:\d{2}:\d{2}Z$/;
function revive(v, key) {
  if (Array.isArray(v)) return v.map((x) => revive(x));
  if (v && typeof v === "object") {
    const out = {};
    for (const [k, x] of Object.entries(v)) out[k] = revive(x, k);
    return out;
  }
  return TS_KEYS.has(key) && typeof v === "string" && ISO_RE.test(v) ? new Timestamp(v) : v;
}

async function request(method, path, { query, body } = {}) {
  const url = new URL(path, BASE);
  if (query) for (const [k, v] of Object.entries(query)) if (v !== undefined && v !== null && v !== "") url.searchParams.set(k, v);
  // Unique URL per GET: defeats host/CDN caches that key on the URL only and ignore cookies.
  if (method === "GET") url.searchParams.set("_", Date.now().toString(36) + Math.random().toString(36).slice(2, 6));
  let res;
  try {
    res = await fetch(url, {
      method,
      credentials: "same-origin",
      cache: "no-store",
      headers: {
        Accept: "application/json", "X-Requested-With": "fetch",
        ...(authToken ? { "X-Auth-Token": authToken } : {}),
        ...(body !== undefined ? { "Content-Type": "application/json" } : {}),
      },
      body: body !== undefined ? JSON.stringify(body) : undefined,
    });
  } catch {
    throw new ApiError("Serveur injoignable. Vérifiez votre connexion.", 0);
  }
  let data = null;
  try { data = await res.json(); } catch { /* non-JSON error page */ }
  if (!res.ok) {
    // Session expired / signed out elsewhere: go back to the login page.
    if (res.status === 401 && path !== "auth/login" && path !== "auth/me") {
      setAuthToken(null);
      location.href = LOGIN_URL;
      return new Promise(() => {});
    }
    throw new ApiError(data?.error || `Erreur serveur (${res.status})`, res.status);
  }
  return revive(data);
}

// ---- auth
export const diagnose = () => request("GET", "auth/diag");
export const login = (email, password, remember) => {
  setAuthToken(null); // a leftover token must never mask a cookie problem (or a different account)
  return request("POST", "auth/login", { body: { email, password, remember: !!remember } });
};
export async function logout() {
  try { return await request("POST", "auth/logout", { body: {} }); }
  finally { setAuthToken(null); }
}
/** Current profile, or null when not signed in. */
export async function me() {
  try { return await request("GET", "auth/me"); }
  catch (e) { if (e.status === 401) return null; throw e; }
}

export const updateProfile = (name) => request("PATCH", "auth/profile", { body: { name } });
export async function changePassword(currentPassword, newPassword) {
  const res = await request("POST", "auth/password", { body: { currentPassword, newPassword } });
  if (authToken && res?.token) setAuthToken(res.token); // the server rotated the session
  return res;
}

// ---- users (admin)
export const listUsers = (role) => request("GET", "users", { query: { role } });
export const createUser = (u) => request("POST", "users", { body: u });
export const deleteUser = (id) => request("DELETE", `users/${encodeURIComponent(id)}`);
export const updateUser = (id, patch) => request("PATCH", `users/${encodeURIComponent(id)}`, { body: patch });

// ---- flights
export const listFlights = () => request("GET", "flights");
export async function getFlight(id) {
  try { return await request("GET", "flight", { query: { id } }); }
  catch (e) { if (e.status === 404) return null; throw e; }
}
export const deleteFlight = (id) => request("DELETE", "flight", { query: { id } });
// Admin: edit a flight by hand ({core:{...}, controller:{...}}) or add a new one ({flightNumber, date, core, controller}).
export const updateFlight = (id, patch) => request("PATCH", "flight", { query: { id }, body: patch });
export const createFlight = (payload) => request("POST", "flight", { body: payload });
export const updateController = (id, changes) => request("PATCH", "flight/controller", { query: { id }, body: { changes } });

// ---- recaps / audit
export const uploadRecap = (payload) => request("POST", "recaps", { body: payload });
export const listRecaps = (limit = 20) => request("GET", "recaps", { query: { limit } });
export const listAuditLogs = (limit = 200) => request("GET", "audit-logs", { query: { limit } });

// ---- shift plans & planning
export const listShiftPlans = (date) => request("GET", "shift-plans", { query: { date } });
export const saveShiftPlan = (plan) => request("PUT", "shift-plans", { body: plan });
export const deleteShiftPlan = (id) => request("DELETE", "shift-plans", { query: { id } });
export const listPlanning = (dates) => request("GET", "planning", { query: { dates: dates?.join(",") } });
export const savePlanning = (days, source) => request("PUT", "planning", { body: { days, source } });

// ---- loading plans ("Plan de chargement")
export const listLoadingPlans = () => request("GET", "loading-plans");
export const uploadLoadingPlan = (type, fileName, dataBase64) => request("POST", "loading-plans", { body: { type, fileName, dataBase64 } });
export const deleteLoadingPlan = (type) => request("DELETE", "loading-plans", { query: { type } });

// ---- fiches techniques (one PDF per code prestation: DC25, BC55, CF99…)
export const listTechSheets = () => request("GET", "tech-sheets");
export const uploadTechSheet = (type, fileName, dataBase64) => request("POST", "tech-sheets", { body: { type, fileName, dataBase64 } });
export const deleteTechSheet = (type) => request("DELETE", "tech-sheets", { query: { type } });

/** The PDF bytes for one family code, as a Blob (not JSON — reuses the same auth as every other
 *  call so it works whether the browser accepts the session cookie or needs the X-Auth-Token
 *  fallback). Throws ApiError on 403/404/etc, same as request(). */
export const fetchLoadingPlanBlob = (type) => fetchPdfBlob("loading-plan", type);
export const fetchTechSheetBlob = (type) => fetchPdfBlob("tech-sheet", type);

async function fetchPdfBlob(route, type) {
  const url = new URL(route, BASE);
  url.searchParams.set("type", type);
  url.searchParams.set("_", Date.now().toString(36) + Math.random().toString(36).slice(2, 6));
  let res;
  try {
    res = await fetch(url, {
      method: "GET", credentials: "same-origin", cache: "no-store",
      headers: { Accept: "application/pdf", "X-Requested-With": "fetch", ...(authToken ? { "X-Auth-Token": authToken } : {}) },
    });
  } catch {
    throw new ApiError("Serveur injoignable. Vérifiez votre connexion.", 0);
  }
  if (!res.ok) {
    let msg = `Erreur serveur (${res.status})`;
    try { msg = (await res.json())?.error || msg; } catch { /* non-JSON error page */ }
    if (res.status === 401) { setAuthToken(null); location.href = LOGIN_URL; return new Promise(() => {}); }
    throw new ApiError(msg, res.status);
  }
  return res.blob();
}
