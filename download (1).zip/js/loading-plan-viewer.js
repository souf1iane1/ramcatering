// « Plan de chargement » viewer: fetches the matching PDF (see js/loading-plans.js: matchLoadingPlan)
// and shows it in a modal <iframe>, with a direct download link. Reuses the .fe-overlay/.fe-modal
// look from flight-editor.js so it fits the rest of the app.
import { icon } from "./icons.js";
import { showToast } from "./auth.js";
import { fetchLoadingPlanBlob, fetchTechSheetBlob } from "./api.js";

const esc = (v) => String(v ?? "").replace(/[&<>"']/g, (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]));

const PDFJS_VERSION = "3.11.174";
const PDFJS_BASE = `https://cdnjs.cloudflare.com/ajax/libs/pdf.js/${PDFJS_VERSION}/`;

let currentUrl = null; // the last object URL, revoked when the modal closes or a new one opens
let cleanup = null;    // tears down the canvas renderer (resize listener, pdf.js document)

function closeViewer() {
  if (cleanup) { cleanup(); cleanup = null; }
  document.getElementById("lpOverlay")?.remove();
  if (currentUrl) { URL.revokeObjectURL(currentUrl); currentUrl = null; }
}

/** Phones and tablets (iPadOS reports itself as a Mac, hence the touch check) can't show a PDF inside an
 *  <iframe>: iOS only draws page 1 without scrolling, Android Chrome shows nothing / a download prompt.
 *  There we draw the pages ourselves with pdf.js. Desktop keeps the browser's own PDF viewer. */
function needsCanvasViewer() {
  const touch = (navigator.maxTouchPoints || 0) > 0 || matchMedia("(pointer: coarse)").matches;
  const mobileUA = /Android|iPhone|iPad|iPod|Mobile/i.test(navigator.userAgent);
  if (mobileUA || touch) return true;
  return navigator.pdfViewerEnabled === false;
}

let pdfjsPromise = null;
function loadPdfJs() {
  if (globalThis.pdfjsLib) return Promise.resolve(globalThis.pdfjsLib);
  if (!pdfjsPromise) {
    pdfjsPromise = new Promise((resolve, reject) => {
      const s = document.createElement("script");
      s.src = `${PDFJS_BASE}pdf.min.js`;
      s.onload = () => resolve(globalThis.pdfjsLib);
      s.onerror = () => { pdfjsPromise = null; reject(new Error("Impossible de charger l'afficheur PDF. Utilisez « Télécharger ».")); };
      document.head.appendChild(s);
    });
  }
  return pdfjsPromise.then((lib) => {
    lib.GlobalWorkerOptions.workerSrc = `${PDFJS_BASE}pdf.worker.min.js`;
    return lib;
  });
}

/** Renders every page of `blob` as a canvas inside `body`, fitted to its width, with +/- zoom buttons. */
async function renderCanvasViewer(blob, body) {
  const lib = await loadPdfJs();
  const data = new Uint8Array(await blob.arrayBuffer());
  const pdf = await lib.getDocument({ data }).promise;

  body.innerHTML = `
    <div class="lp-viewer">
      <div class="lp-toolbar">
        <button type="button" class="btn ghost small" id="lpZoomOut" aria-label="Zoom arrière">${icon("minus", 16)}</button>
        <span id="lpZoomLvl" class="lp-zoom-lvl">100%</span>
        <button type="button" class="btn ghost small" id="lpZoomIn" aria-label="Zoom avant">${icon("plus", 16)}</button>
        <span class="lp-pages" id="lpPageInfo">${pdf.numPages} page${pdf.numPages > 1 ? "s" : ""}</span>
      </div>
      <div class="lp-scroll" id="lpScroll"><div class="lp-pages-wrap" id="lpPages"></div></div>
    </div>`;
  const scroll = document.getElementById("lpScroll");
  const wrap = document.getElementById("lpPages");
  const lvl = document.getElementById("lpZoomLvl");

  let zoom = 1, renderId = 0, destroyed = false, lastWidth = 0;

  async function renderAll() {
    const id = ++renderId;
    const avail = Math.max(200, scroll.clientWidth - 16);
    lastWidth = scroll.clientWidth;
    const dpr = Math.min(window.devicePixelRatio || 1, 3);
    const frag = document.createDocumentFragment();
    const canvases = [];
    for (let n = 1; n <= pdf.numPages; n++) {
      const c = document.createElement("canvas");
      c.className = "lp-canvas";
      frag.appendChild(c); canvases.push(c);
    }
    for (let n = 1; n <= pdf.numPages; n++) {
      const page = await pdf.getPage(n);
      if (destroyed || id !== renderId) return;
      const base = page.getViewport({ scale: 1 });
      const cssScale = (avail / base.width) * zoom;
      let renderScale = cssScale * dpr;
      // keep each canvas under common mobile limits (~16.7M px on iOS)
      const maxPx = 14e6;
      const px = base.width * base.height * renderScale * renderScale;
      if (px > maxPx) renderScale *= Math.sqrt(maxPx / px);
      const vp = page.getViewport({ scale: renderScale });
      const c = canvases[n - 1];
      c.width = Math.floor(vp.width); c.height = Math.floor(vp.height);
      c.style.width = `${Math.floor(base.width * cssScale)}px`;
      c.style.height = `${Math.floor(base.height * cssScale)}px`;
      await page.render({ canvasContext: c.getContext("2d"), viewport: vp }).promise;
      if (n === 1) { wrap.replaceChildren(frag); } // show page 1 as soon as it is ready
    }
    if (!canvases[0].isConnected) wrap.replaceChildren(frag);
  }

  const setZoom = (z) => {
    zoom = Math.min(4, Math.max(0.5, Math.round(z * 100) / 100));
    lvl.textContent = `${Math.round(zoom * 100)}%`;
    renderAll().catch(() => {});
  };
  document.getElementById("lpZoomIn").addEventListener("click", () => setZoom(zoom + 0.25));
  document.getElementById("lpZoomOut").addEventListener("click", () => setZoom(zoom - 0.25));

  // Re-fit on rotation / window resize (width only: the mobile URL bar changes the height while scrolling).
  let t;
  const onResize = () => {
    clearTimeout(t);
    t = setTimeout(() => { if (Math.abs(scroll.clientWidth - lastWidth) > 4) renderAll().catch(() => {}); }, 200);
  };
  window.addEventListener("resize", onResize);
  window.addEventListener("orientationchange", onResize);

  cleanup = () => {
    destroyed = true; clearTimeout(t);
    window.removeEventListener("resize", onResize);
    window.removeEventListener("orientationchange", onResize);
    pdf.destroy?.();
  };

  await renderAll();
}

/** Opens the modal, fetches the PDF, and shows it. `label` is shown in the title (e.g. "AT208 · 788").
 *  `kind` picks the document: "plan" (Plan de chargement, by aircraft type) or "fiche" (Fiche technique, by code presta). */
export async function openLoadingPlanViewer({ type, label = "", kind = "plan" } = {}) {
  if (!type) return;
  const isFiche = kind === "fiche";
  const docName = isFiche ? "Fiche technique" : "Plan de chargement";
  const fetchBlob = isFiche ? fetchTechSheetBlob : fetchLoadingPlanBlob;
  closeViewer();
  const ov = document.createElement("div");
  ov.id = "lpOverlay"; ov.className = "fe-overlay";
  ov.innerHTML = `
    <div class="fe-modal lp-modal" role="dialog" aria-modal="true" aria-labelledby="lpTitle">
      <div class="fe-head">
        <h2 id="lpTitle">${icon("fileText", 18)} ${docName} ${label ? `· ${esc(label)}` : ""}</h2>
        <div class="lp-head-actions">
          <a id="lpDownload" class="btn ghost small" hidden>${icon("download", 16)} Télécharger</a>
          <button type="button" class="fe-x" id="lpClose" aria-label="Fermer">${icon("x", 18)}</button>
        </div>
      </div>
      <div class="lp-body" id="lpBody"><div class="lp-loading">Chargement du PDF…</div></div>
    </div>`;
  document.body.appendChild(ov);
  ov.addEventListener("click", (e) => { if (e.target === ov) closeViewer(); });
  document.getElementById("lpClose").addEventListener("click", closeViewer);
  const onEsc = (e) => { if (e.key === "Escape") closeViewer(); };
  document.addEventListener("keydown", onEsc, { once: true });

  const body = document.getElementById("lpBody");
  try {
    const blob = await fetchBlob(type);
    if (!document.getElementById("lpOverlay")) return; // closed while fetching
    currentUrl = URL.createObjectURL(blob);
    const dl = document.getElementById("lpDownload");
    dl.href = currentUrl; dl.download = `${type}.pdf`; dl.target = "_blank"; dl.rel = "noopener"; dl.hidden = false;
    if (needsCanvasViewer()) {
      try {
        await renderCanvasViewer(blob, body);
      } catch (e) {
        if (!document.getElementById("lpOverlay")) return;
        // pdf.js unavailable (offline CDN…) → last resort: open the PDF in the browser's own viewer
        body.innerHTML = `<div class="lp-error">${esc(e?.message || "Impossible d'afficher le PDF.")}<br><br>
          <a class="btn small" href="${currentUrl}" target="_blank" rel="noopener">${icon("fileText", 16)} Ouvrir le PDF</a></div>`;
      }
    } else {
      body.innerHTML = `<iframe class="lp-frame" src="${currentUrl}" title="${docName} ${esc(type)}"></iframe>`;
    }
  } catch (err) {
    if (!document.getElementById("lpOverlay")) return;
    body.innerHTML = `<div class="lp-error">${esc(err?.message || `Impossible de charger : ${docName.toLowerCase()}.`)}</div>`;
    showToast(err?.message || `Impossible de charger : ${docName.toLowerCase()}.`, "error");
  }
}
