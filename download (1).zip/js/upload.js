import { requireAuth } from "./auth.js";
import { parseRecapWorkbook } from "./excel-parser.js";
import { parseRecapPdf } from "./pdf-parser.js";
import { saveRecapUpload } from "./data.js";
import { assignRecapShifts, flightShift, shiftLabel, loadTime } from "./shifts.js";

const { profile } = await requireAuth("admin/upload.html");

const dropzone = document.getElementById("dropzone");
const fileInput = document.getElementById("fileInput");
const dzText = document.getElementById("dzText");
const msg = document.getElementById("msg");
const preview = document.getElementById("preview");

let parsedResult = null;
let fileName = "";

["dragover", "dragleave", "drop"].forEach((evt) =>
  dropzone.addEventListener(evt, (e) => {
    e.preventDefault();
    dropzone.classList.toggle("drag", evt === "dragover");
    if (evt === "drop" && e.dataTransfer.files[0]) handleFile(e.dataTransfer.files[0]);
  })
);
fileInput.addEventListener("change", () => fileInput.files[0] && handleFile(fileInput.files[0]));

async function handleFile(file) {
  msg.innerHTML = "";
  preview.innerHTML = "";
  fileName = file.name;
  dzText.textContent = `Analyse de « ${file.name} »…`;
  try {
    const buffer = await file.arrayBuffer();
    const isPdf = /\.pdf$/i.test(file.name) || new TextDecoder().decode(new Uint8Array(buffer, 0, 5)).startsWith("%PDF");
    if (isPdf) {
      if (globalThis.pdfjsLib) pdfjsLib.GlobalWorkerOptions.workerSrc = "https://cdnjs.cloudflare.com/ajax/libs/pdf.js/3.11.174/pdf.worker.min.js";
      parsedResult = await parseRecapPdf(buffer);
      parsedResult.fromPdf = true;
      // fall back on the file name ("RECAP_29_OCT_2026.pdf") if the title carries no date
      if (!parsedResult.date) parsedResult.date = dateFromName(file.name);
      parsedResult.flights.forEach((f) => { if (!f.date) f.date = parsedResult.date; });
    } else {
      parsedResult = parseRecapWorkbook(buffer);
    }
    if (!parsedResult.flights.length) throw new Error("Aucun vol AT détecté dans ce fichier. Seuls les vols commençant par AT sont importés.");
    parsedResult.shiftInfo = assignRecapShifts(parsedResult.flights); // shift = position in the recap (anchor flights)
    dzText.textContent = `Fichier chargé : ${file.name}`;
    renderPreview(parsedResult);
  } catch (err) {
    parsedResult = null;
    dzText.textContent = "Glissez le fichier Récap (Excel ou PDF) ici, ou cliquez pour parcourir";
    msg.innerHTML = `<div class="error-msg">${err.message}</div>`;
  }
}

const MONTHS = { jan: 1, janv: 1, feb: 2, fev: 2, febr: 2, mar: 3, mars: 3, apr: 4, avr: 4, avri: 4, may: 5, mai: 5, jun: 6, juin: 6, jul: 7, juil: 7, aug: 8, aou: 8, sep: 9, sept: 9, oct: 10, nov: 11, dec: 12 };
/** "RECAP_29_OCT_2026.pdf" -> "2026-10-29" (null when the name has no date). */
function dateFromName(name) {
  const m = String(name).match(/(\d{1,2})[\s_.-]*([a-zA-Zéûàè]{3,9})[\s_.-]*(\d{4})/);
  if (!m) return null;
  const w = m[2].toLowerCase().normalize("NFD").replace(/[\u0300-\u036f]/g, "");
  const mo = MONTHS[w] || MONTHS[w.slice(0, 4)] || MONTHS[w.slice(0, 3)];
  return mo ? `${m[3]}-${String(mo).padStart(2, "0")}-${m[1].padStart(2, "0")}` : null;
}

function renderPreview(result) {
  const warn = result.warnings?.length
    ? `<div class="error-msg">Lecture du PDF : ${result.warnings.length} vol(s) à vérifier (colonnes dont le nombre de lignes diffère) : ${result.warnings.slice(0, 12).join(" · ")}${result.warnings.length > 12 ? " …" : ""}. Si un doute subsiste, importez le fichier Excel.</div>`
    : "";
  const madWarn = !result.madColumn
    ? `<div class="error-msg">Colonne « Heure MAD » introuvable dans ce fichier. Colonnes lues : ${result.headers?.slice(0, 14).join(" · ") || "—"}. ${result.madGuessed ? `Heure MAD déduite de la ligne pour ${result.madGuessed} vol(s) : vérifiez la colonne « MAD » ci-dessous.` : ""}</div>`
    : result.madMissing ? `<div class="error-msg">${result.madMissing} vol(s) sans Heure MAD : leur chargement sera calculé sur l'heure de départ.</div>` : "";
  const si = result.shiftInfo || { missing: [], fallback: [] };
  const shiftWarn = si.missing.length || si.fallback.length
    ? `<div class="error-msg">Shift : ${si.missing.length ? `vols repères introuvables pour ${si.missing.join(", ")}. ` : ""}${si.fallback.length ? `${si.fallback.length} vol(s) hors des plages repères (calculés d'après l'heure de chargement) : ${si.fallback.slice(0, 12).join(" · ")}${si.fallback.length > 12 ? " …" : ""}.` : ""}</div>` : "";
  const seen = {}; result.flights.forEach((f) => { (seen[f.flightNumber] = seen[f.flightNumber] || []).push(f); });
  const dups = Object.entries(seen).filter(([, v]) => v.length > 1);
  const dupWarn = dups.length
    ? `<div class="error-msg">Numéro de vol en double dans le fichier : ${dups.map(([n, v]) => `${n} (${v.map((f) => `${f.heureDepart} ${f.aircraftType || "?"}`).join(" / ")})`).join(" · ")}. Un vol est identifié par sa date + son numéro : seule la <b>dernière</b> ligne sera conservée à l'import.</div>`
    : "";
  const spml = (f) => ["yCl", "cCl"].map((k) => {
    const list = f.imported[k].specialMeals || [];
    return list.length ? `${k === "yCl" ? "Y" : "C"}: ${list.map((s) => `${s.code} ${s.allerPrevu ?? "–"}/${s.retourPrevu ?? "–"}${s.fromNote ? "*" : ""}`).join(", ")}` : "";
  }).filter(Boolean).join(" · ") || "—";
  const spmlInfo = result.noteSpmlFlights
    ? `<div class="ok-msg">SPML lus dans la colonne Note : ${result.noteSpmlFlights} vol(s) (repérés par * dans la colonne « Special Meals Aller/Retour »).</div>` : "";
  preview.innerHTML = `
    ${result.fromPdf ? `<div class="ok-msg">Fichier PDF lu. Vérifiez l'aperçu ci-dessous avant d'importer.</div>` : ""}
    ${warn}
    ${madWarn}
    ${shiftWarn}
    ${dupWarn}
    ${spmlInfo}
    <div class="panel">
      <div class="panel-title">Aperçu — ${result.flights.length} vol(s) AT détecté(s) ${result.date ? `pour le ${result.date}` : ""}</div>
      <table class="data-table">
        <thead><tr><th>Vol</th><th>Départ</th><th>MAD</th><th>Chargt</th><th>Shift</th><th>Type</th><th>Catégorie</th><th>Code C/CL</th><th>Code Y/CL</th><th>Special Meals (Aller/Retour)</th></tr></thead>
        <tbody>
          ${result.flights.map((f) => `
            <tr>
              <td class="mono">${f.flightNumber}</td>
              <td class="mono">${f.heureDepart}</td>
              <td class="mono">${f.heureMAD || "—"}</td>
              <td class="mono">${loadTime(f) || "—"}</td>
              <td>${shiftLabel(flightShift(f)) || "—"}${f.recapShift ? "" : " *"}</td>
              <td class="mono">${f.aircraftType || "—"}</td>
              <td>${(f.aircraftCategory || "").replace("_"," ")}</td>
              <td>${f.imported.cCl.codePrestation || "—"}</td>
              <td>${f.imported.yCl.codePrestation || "—"}</td>
              <td class="muted" style="font-size:12px">${spml(f)}</td>
            </tr>`).join("")}
        </tbody>
      </table>
    </div>
    <button class="btn amber" id="confirmBtn">Confirmer et importer ${result.flights.length} vol(s) AT</button>
  `;
  document.getElementById("confirmBtn").addEventListener("click", doImport);
}

async function doImport() {
  const btn = document.getElementById("confirmBtn");
  btn.disabled = true;
  btn.textContent = "Import en cours…";
  try {
    const res = await saveRecapUpload({ fileName, date: parsedResult.date, flights: parsedResult.flights }, profile);
    msg.innerHTML = `<div class="ok-msg">Import terminé — ${res.created} vol(s) créé(s), ${res.updated} mis à jour. Les valeurs déjà saisies par les contrôleurs n'ont pas été modifiées.</div>`;
    preview.innerHTML = `<a class="btn ghost" href="../flights.html">Voir les vols</a>`;
  } catch (err) {
    msg.innerHTML = `<div class="error-msg">Échec de l'import : ${err.message}</div>`;
    btn.disabled = false;
    btn.textContent = "Réessayer";
  }
}
