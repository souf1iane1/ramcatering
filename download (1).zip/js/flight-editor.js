// Admin flight editor: edit an imported flight, or add a new one by hand.
//   openFlightEditor({ flight, defaultDate, onSaved })   flight = null -> "Ajouter un vol"
// Fields follow the flight sheet: header (Heure Dép., Heure MAD, Shift, Chargement, Type A/C, Catégorie, Immat.)
// then PEQ / C/CL / Y/CL blocks. Shift and Chargement are computed from Heure MAD (read-only).
import { icon } from "./icons.js";
import { updateFlight, createFlight } from "./api.js";
import { showToast } from "./auth.js";
import { flightShift, shiftLabel, loadTime } from "./shifts.js";
import { classifyAircraft } from "./excel-parser.js";

const esc = (v) => String(v ?? "").replace(/[&<>"']/g, (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]));
const val = (v) => (v === null || v === undefined ? "" : v);
const CATS = [["", "—"], ["LONG_COURRIER", "Long courrier"], ["MOYEN_COURRIER", "Moyen courrier"], ["COURT_COURRIER", "Court courrier"]];

function field(id, label, value, { type = "text", ro = false, ph = "", hint = "", wide = false } = {}) {
  return `<label class="fe-field${wide ? " wide" : ""}" for="fe-${id}"><span>${label}</span>
    <input id="fe-${id}" data-k="${id}" type="${type}" ${type === "number" ? 'min="0" step="1" inputmode="numeric"' : ""} value="${esc(value)}" placeholder="${esc(ph)}" ${ro ? "readonly" : ""}>
    ${hint ? `<small>${hint}</small>` : ""}</label>`;
}

/** Special Meals of one cabin: rows of [code][Aller][Retour][×] + "Ajouter". */
function smRow(s = {}) {
  return `<div class="fe-sm-row">
    <input class="sm-code" type="text" maxlength="20" placeholder="Code (CHML, VGML…)" value="${esc(s.code)}" aria-label="Code Special Meal">
    <input class="sm-a" type="number" min="0" step="1" inputmode="numeric" placeholder="Aller" value="${esc(val(s.allerPrevu))}" aria-label="Aller">
    <input class="sm-r" type="number" min="0" step="1" inputmode="numeric" placeholder="Retour" value="${esc(val(s.retourPrevu))}" aria-label="Retour">
    <button type="button" class="fe-sm-del" aria-label="Supprimer">×</button>
  </div>`;
}
const smBlock = (cab, list) => `<div class="fe-sm" data-sm="${cab}">
  <div class="fe-sm-title">Special Meals</div>
  <div class="fe-sm-rows">${(list || []).map(smRow).join("")}</div>
  <button type="button" class="btn ghost small fe-sm-add">+ Special Meal</button>
</div>`;

export function openFlightEditor({ flight = null, defaultDate = "", onSaved = () => {} } = {}) {
  const isNew = !flight;
  const f = flight || {};
  const im = f.imported || {};
  const c = f.controller || {};
  const peq = im.peq || {}, cCl = im.cCl || {}, yCl = im.yCl || {};

  document.getElementById("feOverlay")?.remove();
  const ov = document.createElement("div");
  ov.id = "feOverlay"; ov.className = "fe-overlay";
  ov.innerHTML = `
  <div class="fe-modal" role="dialog" aria-modal="true" aria-labelledby="feTitle">
    <div class="fe-head">
      <h2 id="feTitle">${icon(isNew ? "plus" : "edit", 18)} ${isNew ? "Ajouter un vol" : `Modifier le vol ${esc(f.flightNumber)} — ${esc(f.date || "")}`}</h2>
      <button type="button" class="fe-x" data-close aria-label="Fermer">${icon("x", 18)}</button>
    </div>
    <div class="fe-body">
      ${isNew ? `<div class="fe-section"><div class="fe-title">Vol</div><div class="fe-grid">
        ${field("flightNumber", "Numéro de vol", "", { ph: "AT208" })}
        ${field("date", "Date du Récap", defaultDate, { type: "date" })}
      </div></div>` : ""}

      <div class="fe-section"><div class="fe-title">Informations du vol</div><div class="fe-grid">
        ${field("heureDepart", "Heure Dép.", f.heureDepart, { type: "time" })}
        ${field("heureMAD", "Heure MAD", f.heureMAD, { type: "time" })}
        <div class="fe-field"><span>Shift</span><output id="fe-shift" class="fe-out">—</output><small>automatique (selon l'heure de chargement)</small></div>
        <div class="fe-field"><span>Chargement (MAD+1h, sauf 786-789)</span><output id="fe-load" class="fe-out">—</output><small>automatique</small></div>
        ${field("aircraftType", "Type A/C", f.aircraftType, { ph: "73H, 788, 7M8…" })}
        <label class="fe-field" for="fe-aircraftCategory"><span>Catégorie</span>
          <select id="fe-aircraftCategory" data-k="aircraftCategory">${CATS.map(([v, l]) => `<option value="${v}" ${f.aircraftCategory === v ? "selected" : ""}>${l}</option>`).join("")}</select></label>
        ${field("numEnregistrement", "Immat.", f.numEnregistrement, { ph: "RGH" })}
      </div></div>

      <div class="fe-cols">
        <div class="fe-section"><div class="fe-title">PEQ</div><div class="fe-grid one">
          ${field("peq.codePrestation", "Code Prestation", peq.codePrestation, { ph: "BF99, BF99 CDB, DF99" })}
          ${field("peq.allerPrevu", "NBR PNC /A", val(peq.allerPrevu), { type: "number" })}
          ${field("peq.retourPrevu", "NBR PNC /R", val(peq.retourPrevu), { type: "number" })}
        </div></div>
        <div class="fe-section"><div class="fe-title">C/CL</div><div class="fe-grid one">
          ${field("cCl.codePrestation", "Code Prestation", cCl.codePrestation)}
          ${field("cCl.paxAllerReel", "PAX Aller (réel)", val(c.paxAllerReelCcl), { type: "number" })}
          ${field("cCl.paxAllerPrevu", "Prévu Aller", val(cCl.paxAllerPrevu), { type: "number" })}
          ${field("cCl.paxRetourReel", "PAX Retour (réel)", val(c.paxRetourReelCcl), { type: "number" })}
          ${field("cCl.paxRetourPrevu", "Prévu Retour", val(cCl.paxRetourPrevu), { type: "number" })}
        </div>${smBlock("cCl", cCl.specialMeals)}</div>
        <div class="fe-section"><div class="fe-title">Y/CL</div><div class="fe-grid one">
          ${field("yCl.codePrestation", "Code Prestation", yCl.codePrestation)}
          ${field("yCl.paxAllerReel", "PAX Aller (réel)", val(c.paxAllerReel), { type: "number" })}
          ${field("yCl.paxAllerPrevu", "Prévu Aller", val(yCl.paxAllerPrevu), { type: "number" })}
          ${field("yCl.paxRetourReel", "PAX Retour (réel)", val(c.paxRetourReel), { type: "number" })}
          ${field("yCl.paxRetourPrevu", "Prévu Retour", val(yCl.paxRetourPrevu), { type: "number" })}
        </div>${smBlock("yCl", yCl.specialMeals)}</div>
      </div>
      <div id="feErr" class="error-msg" hidden></div>
    </div>
    <div class="fe-foot">
      <button type="button" class="btn ghost" data-close>Annuler</button>
      <button type="button" class="btn amber" id="feSave">${icon("check", 16)} ${isNew ? "Ajouter le vol" : "Enregistrer"}</button>
    </div>
  </div>`;
  document.body.appendChild(ov);
  const $ = (k) => ov.querySelector(`[data-k="${k}"]`);
  const close = () => { ov.remove(); document.removeEventListener("keydown", onKey); };
  const onKey = (e) => { if (e.key === "Escape") close(); };
  document.addEventListener("keydown", onKey);
  ov.addEventListener("mousedown", (e) => { if (e.target === ov) close(); });
  ov.querySelectorAll("[data-close]").forEach((b) => b.addEventListener("click", close));

  // live Shift + Chargement from Heure MAD (falls back on Heure Dép., like the rest of the app)
  const date = () => (isNew ? $("date")?.value : f.date) || "";
  const refresh = () => {
    const probe = { heureMAD: $("heureMAD").value, heureDepart: $("heureDepart").value, aircraftType: $("aircraftType").value, date: date() };
    ov.querySelector("#fe-load").textContent = loadTime(probe) || "—";
    ov.querySelector("#fe-shift").textContent = loadTime(probe) ? shiftLabel(flightShift(probe, date() || undefined)) : "—";
  };
  ["heureMAD", "heureDepart", "aircraftType", "date"].forEach((k) => $(k)?.addEventListener("input", refresh));
  refresh();
  // suggest the category from the aircraft type when none is chosen
  $("aircraftType").addEventListener("change", () => {
    const cat = $("aircraftCategory");
    if (!cat.value) { const g = classifyAircraft($("aircraftType").value); if (g && [...cat.options].some((o) => o.value === g)) cat.value = g; }
  });

  ov.querySelectorAll(".fe-sm").forEach((box) => {
    box.querySelector(".fe-sm-add").addEventListener("click", () => {
      box.querySelector(".fe-sm-rows").insertAdjacentHTML("beforeend", smRow());
      box.querySelector(".fe-sm-row:last-child .sm-code").focus();
    });
    box.addEventListener("click", (e) => { if (e.target.closest(".fe-sm-del")) e.target.closest(".fe-sm-row").remove(); });
  });
  const specials = (cab) => [...ov.querySelectorAll(`.fe-sm[data-sm="${cab}"] .fe-sm-row`)].map((r) => {
    const n = (sel) => { const v = r.querySelector(sel).value.trim(); return v === "" ? null : Number(v); };
    return { code: r.querySelector(".sm-code").value.trim().toUpperCase(), allerPrevu: n(".sm-a"), retourPrevu: n(".sm-r") };
  }).filter((x) => x.code);
  const num = (k) => { const v = $(k).value.trim(); return v === "" ? null : Number(v); };
  const txt = (k) => $(k).value.trim();
  ov.querySelector("#feSave").addEventListener("click", async (e) => {
    const err = ov.querySelector("#feErr"); err.hidden = true;
    const patch = {
      core: {
        heureDepart: txt("heureDepart"), heureMAD: txt("heureMAD"), aircraftType: txt("aircraftType"),
        aircraftCategory: $("aircraftCategory").value, numEnregistrement: txt("numEnregistrement"),
        imported: {
          peq: { codePrestation: txt("peq.codePrestation"), allerPrevu: num("peq.allerPrevu"), retourPrevu: num("peq.retourPrevu") },
          cCl: { codePrestation: txt("cCl.codePrestation"), paxAllerPrevu: num("cCl.paxAllerPrevu"), paxRetourPrevu: num("cCl.paxRetourPrevu"), specialMeals: specials("cCl") },
          yCl: { codePrestation: txt("yCl.codePrestation"), paxAllerPrevu: num("yCl.paxAllerPrevu"), paxRetourPrevu: num("yCl.paxRetourPrevu"), specialMeals: specials("yCl") },
        },
      },
      controller: {
        paxAllerReelCcl: num("cCl.paxAllerReel"), paxRetourReelCcl: num("cCl.paxRetourReel"),
        paxAllerReel: num("yCl.paxAllerReel"), paxRetourReel: num("yCl.paxRetourReel"),
      },
    };
    if (isNew) {
      patch.flightNumber = txt("flightNumber").toUpperCase().replace(/\s+/g, "");
      patch.date = $("date").value;
      if (!/^AT\d{3,4}$/.test(patch.flightNumber)) { err.textContent = "Numéro de vol invalide (ex. AT208)."; err.hidden = false; return; }
      if (!patch.date) { err.textContent = "Choisissez la date du Récap."; err.hidden = false; return; }
    }
    const btn = e.currentTarget; btn.disabled = true;
    try {
      const saved = isNew ? await createFlight(patch) : await updateFlight(f.id, patch);
      showToast(isNew ? `Vol ${saved.flightNumber} ajouté.` : `Vol ${saved.flightNumber} modifié.`, "success", 3000);
      close();
      onSaved(saved, isNew);
    } catch (ex) {
      err.textContent = ex.message || "Enregistrement impossible."; err.hidden = false; btn.disabled = false;
    }
  });
  setTimeout(() => (isNew ? $("flightNumber") : $("heureDepart")).focus(), 30);
}
