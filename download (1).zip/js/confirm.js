// Styled confirmation dialog (replaces the browser's plain confirm()).
//   if (!(await confirmDialog({ title, message, items, confirmText, danger }))) return;
import { icon } from "./icons.js";

const esc = (v) => String(v ?? "").replace(/[&<>"']/g, (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]));

export function confirmDialog({ title = "Confirmer", message = "", items = [], confirmText = "Confirmer", cancelText = "Annuler", danger = false } = {}) {
  return new Promise((resolve) => {
    document.getElementById("cfOverlay")?.remove();
    const ov = document.createElement("div");
    ov.id = "cfOverlay"; ov.className = "cf-overlay";
    ov.innerHTML = `
      <div class="cf-box" role="alertdialog" aria-modal="true" aria-labelledby="cfTitle" aria-describedby="cfMsg">
        <div class="cf-head${danger ? " danger" : ""}">
          <span class="cf-ico">${icon(danger ? "trash" : "check", 22)}</span>
          <h2 id="cfTitle">${esc(title)}</h2>
        </div>
        <div class="cf-body">
          <p id="cfMsg">${esc(message)}</p>
          ${items.length ? `<div class="cf-items">${items.slice(0, 30).map((i) => `<span>${esc(i)}</span>`).join("")}${items.length > 30 ? `<span class="more">+${items.length - 30}</span>` : ""}</div>` : ""}
          ${danger ? `<p class="cf-warn">Cette action est irréversible.</p>` : ""}
        </div>
        <div class="cf-foot">
          <button type="button" class="btn ghost" data-r="0">${esc(cancelText)}</button>
          <button type="button" class="btn ${danger ? "danger" : "amber"}" data-r="1">${esc(confirmText)}</button>
        </div>
      </div>`;
    document.body.appendChild(ov);
    const done = (v) => { document.removeEventListener("keydown", onKey, true); ov.remove(); resolve(v); };
    const onKey = (e) => {
      if (e.key === "Escape") { e.preventDefault(); done(false); }
      else if (e.key === "Enter" && document.activeElement?.dataset?.r !== "0") { e.preventDefault(); done(true); }
    };
    document.addEventListener("keydown", onKey, true);
    ov.addEventListener("mousedown", (e) => { if (e.target === ov) done(false); });
    ov.querySelectorAll("[data-r]").forEach((b) => b.addEventListener("click", () => done(b.dataset.r === "1")));
    ov.querySelector('[data-r="0"]').focus(); // safest default for destructive actions
  });
}
