import { requireAuth, showToast } from "./auth.js";
import { icon } from "./icons.js";
import { exportFlightsXlsx, exportFlightsPdf } from "./export.js";
import { listFlights, flightStatus, hasRetourLeg } from "./data.js";
import { assignDay, flightDateOf } from "./assign.js";
import { sameController } from "./shifts.js";

const { profile } = await requireAuth("dashboard.html");
const content = document.getElementById("content");

const flights = await listFlights();
flights.forEach((f) => (f.status = flightStatus(f)));

if (profile.role === "controller") {
  await renderControllerView();
} else {
  renderAdminView();
}

function renderAdminView() {
  const total = flights.length;
  const completed = flights.filter((f) => f.status === "completed").length;
  const pending = total - completed;

  content.innerHTML = `
    <h1>Check-list</h1>
    <p class="subtitle">Vue d'ensemble des vols du jour</p>
    <div class="stat-row">
      <div class="stat"><div class="num">${total}</div><div class="lbl">Vols</div></div>
      <div class="stat"><div class="num">${completed}</div><div class="lbl">Complétés</div></div>
      <div class="stat"><div class="num">${pending}</div><div class="lbl">En attente</div></div>
    </div>
    <div class="action-row">
      <a class="btn amber" href="admin/upload.html">Upload Récap</a>
      <a class="btn ghost" href="flights.html">Voir les vols</a>
      <button class="btn ghost" id="exportBtn">Exporter (CSV)</button>
      <button class="btn ghost" id="exportXlsBtn">Exporter (Excel)</button>
      <button class="btn ghost" id="exportPdfBtn">Exporter (PDF)</button>
    </div>
    <div class="panel">
      <div class="panel-title">Derniers vols</div>
      <div class="flight-list">${flights.slice(0, 8).map(rowHtml).join("") || `<div class="empty-state">Aucun vol importé pour l'instant.</div>`}</div>
    </div>
  `;
  document.getElementById("exportBtn").addEventListener("click", () => exportCsv(flights));
  for (const [id, fn] of [["exportXlsBtn", exportFlightsXlsx], ["exportPdfBtn", exportFlightsPdf]]) {
    document.getElementById(id).addEventListener("click", async (e) => {
      const b = e.currentTarget; b.disabled = true;
      try { await fn(flights); } catch (err) { console.error(err); showToast("Export impossible : " + err.message, "error", 5000); }
      finally { b.disabled = false; }
    });
  }
}

async function renderControllerView() {
  // Today's flights (or the newest day with flights), split automatically from the planning.
  const today = flightDateOf({ date: new Date() });
  const days = [...new Set(flights.map(flightDateOf).filter(Boolean))].sort().reverse();
  const day = days.includes(today) ? today : days[0] || "";
  const ofDay = flights.filter((f) => flightDateOf(f) === day);
  await assignDay(ofDay, day);
  const hasAssign = ofDay.some((f) => f.assignedTo);
  const mine = hasAssign ? ofDay.filter((f) => sameController(f.assignedTo, profile.name)) : ofDay;
  content.innerHTML = `
    <h1>Mes vols</h1>
    <p class="subtitle">${day ? day.split("-").reverse().join("/") + " · " : ""}Ouvrez un vol pour saisir les valeurs réelles</p>
    <div class="flight-list">${mine.map(rowHtml).join("") || `<div class="empty-state">Aucun vol affecté pour l'instant (repos ou planning non importé).</div>`}</div>
  `;
}

function rowHtml(f) {
  const legs = `
    <span class="${f.controller?.paxAllerReel != null ? "done" : ""}">A${f.controller?.paxAllerReel != null ? icon("check", 12) : icon("circle", 12)}</span>
    ${hasRetourLeg(f) ? `<span class="${f.controller?.paxRetourReel != null ? "done" : ""}">R${f.controller?.paxRetourReel != null ? icon("check", 12) : icon("circle", 12)}</span>` : ""}`;
  return `
    <a class="flight-row" href="flight.html?id=${encodeURIComponent(f.id)}">
      <span class="flight-num">${f.flightNumber}</span>
      <span class="flight-meta">${f.date || ""} · ${f.heureDepart || "--:--"} · ${f.aircraftType || "?"}</span>
      <span class="flight-cat">${(f.aircraftCategory || "").replace("_", " ")}</span>
      <span class="leg-marks">${legs}</span>
      ${profile.role === "admin" && f.updatedByName ? `<span class="controller-name">${icon("user", 13)} ${f.updatedByName}</span>` : ""}
      <span class="status-badge ${f.status}">${f.status.replace("_", " ")}</span>
    </a>`;
}

function exportCsv(list) {
  const headers = ["flightNumber","date","aircraftType","aircraftCategory","status","paxAllerPrevu(YC)","paxAllerReel","paxRetourPrevu(YC)","paxRetourReel"];
  const rows = list.map((f) => [
    f.flightNumber, f.date || "", f.aircraftType || "", f.aircraftCategory || "", f.status,
    f.imported?.yCl?.paxAllerPrevu ?? "", f.controller?.paxAllerReel ?? "",
    f.imported?.yCl?.paxRetourPrevu ?? "", f.controller?.paxRetourReel ?? "",
  ]);
  const csv = [headers, ...rows].map((r) => r.map((v) => `"${String(v).replace(/"/g, '""')}"`).join(",")).join("\n");
  const blob = new Blob([csv], { type: "text/csv;charset=utf-8;" });
  const a = document.createElement("a");
  a.href = URL.createObjectURL(blob);
  a.download = `check-list-export-${new Date().toISOString().slice(0, 10)}.csv`;
  a.click();
}
