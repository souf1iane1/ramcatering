// "My Planning" (controllers): my shift for every day of the month, taken from the planning the admin
// imported, plus the flights assigned to me on the selected day.
import { requireAuth } from "./auth.js";
import { icon } from "./icons.js";
import { listPlanning } from "./api.js";
import { listFlights, flightStatus, hasRetourLeg } from "./data.js";
import { assignDay, flightDateOf } from "./assign.js";
import { SHIFTS, SHIFT_ORDER, sameController, loadTime, sortInShift } from "./shifts.js";

const { profile } = await requireAuth("my-planning.html");
const content = document.getElementById("content");

const esc = (v) => String(v ?? "").replace(/[&<>"']/g, (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]));
const pad = (n) => String(n).padStart(2, "0");
const isoOf = (y, m, d) => `${y}-${pad(m + 1)}-${pad(d)}`;                    // m = 0..11
const todayIso = flightDateOf({ date: new Date() });                           // local date
const cap = (s) => s.charAt(0).toUpperCase() + s.slice(1);
const WEEKDAYS = ["Lun", "Mar", "Mer", "Jeu", "Ven", "Sam", "Dim"];
const LABEL = { morning: "Matin", afternoon: "Après-midi", night: "Nuit", off: "Repos" };
const SHORT = { morning: "M", afternoon: "AM", night: "N", off: "R" };

// ---- data
let planning = new Map();   // date -> { morning:[], afternoon:[], night:[], off:[] }
let loadError = "";
try {
  (await listPlanning()).forEach((d) => planning.set(d.date, d));
} catch (e) { loadError = e.message; }

/** My shift on `date`: "morning" | "afternoon" | "night" | "off" | null (not in the planning that day). */
function myShift(date) {
  const d = planning.get(date);
  if (!d) return null;
  const mine = (names) => (names || []).some((n) => sameController(profile.name, n));
  for (const k of SHIFT_ORDER) if (mine(d[k])) return k;
  return mine(d.off) ? "off" : null;
}
const anyMatch = [...planning.keys()].some((d) => myShift(d));

// ---- state
const start = todayIso.split("-").map(Number);
let view = { y: start[0], m: start[1] - 1 };
let selected = todayIso;

// ---- rendering
function monthDays() {
  const first = new Date(view.y, view.m, 1);
  const lead = (first.getDay() + 6) % 7;                    // Monday-first grid
  const count = new Date(view.y, view.m + 1, 0).getDate();
  return { lead, count };
}

function summaryHtml() {
  const { count } = monthDays();
  const tot = { morning: 0, afternoon: 0, night: 0, off: 0 };
  for (let d = 1; d <= count; d++) { const s = myShift(isoOf(view.y, view.m, d)); if (s) tot[s]++; }
  const worked = tot.morning + tot.afternoon + tot.night;
  return `<div class="mp-summary">
    <span class="mp-chip morning"><b>${tot.morning}</b> Matin</span>
    <span class="mp-chip afternoon"><b>${tot.afternoon}</b> Après-midi</span>
    <span class="mp-chip night"><b>${tot.night}</b> Nuit</span>
    <span class="mp-chip off"><b>${tot.off}</b> Repos</span>
    <span class="mp-chip total"><b>${worked}</b> jour${worked > 1 ? "s" : ""} travaillé${worked > 1 ? "s" : ""}</span>
  </div>`;
}

function gridHtml() {
  const { lead, count } = monthDays();
  const cells = [];
  for (let i = 0; i < lead; i++) cells.push(`<span class="mp-cell blank"></span>`);
  for (let d = 1; d <= count; d++) {
    const iso = isoOf(view.y, view.m, d);
    const s = myShift(iso);
    const cls = ["mp-cell", s || "none", iso === todayIso ? "today" : "", iso === selected ? "selected" : ""].join(" ");
    const label = `${d} ${new Date(view.y, view.m, d).toLocaleDateString("fr-FR", { month: "long" })}${s ? " — " + LABEL[s] : ""}`;
    cells.push(`<button type="button" class="${cls}" data-date="${iso}" aria-label="${esc(label)}" aria-pressed="${iso === selected}">
      <span class="mp-day">${d}</span>${s ? `<span class="mp-badge ${s}">${SHORT[s]}</span>` : ""}</button>`);
  }
  return `<div class="mp-grid" role="group" aria-label="Calendrier">
    ${WEEKDAYS.map((w) => `<span class="mp-wd">${w}</span>`).join("")}${cells.join("")}</div>`;
}

function upcomingHtml() {
  const t = new Date(); t.setHours(12, 0, 0, 0);
  const items = [];
  for (let i = 0; i < 7; i++) {
    const d = new Date(t); d.setDate(t.getDate() + i);
    const iso = flightDateOf({ date: d }); const s = myShift(iso);
    items.push(`<button type="button" class="mp-up ${s || "none"} ${iso === selected ? "selected" : ""}" data-date="${iso}">
      <span class="mp-up-d">${i === 0 ? "Auj." : cap(d.toLocaleDateString("fr-FR", { weekday: "short" }).replace(".", ""))}</span>
      <span class="mp-up-n">${d.getDate()}</span>
      <span class="mp-up-s">${s ? LABEL[s] : "—"}</span></button>`);
  }
  return `<div class="mp-upcoming" aria-label="7 prochains jours">${items.join("")}</div>`;
}

function monthTitle() {
  return cap(new Date(view.y, view.m, 1).toLocaleDateString("fr-FR", { month: "long", year: "numeric" }));
}

function render() {
  const noMatch = !loadError && !anyMatch
    ? `<div class="panel mp-note">Aucun planning trouvé pour <b>${esc(profile.name || profile.email)}</b>. Vérifiez que votre nom correspond à celui du planning, ou demandez à l'administrateur d'importer le planning.</div>` : "";
  content.innerHTML = `
    <h1>Mon planning</h1>
    <p class="subtitle">${esc(profile.name || profile.email)} · touchez un jour pour voir le détail</p>
    ${loadError ? `<div class="error-msg">Impossible de charger le planning : ${esc(loadError)}</div>` : ""}
    ${noMatch}
    ${upcomingHtml()}
    <div class="panel mp-panel">
      <div class="mp-head">
        <button type="button" class="btn ghost small" id="mpPrev" aria-label="Mois précédent">‹</button>
        <div class="mp-title">${monthTitle()}</div>
        <button type="button" class="btn ghost small" id="mpNext" aria-label="Mois suivant">›</button>
        <button type="button" class="btn ghost small" id="mpToday">Aujourd'hui</button>
      </div>
      ${summaryHtml()}
      ${gridHtml()}
      <div class="mp-legend">
        <span><i class="mp-badge morning">M</i> Matin ${SHIFTS.morning.range}</span>
        <span><i class="mp-badge afternoon">AM</i> Après-midi ${SHIFTS.afternoon.range}</span>
        <span><i class="mp-badge night">N</i> Nuit ${SHIFTS.night.range}</span>
        <span><i class="mp-badge off">R</i> Repos</span>
      </div>
    </div>
    <div class="panel" id="mpDetail"></div>`;
  renderDetail();
}

// ---- selected day: shift + my flights
let flightsCache = null;
let detailToken = 0;

async function renderDetail() {
  const box = document.getElementById("mpDetail");
  if (!box) return;
  const token = ++detailToken;
  const s = myShift(selected);
  const dateLabel = cap(new Date(selected + "T12:00:00").toLocaleDateString("fr-FR", { weekday: "long", day: "numeric", month: "long", year: "numeric" }));
  const head = `<div class="panel-title">${esc(dateLabel)}</div>
    <p class="mp-shift ${s || "none"}">${s ? `<span class="mp-badge ${s}">${SHORT[s]}</span> ${LABEL[s]}${s !== "off" ? ` <small>${SHIFTS[s].range}</small>` : ""}` : "Pas de planning pour ce jour"}</p>`;
  box.innerHTML = head + `<div class="mp-flights muted">Chargement des vols…</div>`;
  if (s === "off") { box.querySelector(".mp-flights").textContent = "Jour de repos."; return; }

  let html;
  try {
    flightsCache ??= await listFlights();
    const ofDay = flightsCache.filter((f) => flightDateOf(f) === selected);
    if (!ofDay.length) html = `<div class="empty-state">Aucun vol importé pour ce jour.</div>`;
    else {
      await assignDay(ofDay, selected);
      const hasAssign = ofDay.some((f) => f.assignedTo);
      const mine = sortInShift(ofDay.filter((f) => hasAssign && sameController(f.assignedTo, profile.name)), s || "morning");
      html = mine.length
        ? `<div class="flight-list">${mine.map(flightRow).join("")}</div>`
        : `<div class="empty-state">${hasAssign ? "Aucun vol ne vous est affecté ce jour." : "Répartition des vols pas encore disponible pour ce jour."}</div>`;
    }
  } catch (e) { html = `<div class="error-msg">Impossible de charger les vols : ${esc(e.message)}</div>`; }
  if (token !== detailToken) return;                       // a newer selection took over
  box.querySelector(".mp-flights").outerHTML = `<div class="mp-flights">${html}</div>`;
}

function flightRow(f) {
  const st = flightStatus(f);
  const aller = f.controller?.paxAllerReel != null, retour = f.controller?.paxRetourReel != null;
  return `<a class="flight-row" href="flight.html?id=${encodeURIComponent(f.id)}">
    <span class="flight-num">${esc(f.flightNumber)}</span>
    <span class="flight-meta">${esc(loadTime(f) || "--:--")} · ${esc(f.aircraftType || "?")}</span>
    <span class="flight-cat">${esc((f.aircraftCategory || "").replace("_", " "))}</span>
    <span class="leg-marks"><span class="${aller ? "done" : ""}">A${aller ? icon("check", 12) : icon("circle", 12)}</span>${hasRetourLeg(f) ? `<span class="${retour ? "done" : ""}">R${retour ? icon("check", 12) : icon("circle", 12)}</span>` : ""}</span>
    <span class="status-badge ${esc(st)}">${esc(st.replace("_", " "))}</span>
  </a>`;
}

// ---- events (delegated; the page is re-rendered as a whole)
content.addEventListener("click", (e) => {
  const day = e.target.closest("[data-date]");
  if (day) {
    selected = day.dataset.date;
    const [y, m] = selected.split("-").map(Number);
    view = { y, m: m - 1 };
    render();
    document.getElementById("mpDetail")?.scrollIntoView({ block: "nearest", behavior: "smooth" });
    return;
  }
  const move = (delta) => {
    const d = new Date(view.y, view.m + delta, 1);
    view = { y: d.getFullYear(), m: d.getMonth() };
    const inThisMonth = selected.startsWith(`${view.y}-${pad(view.m + 1)}`);
    if (!inThisMonth) selected = todayIso.startsWith(`${view.y}-${pad(view.m + 1)}`) ? todayIso : isoOf(view.y, view.m, 1);
    render();
  };
  if (e.target.closest("#mpPrev")) move(-1);
  else if (e.target.closest("#mpNext")) move(1);
  else if (e.target.closest("#mpToday")) { selected = todayIso; view = { y: start[0], m: start[1] - 1 }; render(); }
});

render();
