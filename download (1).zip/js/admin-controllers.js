import { requireAuth } from "./auth.js";
import { icon } from "./icons.js";
import { listUsers, listShiftPlans } from "./api.js";
import { ringHtml } from "./ring.js";
import { listFlights, flightStatus, hasRetourLeg } from "./data.js";

await requireAuth("admin/controllers.html");

const search = document.getElementById("controllerSearch");
const datalist = document.getElementById("controllerNames");
const summary = document.getElementById("summary");
const dateInput = document.getElementById("controllerDate");
document.getElementById("clearDate").addEventListener("click", () => { dateInput.value = ""; render(); });
dateInput.addEventListener("input", render);
dateInput.addEventListener("change", render);
const list = document.getElementById("list");

// Every registered "controller" account — used to power the suggestions list, so the
// admin can pick a known name (Soufiane, Hiba, …) without having to type it out fully.
// The search itself still works against whatever name is actually stamped on a flight
// (updatedByName), so it also finds anyone who has ever controlled a flight, even a
// former user no longer in this list.
let controllerNames = [];
try {
  controllerNames = (await listUsers("controller")).map((u) => u.name).filter(Boolean);
} catch {
  // Falls back gracefully: if the composite query/index isn't available, the datalist
  // just stays empty — free-text search below still works.
}
datalist.innerHTML = controllerNames.map((n) => `<option value="${escAttr(n)}"></option>`).join("");

let flights = await listFlights();
flights = flights.filter((f) => /^AT\d{3,4}$/i.test(String(f.flightNumber || "").replace(/\s+/g, "")));
flights.forEach((f) => (f.status = flightStatus(f)));

// Flights assigned to each controller by the shift plans (shiftPlans docs: assignments { flightNumber: name }).
const assigned = []; // { id: "2026-10-05_AT208", name }
try {
  (await listShiftPlans()).forEach((p) => { Object.entries(p.assignments || {}).forEach(([fn, name]) => assigned.push({ id: `${p.date}_${fn}`, name })); });
} catch (e) { console.warn("shiftPlans:", e); }
const flightById = new Map(flights.map((f) => [f.id, f]));

search.addEventListener("input", render);
render();

function normalize(s) {
  return String(s || "")
    .normalize("NFD").replace(/[\u0300-\u036f]/g, "") // strip accents
    .toLowerCase().trim();
}

function getFlightDate(f) {
  const raw = f?.date;
  if (raw && typeof raw === "object" && typeof raw.toDate === "function") return toISO(raw.toDate());
  if (raw instanceof Date) return toISO(raw);
  const v = String(raw || "").trim();
  if (/^\d{4}-\d{2}-\d{2}$/.test(v)) return v;
  const m1 = v.match(/^(\d{2})[\/-](\d{2})[\/-](\d{4})$/);
  if (m1) return `${m1[3]}-${m1[2]}-${m1[1]}`;
  const m2 = String(f?.id || "").match(/^(\d{4}-\d{2}-\d{2})_AT\d{3,4}$/i);
  return m2 ? m2[1] : "";
}
function toISO(d) {
  return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, "0")}-${String(d.getDate()).padStart(2, "0")}`;
}
function displayDate(iso) {
  const m = String(iso || "").match(/^(\d{4})-(\d{2})-(\d{2})$/);
  return m ? `${m[3]}/${m[2]}/${m[1]}` : (iso || "");
}

function render() {
  const q = normalize(search.value);

  if (!q) {
    summary.innerHTML = "";
    list.innerHTML = `<div class="empty-state">Tapez ou sélectionnez un nom de contrôleur pour voir ses vols.</div>`;
    return;
  }

  const day = dateInput.value; // "" = all dates
  const onDay = (f) => !day || getFlightDate(f) === day;
  const matches = flights
    .filter((f) => onDay(f) && normalize(f.updatedByName).includes(q))
    .sort((a, b) => getFlightDate(b).localeCompare(getFlightDate(a)) || String(a.flightNumber).localeCompare(String(b.flightNumber)));

  // Share of the flights assigned to this controller that are already controlled (status "completed").
  const mine = assigned.filter((x) => normalize(x.name).includes(q)).map((x) => flightById.get(x.id)).filter((f) => f && onDay(f));
  if (!matches.length && !mine.length) {
    summary.innerHTML = "";
    list.innerHTML = `<div class="empty-state">Aucun vol trouvé pour « ${esc(search.value)} »${day ? " le " + displayDate(day) : ""}.</div>`;
    return;
  }

  const base = mine.length ? mine : matches; // no plan for this name -> fall back to the flights they treated
  const done = base.filter((f) => f.status === "completed").length;
  const total = matches.length;
  const completed = matches.filter((f) => f.status === "completed").length;
  const inProgress = matches.filter((f) => f.status === "in_progress").length;
  const pending = total - completed - inProgress;
  const displayName = matches[0]?.updatedByName || search.value;

  summary.innerHTML = `
    <div class="panel">
      <div class="panel-title">Vols traités par ${esc(displayName)}${day ? " · " + displayDate(day) : ""}</div>
      <div class="ctrl-summary">
        <div class="ctrl-ring">${ringHtml(done, base.length, 96)}
          <small>${done} / ${base.length} vols ${mine.length ? "affectés" : "traités"} contrôlés</small></div>
        <div class="stat-row" style="margin-bottom:0">
          <div class="stat"><div class="num">${total}</div><div class="lbl">Vols</div></div>
          <div class="stat"><div class="num">${completed}</div><div class="lbl">Complétés</div></div>
          <div class="stat"><div class="num">${inProgress}</div><div class="lbl">En cours</div></div>
          <div class="stat"><div class="num">${pending}</div><div class="lbl">En attente</div></div>
        </div>
      </div>
    </div>`;

  list.innerHTML = matches.length ? matches.map(rowHtml).join("") : `<div class="empty-state">Aucun vol traité pour l'instant (vols affectés : ${mine.length}).</div>`;
}

function rowHtml(f) {
  const a = f.controller?.paxAllerReel != null;
  const r = f.controller?.paxRetourReel != null;
  const retour = hasRetourLeg(f);
  const d = getFlightDate(f);
  return `
    <a class="flight-row" href="../flight.html?id=${encodeURIComponent(f.id)}">
      <span class="flight-num">${esc(f.flightNumber)}</span>
      <span class="flight-meta">${displayDate(d)} · ${esc(f.heureDepart || "--:--")} · ${esc(f.aircraftType || "?")} · ${esc(f.numEnregistrement || "")}</span>
      <span class="flight-cat">${esc(String(f.aircraftCategory || "").replace("_", " "))}</span>
      <span class="leg-marks"><span class="${a ? "done" : ""}">A${a ? icon("check", 12) : icon("circle", 12)}</span>${retour ? `<span class="${r ? "done" : ""}">R${r ? icon("check", 12) : icon("circle", 12)}</span>` : ""}</span>
      <span class="controller-name">${icon("user", 13)} ${esc(f.updatedByName)}</span>
      <span class="status-badge ${f.status}">${String(f.status || "").replace("_", " ")}</span>
    </a>`;
}

function esc(s) {
  return String(s ?? "").replace(/[&<>"']/g, (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]));
}
function escAttr(s) {
  return esc(s);
}
