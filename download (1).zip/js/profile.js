import { requireAuth, showToast, initialsOf } from "./auth.js";
import { updateProfile, changePassword, logout } from "./api.js";
import { enhancePasswordFields } from "./pw-toggle.js";

const { profile } = await requireAuth("profile.html");
const content = document.getElementById("content");

const esc = (v) => String(v ?? "").replace(/[&<>"']/g, (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]));
const ROLE_LABEL = { admin: "Administrateur", controller: "Contrôleur" };

content.innerHTML = `
  <div class="profile-head">
    <span class="avatar lg" id="bigAvatar">${esc(initialsOf(profile))}</span>
    <div>
      <h1 id="headName">${esc(profile.name || profile.email)}</h1>
      <p class="subtitle"><span class="role-pill ${esc(profile.role)}">${esc(profile.role)}</span> · ${esc(profile.email)}</p>
    </div>
  </div>

  <div class="profile-grid">
    <div class="panel">
      <div class="panel-title">Informations</div>
      <div id="infoMsg"></div>
      <form id="infoForm">
        <div class="field"><label for="pName">Nom</label><input type="text" id="pName" value="${esc(profile.name)}" required maxlength="120" autocomplete="name"></div>
        <div class="field"><label for="pEmail">Email</label><input type="email" id="pEmail" value="${esc(profile.email)}" readonly></div>
        <div class="field"><label for="pRole">Rôle</label><input type="text" id="pRole" value="${esc(ROLE_LABEL[profile.role] || profile.role)}" readonly></div>
        <button type="submit" class="btn amber" id="infoBtn">Enregistrer</button>
      </form>
    </div>

    <div class="panel">
      <div class="panel-title">Changer le mot de passe</div>
      <div id="pwMsg"></div>
      <form id="pwForm">
        <div class="field"><label for="pwCur">Mot de passe actuel</label><input type="password" id="pwCur" required autocomplete="current-password"></div>
        <div class="field"><label for="pwNew">Nouveau mot de passe (8 caractères min.)</label><input type="password" id="pwNew" required minlength="8" autocomplete="new-password"></div>
        <div class="field"><label for="pwNew2">Confirmer le nouveau mot de passe</label><input type="password" id="pwNew2" required minlength="8" autocomplete="new-password"></div>
        <button type="submit" class="btn amber" id="pwBtn">Mettre à jour</button>
      </form>
    </div>
  </div>

  <div class="profile-logout"><button type="button" class="btn ghost" id="profileLogout">Se déconnecter</button></div>
`;

enhancePasswordFields(content);

const infoMsg = document.getElementById("infoMsg");
const pwMsg = document.getElementById("pwMsg");

document.getElementById("infoForm").addEventListener("submit", async (e) => {
  e.preventDefault();
  const btn = document.getElementById("infoBtn");
  infoMsg.innerHTML = "";
  btn.disabled = true;
  try {
    const updated = await updateProfile(document.getElementById("pName").value.trim());
    // Keep the navbar and header in sync without a reload.
    document.getElementById("headName").textContent = updated.name;
    document.getElementById("navUserName").textContent = updated.name;
    const ini = initialsOf(updated);
    document.getElementById("bigAvatar").textContent = ini;
    document.getElementById("navAvatar").textContent = ini;
    showToast("Profil mis à jour", "success");
  } catch (err) {
    infoMsg.innerHTML = `<div class="error-msg">${esc(err.message)}</div>`;
  } finally { btn.disabled = false; }
});

document.getElementById("pwForm").addEventListener("submit", async (e) => {
  e.preventDefault();
  pwMsg.innerHTML = "";
  const cur = document.getElementById("pwCur").value;
  const next = document.getElementById("pwNew").value;
  if (next !== document.getElementById("pwNew2").value) {
    pwMsg.innerHTML = `<div class="error-msg">Les deux mots de passe ne correspondent pas.</div>`;
    return;
  }
  const btn = document.getElementById("pwBtn");
  btn.disabled = true;
  try {
    await changePassword(cur, next);
    e.target.reset();
    showToast("Mot de passe modifié", "success");
  } catch (err) {
    pwMsg.innerHTML = `<div class="error-msg">${esc(err.message)}</div>`;
  } finally { btn.disabled = false; }
});

document.getElementById("profileLogout").addEventListener("click", async () => {
  try { await logout(); } catch { /* ignore */ }
  location.href = "login.html";
});
