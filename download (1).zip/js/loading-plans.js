// « Plan de chargement » — one PDF per aircraft family, uploaded by an admin (named after the family
// code: 788.pdf, 786.pdf, 789.pdf, 73H.pdf, 7M3.pdf, 7M8.pdf, E90.pdf, AT7.pdf, or any other code).
// A controller opening a flight (e.g. AT208, Type A/C "788") gets the matching PDF with no extra typing:
// the flight's Type A/C is matched against every uploaded family code, here, on the client.
//
// The server (api/index.php: GET/POST/DELETE loading-plans, GET loading-plan) only stores and serves
// PDFs by their exact family code; it never guesses — matching a flight to a family is entirely this
// module's job, so the admin page and the flight page agree on one rule.

/** "788.pdf" / "7m8" / " E90 " -> "788" / "7M8" / "E90". Keeps only letters and digits, uppercased. */
export const normPlanCode = (v) => String(v ?? "").toUpperCase().replace(/[^A-Z0-9]/g, "");

/** A valid family code: 1–16 letters/digits once normalized (matches the server's PLAN_TYPE_RE). */
export const isValidPlanCode = (code) => /^[A-Z0-9]{1,16}$/.test(normPlanCode(code));

/** Family code an admin meant by a file name: strips the extension, then normalizes
 *  ("788.pdf" -> "788"; "7M8 - plan.pdf" -> "7M8" — only the part before any separator/extension is kept).
 *  « Moyen courrier » variants end with M: "788m.pdf" / "788 M.pdf" / "788-M.pdf" / "788_moyen.pdf" -> "788M". */
export function planCodeFromFileName(fileName) {
  const stem = String(fileName ?? "").replace(/\.[a-z0-9]+$/i, "");
  const variant = stem.match(/^\s*([a-z0-9]+)[\s_-]+(?:m|mc|moyen(?:[\s_-]*courrier)?)\s*$/i);
  if (variant) return normPlanCode(variant[1]) + "M";
  const head = stem.split(/[\s_-]+/)[0] || stem; // "788.pdf" -> "788"; "73H - chargement.pdf" -> "73H"
  return normPlanCode(head);
}

/** « Moyen courrier » plan variants are uploaded as <family>M.pdf (788M, 786M, 787M, 789M…): 4+ characters ending in M.
 *  (Family codes themselves are 3 characters — 788, 73H, 7M8, E90, AT7 — so a trailing M is unambiguous.) */
export const isMediumVariant = (code) => code.length >= 4 && code.endsWith("M");

/** Best family for a flight type among `families`: exact match wins; otherwise the longest family code that is a
 *  prefix of, or shares a prefix with, the flight's code — this absorbs the extra digits the Récap sometimes
 *  appends to a type (immat./cycle artifacts like "7M84", "73H7", "7M35"). */
function bestFamily(norm, families) {
  if (families.includes(norm)) return norm;
  let best = null;
  for (const fam of families) {
    if (fam.length < 2) continue; // a 1-char family is too ambiguous to prefix-match
    if (norm.startsWith(fam) || fam.startsWith(norm)) {
      if (!best || fam.length > best.length) best = fam;
    }
  }
  return best;
}

/** Matches a flight's Type A/C (e.g. "73H", "7M84", "788-8") against the uploaded plan codes (plain strings or
 *  {type} objects, as returned by GET loading-plans) and returns the plan code to open, or null.
 *
 *  Long-haul fleet (786/787/788/789) can fly moyen courrier too and then uses a different plan:
 *    - flight category MOYEN_COURRIER -> the "M" plan (788M.pdf, 786M.pdf…) when uploaded,
 *      otherwise the regular plan (788.pdf) as before;
 *    - any other category -> the regular plan only; "M" plans are never offered (a plain 788 flight must not
 *      pick up 788M through prefix matching). */
export function matchLoadingPlan(aircraftType, availableTypes, category = "") {
  const norm = normPlanCode(aircraftType);
  if (!norm || !availableTypes?.length) return null;
  const all = [...new Set(availableTypes.map((t) => normPlanCode(typeof t === "string" ? t : t?.type)).filter(Boolean))];
  const regular = all.filter((c) => !isMediumVariant(c));
  if (String(category).toUpperCase() === "MOYEN_COURRIER") {
    const bases = all.filter(isMediumVariant).map((c) => c.slice(0, -1));
    const base = bestFamily(norm, bases);
    if (base) return base + "M";
  }
  return bestFamily(norm, regular);
}

export const PLAN_ACCEPT = ".pdf,application/pdf";
export const MAX_PLAN_BYTES = 8 * 1024 * 1024; // keep in sync with api/index.php MAX_PLAN_BYTES
