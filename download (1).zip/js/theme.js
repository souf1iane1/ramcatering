// Light / dark theme. Loaded as a classic <script> in <head> (before first paint) so there is no flash.
// Mode is "auto" (follow the device), "light" or "dark"; the choice is remembered in localStorage.
(function () {
  var KEY = "cl-theme";
  var SUN = '<svg viewBox="0 0 24 24" width="18" height="18" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><circle cx="12" cy="12" r="4"/><path d="M12 2v2M12 20v2M4.93 4.93l1.41 1.41M17.66 17.66l1.41 1.41M2 12h2M20 12h2M4.93 19.07l1.41-1.41M17.66 6.34l1.41-1.41"/></svg>';
  var MOON = '<svg viewBox="0 0 24 24" width="18" height="18" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M21 12.79A9 9 0 1 1 11.21 3 7 7 0 0 0 21 12.79z"/></svg>';
  var mq = window.matchMedia ? window.matchMedia("(prefers-color-scheme: dark)") : null;

  function stored() { try { var v = localStorage.getItem(KEY); return v === "light" || v === "dark" ? v : "auto"; } catch (e) { return "auto"; } }
  function effective() { var m = stored(); return m === "auto" ? (mq && mq.matches ? "dark" : "light") : m; }

  function paintButtons() {
    var dark = effective() === "dark";
    document.querySelectorAll("[data-theme-toggle]").forEach(function (b) {
      b.innerHTML = dark ? SUN : MOON;
      var label = dark ? "Passer en mode clair" : "Passer en mode sombre";
      b.title = label; b.setAttribute("aria-label", label);
    });
  }
  function apply() {
    var t = effective();
    document.documentElement.setAttribute("data-theme", t);
    var meta = document.querySelector('meta[name="theme-color"]');
    if (meta) meta.setAttribute("content", t === "dark" ? "#8a0000" : "#c80000");
    paintButtons();
  }
  function set(mode) { try { localStorage.setItem(KEY, mode); } catch (e) { /* private mode */ } apply(); }
  function toggle() { set(effective() === "dark" ? "light" : "dark"); }
  function wire() {
    document.querySelectorAll("[data-theme-toggle]").forEach(function (b) {
      if (b.__themeWired) return; b.__themeWired = true;
      b.addEventListener("click", toggle);
    });
    paintButtons();
  }

  window.clTheme = { set: set, toggle: toggle, wire: wire, get mode() { return stored(); }, get effective() { return effective(); } };
  apply();
  if (mq && mq.addEventListener) mq.addEventListener("change", function () { if (stored() === "auto") apply(); });

  document.addEventListener("DOMContentLoaded", function () {
    // pages without the app bar (login, 404, legal…) get a small floating switch
    if (!document.getElementById("topbar") && !document.querySelector("[data-theme-toggle]")) {
      var b = document.createElement("button");
      b.type = "button"; b.className = "theme-toggle floating"; b.setAttribute("data-theme-toggle", "");
      document.body.appendChild(b);
    }
    wire();
  });
})();
