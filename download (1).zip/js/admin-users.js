import { requireAuth } from "./auth.js";
import { listUsers, createUser, updateUser, deleteUser } from "./api.js";
import { icon } from "./icons.js";
import { confirmDialog } from "./confirm.js";
import { enhancePasswordFields } from "./pw-toggle.js";

const { profile: me } = await requireAuth("admin/users.html");
const myId = String(me?.id ?? me?.uid ?? "");

const msg = document.getElementById("msg");
const usersBody = document.getElementById("usersBody");
enhancePasswordFields();
const form = document.getElementById("createForm");
const resetDialog = document.getElementById("resetPasswordDialog");
const resetForm = document.getElementById("resetPasswordForm");
const resetPasswordInput = document.getElementById("resetPassword");
const resetTargetLabel = document.getElementById("resetTargetLabel");
const resetSubmit = document.getElementById("confirmResetPassword");
let resetTarget = null;
const esc = (v) => String(v ?? "").replace(/[&<>"']/g, (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]));

async function loadUsers() {
  const users = await listUsers();
  usersBody.innerHTML = users.map((u) => `
    <tr>
      <td>${esc(u.name) || "—"}${u.isOwner ? ` <span class="owner-badge" title="Premier administrateur (créé par install.php) : ne peut être ni modifié ni supprimé par un autre admin">${icon("shield", 12)} Propriétaire</span>` : ""}</td>
      <td class="mono">${esc(u.email)}</td>
      <td><select data-uid="${u.id}" class="roleSelect" ${u.isOwner ? "disabled" : ""} aria-label="Rôle de ${esc(u.name || u.email)}">
        <option value="controller" ${u.role === "controller" ? "selected" : ""}>Controller</option>
        <option value="admin" ${u.role === "admin" ? "selected" : ""}>Admin</option>
      </select></td>
      <td>${u.role === "controller" ? `<button type="button" class="btn small resetPasswordBtn" data-uid="${esc(u.id)}" data-name="${esc(u.name || u.email)}" data-email="${esc(u.email)}">Réinitialiser le mot de passe</button>` : ""}
        ${u.isOwner ? (String(u.id) === myId ? `<span class="muted" title="Votre compte">(vous)</span>` : `<span class="muted" title="Protégé">${icon("shield", 13)} Protégé</span>`) : String(u.id) === myId ? `<span class="muted" title="Votre compte">(vous)</span>` : `<button type="button" class="btn ghost danger small deleteUserBtn" data-uid="${esc(u.id)}" data-name="${esc(u.name || u.email)}" data-email="${esc(u.email)}" data-role="${esc(u.role)}">${icon("trash", 14)} Supprimer</button>`}</td>
    </tr>`).join("") || `<tr><td colspan="4">Aucun utilisateur.</td></tr>`;

  usersBody.querySelectorAll(".resetPasswordBtn").forEach((btn) => btn.addEventListener("click", () => {
    resetTarget = { id: btn.dataset.uid, name: btn.dataset.name, email: btn.dataset.email };
    resetTargetLabel.textContent = `Compte Controller : ${resetTarget.name} (${resetTarget.email})`;
    resetForm.reset();
    resetDialog.showModal();
    resetPasswordInput.focus();
  }));

  usersBody.querySelectorAll(".deleteUserBtn").forEach((btn) => btn.addEventListener("click", async () => {
    const { uid, name, email, role } = btn.dataset;
    if (!(await confirmDialog({ title: "Supprimer ce compte ?", message: `Le compte ${name} (${email}, ${role}) sera supprimé définitivement : il ne pourra plus se connecter.`, confirmText: "Supprimer le compte", danger: true }))) return;
    btn.disabled = true;
    msg.innerHTML = "";
    try {
      await deleteUser(uid);
      msg.innerHTML = `<div class="ok-msg">Compte ${esc(email)} supprimé.</div>`;
      await loadUsers();
    } catch (err) {
      msg.innerHTML = `<div class="error-msg">${esc(err.message)}</div>`;
      btn.disabled = false;
    }
  }));

  usersBody.querySelectorAll(".roleSelect").forEach((sel) =>
    sel.addEventListener("change", async () => {
      try {
        await updateUser(sel.dataset.uid, { role: sel.value });
        msg.innerHTML = `<div class="ok-msg">Rôle mis à jour.</div>`;
      } catch (err) {
        msg.innerHTML = `<div class="error-msg">${esc(err.message)}</div>`;
        await loadUsers(); // put the dropdown back to the real value
      }
    })
  );
}
await loadUsers();

form.addEventListener("submit", async (e) => {
  e.preventDefault();
  msg.innerHTML = "";
  const name = document.getElementById("newName").value.trim();
  const email = document.getElementById("newEmail").value.trim();
  const password = document.getElementById("newPassword").value;
  const role = document.getElementById("newRole").value;
  const submitBtn = form.querySelector("button[type=submit]");
  submitBtn.disabled = true;

  try {
    await createUser({ name, email, password, role });
    msg.innerHTML = `<div class="ok-msg">Utilisateur ${esc(email)} créé avec le rôle ${esc(role)}.</div>`;
    form.reset();
    await loadUsers();
  } catch (err) {
    msg.innerHTML = `<div class="error-msg">${esc(err.message)}</div>`;
  } finally {
    submitBtn.disabled = false;
  }
});


document.getElementById("cancelResetPassword").addEventListener("click", () => {
  resetDialog.close();
  resetTarget = null;
  resetForm.reset();
});

resetDialog.addEventListener("click", (event) => {
  if (event.target === resetDialog) {
    resetDialog.close();
    resetTarget = null;
    resetForm.reset();
  }
});

resetForm.addEventListener("submit", async (event) => {
  event.preventDefault();
  msg.innerHTML = "";
  if (!resetTarget) return;
  const password = resetPasswordInput.value;
  if (password.length < 8) {
    msg.innerHTML = `<div class="error-msg">Le mot de passe doit contenir au moins 8 caractères.</div>`;
    return;
  }
  resetSubmit.disabled = true;
  try {
    await updateUser(resetTarget.id, { password });
    const email = resetTarget.email;
    resetDialog.close();
    resetTarget = null;
    resetForm.reset();
    msg.innerHTML = `<div class="ok-msg">Mot de passe réinitialisé pour ${esc(email)}. Les sessions précédentes ont été invalidées et l’opération a été enregistrée dans le journal d’audit.</div>`;
  } catch (err) {
    msg.innerHTML = `<div class="error-msg">${esc(err.message)}</div>`;
  } finally {
    resetSubmit.disabled = false;
  }
});
