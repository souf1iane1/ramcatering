// Admin: « Répartir manuellement » — the ONLY way flights get a controller (there is no automatic split).
//   1. Contrôleurs : click one or more names.
//   1b. Recherche « Into » / « To » : les vols sont dans l'ordre du Récap (f.recapIdx) ; on saisit le vol de début et le
//      vol de fin (ex. INTO AT1435 TO AT215), la liste se limite à cette plage et « Cocher la plage » la coche.
//   2. Plage de vols : ALL the day's flights are listed — tick the ones you want (or « Tout cocher »).
//   3. Split : shares the TICKED flights between the selected controllers (balanced counts, two flights with the
//      SAME loading time never go to the same controller). Only the split flights stay on screen as a preview.
//   4. Affecter : saves. « Retirer l'affectation » frees the ticked flights.
//   openManualSplit({ date, flights, controllerNames, plans, onSaved })
// `flights` = the day's flights already processed by assignDay() (f.shift, f.assignedTo set).
// Only the flights that were split/freed change: every other flight keeps its saved controller (or none).
import { icon } from "./icons.js";
import { saveShiftPlan, listUsers } from "./api.js";
import { showToast } from "./auth.js";
import { plansCache, loadPlans } from "./assign.js";
import { SHIFTS, SHIFT_ORDER, sortInShift, loadTime, splitNoOverlap, byRecapOrder, searchRange } from "./shifts.js";

const esc = (v) => String(v ?? "").replace(/[&<>"']/g, (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]));
const dmy = (iso) => (iso ? iso.split("-").reverse().join("/") : "");

export function openManualSplit({ date, flights, controllerNames = [], plans = {}, onSaved = () => {} }) {
  document.getElementById("msOverlay")?.remove();
  let names = [...new Set(controllerNames)].sort((a, b) => a.localeCompare(b)); // the accounts of the Utilisateurs page (role controller), refreshed on open
  let namesState = names.length ? "ok" : "loading"; // "loading" | "ok" | "error"
  const groups = SHIFT_ORDER.map((k) => ({ k, items: sortInShift(flights.filter((f) => f.shift === k), k) })).filter((g) => g.items.length);
  const shiftOrder = groups.flatMap((g) => g.items);
  const recapOrdered = byRecapOrder(shiftOrder);   // null when the recap was imported before the order was stored
  const all = recapOrdered || shiftOrder;          // every flight of the day, on-screen order (= recap order when known)

  const ov = document.createElement("div");
  ov.id = "msOverlay"; ov.className = "fe-overlay";
  ov.innerHTML = `
  <div class="fe-modal ms-modal" role="dialog" aria-modal="true" aria-labelledby="msTitle">
    <div class="fe-head">
      <h2 id="msTitle">${icon("userCheck", 18)} Répartition manuelle — ${dmy(date)}</h2>
      <button type="button" class="fe-x" data-close aria-label="Fermer">${icon("x", 18)}</button>
    </div>
    <div class="ms-top">
      <div class="fe-field ms-ctls"><span>Contrôleur <em id="msSelN">(aucun)</em></span>
        <div class="ms-chips" id="msChips"></div></div>
      <label class="ms-only"><input type="checkbox" id="msFree"> Non affectés seulement</label>
    </div>
    <div class="ms-search">
      <label class="fe-field"><span>Search into</span><input id="msInto" type="search" placeholder="AT1435" autocomplete="off" spellcheck="false"></label>
      <label class="fe-field"><span>Search to</span><input id="msTo" type="search" placeholder="AT215" autocomplete="off" spellcheck="false"></label>
      <button type="button" class="btn ghost small" id="msTick">Cocher la plage</button>
      <button type="button" class="btn ghost small" id="msClearS">Effacer</button>
      <div class="ms-hint" id="msSearchMsg"></div>
    </div>
    <div class="ms-range" id="msRange" hidden></div>
    <div class="ms-listbar"><strong>Plage de vols</strong><button type="button" class="btn ghost small" id="msAll">Tout cocher</button><span id="msListN"></span></div>
    <div class="fe-body ms-body" id="msList"></div>
    <div class="fe-foot">
      <span class="ms-count" id="msCount"></span>
      <button type="button" class="btn ghost" data-close>Fermer</button>
      <button type="button" class="btn ghost" id="msFreeBtn" disabled>Retirer l'affectation</button>
      <button type="button" class="btn ghost" id="msSplit" disabled>${icon("users", 16)} Split</button>
      <button type="button" class="btn amber" id="msSave" disabled>${icon("check", 16)} Affecter</button>
    </div>
  </div>`;
  document.body.appendChild(ov);
  const $ = (id) => ov.querySelector("#" + id);
  const close = () => { ov.remove(); document.removeEventListener("keydown", onKey); };
  const onKey = (e) => { if (e.key === "Escape") close(); };
  document.addEventListener("keydown", onKey);
  ov.addEventListener("mousedown", (e) => { if (e.target === ov) close(); });
  ov.querySelectorAll("[data-close]").forEach((b) => b.addEventListener("click", close));

  const sel = [];            // selected controllers, in click order
  const ticked = new Set();  // ticked flights (by flight number)
  const pending = new Map(); // flight number -> controller (result of "Split", not saved yet)
  let conflicts = 0;         // simultaneous flights that outnumber the selected controllers

  const state = () => {
    const freeOnly = $("msFree").checked;
    const r = searchRange(all, $("msInto").value, $("msTo").value);
    const inRange = r.error ? all : new Set(r.items.map((f) => f.flightNumber));
    return { error: r.error || "", visible: all.filter((f) => (r.error || inRange.has(f.flightNumber)) && (!pending.size || pending.has(f.flightNumber)) && (!freeOnly || !f.assignedTo)) };
  };
  // flights the Split will share: the ticked ones, in on-screen order
  const toSplit = () => all.filter((f) => ticked.has(f.flightNumber));

  let chipsKey = "";
  const renderChips = () => {
    const key = namesState + "#" + names.join("|") + "#" + sel.join("|");
    if (key === chipsKey) return;
    chipsKey = key;
    $("msChips").innerHTML = namesState === "loading" && !names.length ? `<span class="ms-hint">Chargement des contrôleurs…</span>`
      : namesState === "error" && !names.length ? `<span class="ms-hint err">Impossible de charger les contrôleurs. <button type="button" class="btn ghost small" id="msRetry">Réessayer</button></span>`
      : !names.length ? `<span class="ms-hint">Aucun compte contrôleur actif — créez-en dans la page Utilisateurs.</span>`
      : names.map((n) => `<label class="ms-chip${sel.includes(n) ? " on" : ""}"><input type="checkbox" data-c="${esc(n)}" ${sel.includes(n) ? "checked" : ""}><span>${esc(n)}</span></label>`).join("");
  };
  const loadControllers = async () => {
    namesState = "loading"; render();
    try {
      const users = await listUsers("controller");
      names = [...new Set(users.filter((u) => u.active !== false).map((u) => String(u.name || u.email || "").trim()).filter(Boolean))].sort((a, b) => a.localeCompare(b));
      namesState = "ok";
    } catch (e) { console.warn("controllers list:", e); namesState = "error"; }
    render();
  };

  const render = () => {
    const { visible, error } = state();
    const typed = $("msInto").value.trim() || $("msTo").value.trim();
    $("msSearchMsg").className = "ms-hint" + (error ? " err" : "");
    $("msSearchMsg").textContent = error || (!recapOrdered ? "Ordre du Récap indisponible pour ce jour (réimportez le Récap) : ordre par heure de chargement." : typed ? `${visible.length} vol(s) dans la plage (ordre du Récap).` : "Saisissez le vol de début (Into) et/ou de fin (To). Plusieurs vols possibles : AT808 OR AT250.");
    $("msTick").disabled = !!error || !typed || !visible.length;
    renderChips();
    $("msSelN").textContent = sel.length ? `(${sel.length})` : "(aucun)";
    const rb = $("msRange");
    rb.hidden = !pending.size;
    rb.classList.remove("err");
    rb.innerHTML = pending.size ? `Split en cours : ${pending.size} vol${pending.size > 1 ? "s" : ""} · changez les contrôleurs ou le filtre pour revenir à la liste complète` : "";

    const inPreview = pending.size > 0;
    $("msAll").hidden = inPreview;
    $("msAll").textContent = visible.length && visible.every((f) => ticked.has(f.flightNumber)) ? "Tout décocher" : "Tout cocher";
    $("msListN").textContent = `${visible.length} vol${visible.length > 1 ? "s" : ""} affiché${visible.length > 1 ? "s" : ""} · ${ticked.size} coché${ticked.size > 1 ? "s" : ""}`;

    $("msList").innerHTML = visible.map((f) => {
      const np = pending.get(f.flightNumber), on = ticked.has(f.flightNumber);
      return `<label class="ms-row${on || np ? " on" : ""}">
        ${inPreview ? "" : `<input type="checkbox" data-fn="${esc(f.flightNumber)}" ${on ? "checked" : ""}>`}
        <b class="ms-fn">${esc(f.flightNumber)}</b>
        <span class="ms-meta">${esc(SHIFTS[f.shift]?.label || "")} · Chargt ${esc(loadTime(f) || "—")} · Dép ${esc(f.heureDepart || "—")} · ${esc(f.aircraftType || "—")}</span>
        ${np ? `<span class="ms-who new">${icon("arrowRight", 12)} ${esc(np)}</span>`
          : f.assignedTo ? `<span class="ms-who">${icon("arrowRight", 12)} ${esc(f.assignedTo)}</span>` : `<span class="ms-who none">non affecté</span>`}
      </label>`;
    }).join("") || `<div class="empty-state">Aucun vol.</div>`;

    let text;
    if (inPreview) {
      const per = sel.map((c) => `${c} (${[...pending.values()].filter((x) => x === c).length})`).join(", ");
      text = `Split : ${pending.size} vol${pending.size > 1 ? "s" : ""} → ${per}` + (conflicts ? ` · ⚠ ${conflicts} vol(s) au même horaire (pas assez de contrôleurs)` : "");
    } else if (!sel.length) text = "Choisissez un ou plusieurs contrôleurs.";
    else if (!ticked.size) text = "Cochez les vols à répartir.";
    else text = `${ticked.size} vol${ticked.size > 1 ? "s" : ""} coché${ticked.size > 1 ? "s" : ""} — cliquez sur Split pour ${sel.length > 1 ? "les répartir" : `les affecter à ${sel[0]}`}.`;
    $("msCount").textContent = text;
    $("msSplit").disabled = inPreview || !sel.length || !ticked.size;
    $("msSave").disabled = !inPreview;
    $("msFreeBtn").disabled = inPreview || !all.some((f) => ticked.has(f.flightNumber) && f.assignedTo);
  };

  const refilter = () => { pending.clear(); render(); };

  $("msChips").addEventListener("click", (e) => { if (e.target.closest("#msRetry")) loadControllers(); });
  $("msChips").addEventListener("change", (e) => {
    const c = e.target.dataset?.c; if (c == null) return;
    if (e.target.checked) sel.push(c); else sel.splice(sel.indexOf(c), 1);
    pending.clear();
    render();
  });
  ["msFree", "msInto", "msTo"].forEach((id) => $(id).addEventListener("input", refilter));
  // « Cocher la plage » : only the flights of the range are ticked (previous ticks are replaced)
  const tickRange = () => { const { visible, error } = state(); if (error || !visible.length) return; ticked.clear(); visible.forEach((f) => ticked.add(f.flightNumber)); pending.clear(); render(); };
  $("msTick").addEventListener("click", tickRange);
  ["msInto", "msTo"].forEach((id) => $(id).addEventListener("keydown", (e) => { if (e.key === "Enter") { e.preventDefault(); tickRange(); } }));
  $("msClearS").addEventListener("click", () => { $("msInto").value = ""; $("msTo").value = ""; ticked.clear(); pending.clear(); render(); });
  $("msList").addEventListener("change", (e) => {
    const fn = e.target.dataset?.fn; if (!fn) return;
    if (e.target.checked) ticked.add(fn); else ticked.delete(fn);
    render();
  });
  $("msAll").addEventListener("click", () => {
    const { visible } = state();
    const allOn = visible.every((f) => ticked.has(f.flightNumber));
    visible.forEach((f) => (allOn ? ticked.delete(f.flightNumber) : ticked.add(f.flightNumber)));
    render();
  });
  $("msSplit").addEventListener("click", () => {
    pending.clear();
    const res = splitNoOverlap(toSplit(), sel);
    conflicts = res.conflicts;
    res.parts.forEach((b) => b.flights.forEach((f) => pending.set(f.flightNumber, b.name)));
    render();
  });

  // Saves { set: fn -> controller, free: [fn] } into the shift plans. Only the flights listed are touched.
  const commit = async (btn, setMap, freeSet, doneText) => {
    btn.disabled = true;
    let touched = 0;
    try {
      for (const g of groups) {
        const assignments = { ...(plans[g.k]?.assignments || {}) };
        let changed = false;
        g.items.forEach((f) => {
          const want = setMap.get(f.flightNumber);
          if (want && assignments[f.flightNumber] !== want) { assignments[f.flightNumber] = want; changed = true; }
          else if (freeSet.has(f.flightNumber) && assignments[f.flightNumber]) { delete assignments[f.flightNumber]; changed = true; }
        });
        if (!changed) continue;
        const controllers = [...new Set([...(plans[g.k]?.controllers || []), ...Object.values(assignments)])];
        const plan = await saveShiftPlan({ date, shift: g.k, controllers, assignments });
        (plansCache.get(date) || plansCache.set(date, {}).get(date))[g.k] = plan;
        touched++;
      }
      plansCache.delete(date);
      const fresh = await loadPlans(date);
      const missing = [];
      groups.forEach((g) => g.items.forEach((f) => {
        const want = setMap.get(f.flightNumber);
        if (want && fresh[g.k]?.assignments?.[f.flightNumber] !== want) missing.push(f.flightNumber);
        if (freeSet.has(f.flightNumber) && fresh[g.k]?.assignments?.[f.flightNumber]) missing.push(f.flightNumber);
      }));
      if (!touched) { showToast("Aucun changement à enregistrer.", "info", 2500); close(); return; }
      if (missing.length) showToast(`Le serveur n'a pas enregistré ${missing.length} vol(s) : ${missing.slice(0, 5).join(", ")}${missing.length > 5 ? "…" : ""}`, "error", 7000);
      else showToast(doneText, "success", 3500);
      close();
      onSaved([...setMap.keys(), ...freeSet]);
    } catch (err) {
      showToast("Enregistrement impossible : " + err.message, "error", 5000);
      btn.disabled = false;
    }
  };
  $("msSave").addEventListener("click", (e) => {
    const n = pending.size;
    commit(e.currentTarget, new Map(pending), new Set(), `${n} vol${n > 1 ? "s" : ""} affecté${n > 1 ? "s" : ""} à ${sel.length} contrôleur${sel.length > 1 ? "s" : ""}.`);
  });
  $("msFreeBtn").addEventListener("click", (e) => {
    const fns = all.filter((f) => ticked.has(f.flightNumber) && f.assignedTo).map((f) => f.flightNumber);
    commit(e.currentTarget, new Map(), new Set(fns), `${fns.length} vol${fns.length > 1 ? "s" : ""} libéré${fns.length > 1 ? "s" : ""}.`);
  });

  render();
  loadControllers();
}
