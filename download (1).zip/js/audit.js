import { requireAuth } from "./auth.js";
import { listAuditLogs } from "./data.js";

await requireAuth("admin/audit.html");

const logs = await listAuditLogs();
const body = document.getElementById("logsBody");

function fmt(v) {
  if (v === null || v === undefined) return "—";
  if (typeof v === "object") return JSON.stringify(v);
  return String(v);
}
function fmtDate(ts) {
  if (!ts?.toDate) return "—";
  return ts.toDate().toLocaleString("fr-FR");
}

body.innerHTML = logs.map((l) => `
  <tr>
    <td class="mono">${fmtDate(l.timestamp)}</td>
    <td>${l.user}</td>
    <td><span class="tag-role">${l.role}</span></td>
    <td>${String(l.field) === "password_reset" ? "Compte utilisateur" : `<a href="../flight.html?id=${encodeURIComponent(l.flightId)}">${l.flightId}</a>`}</td>
    <td>${String(l.field) === "password_reset" ? "Réinitialisation du mot de passe" : l.field}</td>
    <td>${fmt(l.oldValue)}</td>
    <td>${fmt(l.newValue)}</td>
  </tr>`).join("") || `<tr><td colspan="7">Aucune entrée pour l'instant.</td></tr>`;
