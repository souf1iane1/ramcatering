import { parseNoteSpecialMeals } from "./excel-parser.js";
import { requireAuth, showToast } from "./auth.js";
import { icon } from "./icons.js";
import { getFlight, updateControllerFields, flightStatus, hasRetourLeg } from "./data.js";
import { buildModel, makeCtx, autoValue, normTick, cycleInfo } from "./checklist-rules.js";
import { deleteFlight } from "./api.js";
import { openFlightEditor } from "./flight-editor.js";
import { confirmDialog } from "./confirm.js";
import { exportXlsx, exportPdf } from "./export.js";
import { flightShift, shiftLabel, loadTime } from "./shifts.js";
import { listLoadingPlans, listTechSheets } from "./api.js";
import { matchLoadingPlan } from "./loading-plans.js";
import { matchTechSheetsByCycle } from "./tech-sheets.js";
import { openLoadingPlanViewer } from "./loading-plan-viewer.js";

const { profile } = await requireAuth("flight.html");
const content = document.getElementById("content");
const flightId = new URLSearchParams(location.search).get("id");

// Admins can view every flight, but only controllers enter/edit the actual data.
const canEditController = profile.role === "controller";
const canDelete = profile.role === "admin";

// Declared before the first render() call (module-level await runs render immediately).
let currentFlight = null;
let currentModel = null;
let lastLive = {}; // PAX réel snapshot used by the live auto-update (must exist before the first render)

// --- Matrice des ratios d'éléments chauds (checklist "PRESTATION", cadre C/CL) ---
// Index 0 = 1 PAX ... index 25 = 26 PAX.
const DC25_TABLE = {
  viande:  [1,1,2,2,3,4,4,5,5,6,7,7,8,8,9,10,10,11,11,12,13,13,14,14,15,16],
  poulet:  [1,1,1,2,2,2,3,3,4,4,4,5,5,6,6,6,7,7,8,8,8,9,9,10,10,10],
  poisson: [1,1,1,1,1,1,1,1,1,1,1,1,1,1,2,2,2,2,2,2,2,2,2,2,3,3],
};
// DC21 / DCC now use 120% (Viande 40% + Poulet 40% + Poisson 30% + Veg 10%).
// NB: the printed checklist matrix says 130% (40/40/40/10) — Poisson was lowered 40% -> 30%.
const DC2X_TABLE = { // DC21 / DCC
  viande:  [1,1,1,2,2,2,3,3,4,4,5,5,5,6,6,6,7,7,8,8,9,9,9,10,10,10],
  poulet:  [1,1,1,2,2,3,3,4,4,4,5,5,6,6,7,7,7,8,8,8,9,9,10,10,10,11],
  poisson: [1,1,1,1,2,2,2,2,3,3,3,4,4,4,5,5,5,5,6,6,6,7,7,7,8,8],
  veg:     [1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,2,2,2,2,2,2,2,2,2,3,3],
};
const PROD_ITEMS = ["viande","poulet","poisson","veg"];
const PROD_LABELS = { viande: "Viande", poulet: "Poulet", poisson: "Poisson", veg: "Veg" };

/** Looks up the checklist matrix (DC25 = 3 lignes 60/40/10% ; DC21 & DCC = 4 lignes 40/40/30/10% = 120%)
 *  for a given "code presta" and a PAX count, returning {viande, poulet, poisson[, veg]}. */
function lookupCclMatrix(code, pax) {
  if (!pax || pax < 1) return null;
  const codeU = String(code || "").toUpperCase();
  let table;
  if (codeU.includes("DC25")) table = DC25_TABLE;
  else if (codeU.includes("DC21") || codeU.includes("DCC")) table = DC2X_TABLE;
  else return null;
  const idx = Math.min(Math.max(Math.round(pax), 1), 26) - 1;
  const out = {};
  for (const k of Object.keys(table)) out[k] = table[k][idx];
  return out;
}

/** C/CL "Calculer" rule:
 *   - Code prestation DC25 / DC21 / DCC → percentage matrix (lookupCclMatrix).
 *   - Any other code (CF27, CC27, BF, ...) → simple PAX / 3 split across
 *     Viande / Poulet / Poisson (remainder distributed in that order),
 *     e.g. CC27 with 12 Aller / 6 Retour → 4/4/4 Aller, 2/2/2 Retour. */
function computeCclAuto(code, pax) {
  return lookupCclMatrix(code, pax) || computePeqThird(pax);
}

/** PEQ rule: split the PEQ pax count evenly by 3 across viande / poulet / poisson
 *  (remainder distributed in that order). E.g. 6 → 2/2/2, 10 → 4/3/3. */
function computePeqThird(n) {
  if (!n || n < 1) return null;
  n = Math.round(n);
  const base = Math.floor(n / 3);
  let rem = n - base * 3;
  const viande = base + (rem > 0 ? 1 : 0); if (rem > 0) rem--;
  const poulet = base + (rem > 0 ? 1 : 0); if (rem > 0) rem--;
  const poisson = base + (rem > 0 ? 1 : 0);
  return { viande, poulet, poisson };
}

// « Plan de chargement »: fetched once (metadata only — fileName/size, never the PDF bytes) so the
// matching PDF, if any, can be offered right away. A failure here (e.g. table missing on an older
// deployment) must not block the flight page, so it's swallowed and the button just stays hidden.
let loadingPlanTypes = [];
try { loadingPlanTypes = await listLoadingPlans(); } catch { /* button hidden below */ }
// « Fiche technique » (one PDF per code presta): same idea — metadata only, failure just hides the buttons.
let techSheetCodes = [];
try { techSheetCodes = await listTechSheets(); } catch { /* buttons hidden */ }
// Must be declared above the `render(flight)` call below (top-level consts are not hoisted).
const LEG_LABEL = { aller: "Aller", retour: "Retour" };

const flight = await getFlight(flightId);
if (!flight) {
  content.innerHTML = `<div class="error-msg">Vol introuvable.</div><a class="btn ghost" href="flights.html">Retour aux vols</a>`;
} else {
  render(flight);
}

function esc(v) { return v === null || v === undefined ? "" : String(v).replace(/"/g, "&quot;"); }
function ro(v) { return v === null || v === undefined || v === "" ? "—" : v; }

/** Formats a timestamp (api.js Timestamp or Date) into " le JJ/MM/AAAA HH:MM", or "" if absent. */
function formatUpdatedAt(ts) {
  const d = ts && typeof ts.toDate === "function" ? ts.toDate() : (ts instanceof Date ? ts : null);
  if (!d) return "";
  const pad = (n) => String(n).padStart(2, "0");
  return ` le ${pad(d.getDate())}/${pad(d.getMonth() + 1)}/${d.getFullYear()} ${pad(d.getHours())}:${pad(d.getMinutes())}`;
}

function render(f) {
  const c = f.controller || {};
  const checklist = c.checklist || {};
  const status = flightStatus(f);
  const isLong = f.aircraftCategory === "LONG_COURRIER";
  const hasRetour = hasRetourLeg(f);
  currentFlight = f;
  currentModel = buildModel(f, hasRetour);

  document.title = `Check-list — ${f.flightNumber}`;
  content.innerHTML = `
    <div class="toolbar" style="justify-content:space-between">
      <a class="btn ghost small" href="flights.html">${icon("arrowLeft", 14)} Retour</a>
      <div style="display:flex;align-items:center;gap:10px;flex-wrap:wrap">
        <span class="export-group">
          <button type="button" class="btn ghost small" id="exportXlsBtn">${icon("download", 14)} Excel</button>
          <button type="button" class="btn ghost small" id="exportPdfBtn">${icon("download", 14)} PDF</button>
        </span>
        ${profile.role === "admin" ? `<button type="button" class="btn ghost small" id="editFlightBtn">${icon("edit", 14)} Modifier</button>` : ""}
        ${profile.role === "admin" && f.updatedByName ? `<span class="controller-name" title="Contrôlé par">${icon("user", 13)} ${esc(f.updatedByName)}</span>` : ""}
        <span class="status-badge ${status}">${status.replace("_"," ")}</span>
      </div>
    </div>

    <div class="doc-head">
      <div class="flightnum">${f.flightNumber}</div>
      <div class="doc-fields">
        <div><span class="k">Date</span><span class="v">${ro(f.date)}</span></div>
        <div><span class="k">Heure Dép.</span><span class="v">${ro(f.heureDepart)}</span></div>
        <div><span class="k">Shift</span><span class="v">${ro(shiftLabel(flightShift(f)))}</span></div>
        <div><span class="k">Heure MAD</span><span class="v">${ro(f.heureMAD)}</span></div>
        <div><span class="k">Chargement (MAD+1h, sauf 786-789)</span><span class="v">${ro(loadTime(f))}</span></div>
        <div><span class="k">Type A/C</span><span class="v">${ro(f.aircraftType)}${(() => {
          const match = matchLoadingPlan(f.aircraftType, loadingPlanTypes, f.aircraftCategory);
          return match ? ` <button type="button" class="btn ghost small lp-btn" id="loadingPlanBtn" data-type="${esc(match)}">${icon("fileText", 14)} Plan de chargement</button>` : "";
        })()}</span></div>
        <div><span class="k">Catégorie</span><span class="v">${(f.aircraftCategory||"").replace("_"," ")}</span></div>
        <div><span class="k">Immat.</span><span class="v">${ro(f.numEnregistrement)}</span></div>
      </div>
    </div>

    ${f.note ? (() => {
      const spml = new Set(parseNoteSpecialMeals(f.note).map((x) => x.line));
      return `<div class="recap-note"><div class="recap-note-title">Note du Récap${spml.size ? ` <span class="recap-note-badge">${spml.size} SPML</span>` : ""}</div>
        ${String(f.note).split(/\r?\n/).filter((l) => l.trim()).map((l) => `<div class="recap-note-line${spml.has(l.trim()) ? " spml" : ""}">${esc(l)}</div>`).join("")}</div>`;
    })() : ""}

    <div class="grid3">
      ${cabinColumn("PEQ", f.imported?.peq, null, c, hasRetour)}
      ${cabinColumn("C/CL", f.imported?.cCl, "cCl", c, hasRetour)}
      ${cabinColumn("Y/CL", f.imported?.yCl, "yCl", c, hasRetour)}
    </div>

    ${checklistSections(currentModel, makeCtx(f), f, checklist)}

    <div class="section-block">
      <div class="section-header">Vérification produits (Viande / Poulet / Poisson / Veg)</div>
      ${prodGroup("PEQ", "peq", f.imported?.peq, c, hasRetour)}
      ${prodGroup("C/CL", "ccl", f.imported?.cCl, c, hasRetour)}
      ${prodGroup("Y/CL", "ycl", f.imported?.yCl, c, hasRetour)}
    </div>

    <div class="section-block">
      <div class="section-header">Équipement de contrôle</div>
      <div class="field-grid">
        ${cellSelect("tiroir","Tiroir (bacs)", c.tiroir, 18)}
        ${cellSelect("verseuses","Verseuses", c.verseuses, 18)}
        ${cellSelect("armoirs","Armoirs", c.armoirs, 8)}
        ${cellSelect("chargeursFours","Chargeurs fours", c.chargeursFours, 18)}
        ${cellSelect("trolleys11","Trolleys 1/1", c.trolleys11, 20)}
        ${cellSelect("trolleys12","Trolleys 1/2", c.trolleys12, 8)}
      </div>
    </div>

    <div class="section-block">
      <div class="section-header">Contrôles</div>
      <div class="field-grid">
        <div class="cell">
          <label for="fld-qssAs">Contrôle QSS-AS</label>
          <select id="fld-qssAs" data-field="qssAs" ${dis()}>
            <option value="" ${!c.qssAs ? "selected" : ""}>—</option>
            <option value="YES" ${c.qssAs === "YES" ? "selected" : ""}>OUI</option>
            <option value="NO" ${c.qssAs === "NO" ? "selected" : ""}>NON</option>
          </select>
        </div>
        ${inflightNameCell(c)}
        ${cellInput("nomAtlasServair","Contrôle Atlas Servair — Nom", c.nomAtlasServair)}
      </div>
    </div>

    <div class="two-col section-block">
      <div class="side">
        <h4>Heures de contrôle</h4>
        ${cellInput("miseADispo","H. Mise à dispo", c.miseADispo, "time")}
        ${cellInput("dep","H. DEP", (c.dep !== undefined && c.dep !== null && String(c.dep).trim() !== "") ? c.dep : (f.heureDepart || ""), "time")}
        ${cellInput("finCtrl","H. Fin Ctrl", c.finCtrl, "time")}
      </div>
      <div class="side">
        <h4><label for="fld-remarks">Remarques agent contrôle</label></h4>
        <textarea id="fld-remarks" name="remarks" data-field="remarks" rows="6" style="width:100%;padding:8px;border:1px solid var(--line-strong);border-radius:4px" ${dis()}>${esc(c.remarks)}</textarea>
      </div>
    </div>

    <details style="margin:16px 0">
      <summary style="cursor:pointer;font-size:12.5px;color:var(--ink-600)">Données brutes importées (Excel)</summary>
      ${["peq","cCl","yCl"].map((k) => rawTable(k, f.imported?.[k])).join("")}
    </details>

    <div class="sticky-save">
      <span class="audit-note">${profile.role === "admin" && f.updatedByName ? `Dernière mise à jour par ${esc(f.updatedByName)}${formatUpdatedAt(f.updatedAt)}` : (f.updatedAt ? `Dernière mise à jour${formatUpdatedAt(f.updatedAt)}` : "Aucune mise à jour")}${canDelete ? ` · <button class="linklike" id="deleteBtn" style="color:var(--red-600)">Supprimer le vol</button>` : ""}</span>
      <button class="btn amber" id="saveBtn" ${canEditController ? "" : "disabled"}>Enregistrer</button>
    </div>
  `;

  if (!canEditController) {
    content.querySelectorAll("[data-field]").forEach((el) => (el.disabled = true));
  }
  document.getElementById("saveBtn")?.addEventListener("click", () => save(f));
  document.getElementById("deleteBtn")?.addEventListener("click", () => removeFlight(f));
  document.getElementById("editFlightBtn")?.addEventListener("click", () => openFlightEditor({ flight: f, onSaved: () => location.reload() }));
  content.querySelectorAll("[data-tech-sheet]").forEach((btn) =>
    btn.addEventListener("click", () => {
      const code = btn.dataset.techSheet;
      const leg = btn.dataset.leg ? ` · ${LEG_LABEL[btn.dataset.leg]}` : "";
      openLoadingPlanViewer({ type: code, kind: "fiche", label: `${f.flightNumber} · ${code}${leg}` });
    })
  );
  document.getElementById("loadingPlanBtn")?.addEventListener("click", (e) => {
    const type = e.currentTarget.dataset.type;
    openLoadingPlanViewer({ type, label: `${f.flightNumber} · ${type}` });
  });
  for (const [id, fn] of [["exportXlsBtn", exportXlsx], ["exportPdfBtn", exportPdf]]) {
    const b = document.getElementById(id);
    b?.addEventListener("click", async () => {
      b.disabled = true;
      try { await fn(content, f); }
      catch (err) { console.error(err); showToast("Export impossible : " + err.message, "error", 5000); }
      finally { b.disabled = false; }
    });
  }
  wireCalcButtons();
  wireChecklist();
}

/** Live-reads a PAX "réel" input rendered by cabinColumn (pax-<cabin>-<leg>-reel), if present. */
function livePax(cabinKey, leg) {
  const el = document.getElementById(`pax-${cabinKey}-${leg}-reel`);
  if (!el || el.value === "") return null;
  const n = Number(el.value);
  return Number.isFinite(n) ? n : null;
}

/** PAX réel currently on screen: number = typed, null = field empty, undefined = field not on the page. */
function liveSnapshot() {
  const snap = {};
  for (const cab of ["ccl", "ycl"]) for (const leg of ["aller", "retour"]) {
    const el = document.getElementById(`pax-${cab}-${leg}-reel`);
    snap[`${cab}${leg === "aller" ? "Aller" : "Retour"}`] = !el ? undefined : (el.value === "" || !Number.isFinite(Number(el.value)) ? null : Number(el.value));
  }
  return snap;
}

function wireCalcButtons() {
  content.querySelectorAll("[data-calc]").forEach((btn) => {
    btn.addEventListener("click", () => {
      const cabinKey = btn.dataset.calc; // "peq" | "ccl" | "ycl"
      const kind = btn.dataset.calcKind; // "matrix" | "third" | "dash"
      const code = btn.dataset.code || "";
      const prevuAller = btn.dataset.paxAllerPrevu ? Number(btn.dataset.paxAllerPrevu) : null;
      const prevuRetour = btn.dataset.paxRetourPrevu ? Number(btn.dataset.paxRetourPrevu) : null;
      const paxAller = cabinKey === "peq" ? prevuAller : (livePax(cabinKey, "aller") ?? prevuAller);
      const paxRetour = cabinKey === "peq" ? prevuRetour : (livePax(cabinKey, "retour") ?? prevuRetour);

      let aller = null, retour = null;
      if (kind === "matrix") {
        // DC25 / DC21 / DCC use the percentage matrix; any other code prestation
        // (CF27, CC27, BF, ...) falls back to a plain PAX / 3 split.
        aller = computeCclAuto(code, paxAller);
        retour = computeCclAuto(code, paxRetour);
        if (!aller && !retour) {
          showToast("Nombre de PAX manquant.", "error");
          return;
        }
      } else if (kind === "third") {
        aller = computePeqThird(paxAller);
        retour = computePeqThird(paxRetour);
        if (!aller && !retour) {
          showToast("Nombre de PEQ manquant.", "error");
          return;
        }
      } else if (kind === "dash") {
        // Y/CL has no documented numeric rule — auto-fill every field with "-".
        aller = { viande: "-", poulet: "-", poisson: "-", veg: "-" };
        retour = { viande: "-", poulet: "-", poisson: "-", veg: "-" };
      }

      PROD_ITEMS.forEach((item) => {
        if (aller && aller[item] !== undefined) {
          const el = document.getElementById(`fld-prod-${cabinKey}-${item}-aller`);
          if (el) el.value = aller[item];
        }
        if (retour && retour[item] !== undefined) {
          const el = document.getElementById(`fld-prod-${cabinKey}-${item}-retour`);
          if (el) el.value = retour[item];
        }
      });
    });
  });
}

/** The three cabin blocks (PEQ, C/CL, Y/CL): ✔/❌ and number items, pre-filled by the detection rules
 *  in checklist-rules.js. Controllers can override anything; "Calcul"/"Auto" re-run the rules. */
function checklistSections(model, ctx, f, checklist) {
  const catLabel = model.isLong ? "Long courrier" : (f.aircraftCategory === "COURT_COURRIER" ? "Court courrier" : "Moyen courrier");
  return model.sections.map((sec) => {
    if (!sec.items.length) return "";
    const cells = (items) => items.map((it) => it.slots.map((slot) => slotCell(sec, it, slot, ctx, checklist)).join("")).join("");
    let body;
    if (sec.id === "peq") {
      // PEQ is shown in 3 groups; groups 1 and 2 each end with an "Auto" button that re-detects that group.
      body = [1, 2, 3].map((g) => {
        const items = sec.items.filter((it) => it.group === g);
        if (!items.length) return "";
        const autoIds = items.filter((it) => it.auto).map((it) => it.id).join(",");
        const bar = g < 3 && canEditController && autoIds
          ? `<div class="group-bar"><button type="button" class="btn ghost small" data-auto-section="peq" data-auto-items="${autoIds}">${icon("refresh", 14)} Détecter auto</button></div>` : "";
        return `<div class="field-grid">${cells(items)}</div>${bar}`;
      }).join("");
    } else {
      body = `<div class="field-grid">${cells(sec.items)}</div>`;
    }
    const calc = canEditController
      ? `<button type="button" class="btn ghost small" data-auto-section="${sec.id}">Calcul</button>` : "";
    return `
    <div class="section-block">
      <div class="section-header" style="display:flex;justify-content:space-between;align-items:center;gap:10px">
        <span>${sec.title} — ${catLabel}</span>${calc}
      </div>
      ${body}
    </div>`;
  }).join("");
}

function hasValue(v) { return v !== undefined && v !== null && v !== ""; }

function slotCell(sec, item, slot, ctx, checklist) {
  const id = `fld-chk-${slug(slot.key)}`;
  const stored = checklist[slot.key];
  const auto = canEditController ? autoValue(item, slot, ctx) : undefined;
  const data = `data-section="${sec.id}" data-item="${item.id}" data-slot="${slot.key}"`;
  if (item.kind === "text") { // free text: numbers and/or words
    return `<div class="cell chk-cell" ${data}>
      <label for="${id}">${slot.label}</label>
      <input id="${id}" data-field="checklist.${slot.key}" type="text" maxlength="80" autocomplete="off" value="${esc(hasValue(stored) ? stored : "")}" ${dis()}>
    </div>`;
  }
  if (item.kind === "count") {
    const useAuto = !hasValue(stored) && auto !== undefined;
    const val = hasValue(stored) ? stored : (useAuto ? auto : "");
    return `<div class="cell chk-cell${useAuto ? " is-auto" : ""}" ${data}>
      <label for="${id}">${slot.label}</label>
      <input id="${id}" data-field="checklist.${slot.key}" type="number" min="0" inputmode="numeric" value="${esc(val)}" ${dis()}>
      <span class="auto-tag" aria-hidden="true">auto</span>
    </div>`;
  }
  const sv = normTick(stored);
  const useAuto = !sv && auto !== undefined;
  const val = sv || (useAuto ? auto : "");
  const off = canEditController ? "" : "disabled";
  return `<div class="cell chk-cell tick-cell${useAuto ? " is-auto" : ""}" ${data}>
    <label for="${id}">${slot.label}</label>
    <div class="tick-group" role="group" aria-label="${esc(slot.label)}">
      <button type="button" class="tick yes" data-val="OK" aria-label="Oui" aria-pressed="${val === "OK"}" ${off}>${icon("check", 18)}</button>
      <button type="button" class="tick no" data-val="NON" aria-label="Non" aria-pressed="${val === "NON"}" ${off}>${icon("x", 18)}</button>
    </div>
    <input type="hidden" id="${id}" data-field="checklist.${slot.key}" value="${val}">
    <span class="auto-tag" aria-hidden="true">auto</span>
  </div>`;
}

/** "Contrôle Inflight RAM — Nom": the signed-in controller's own name (looked up from the app), editable. */
function inflightNameCell(c) {
  const stored = c.nomInflightRam;
  const auto = canEditController && !hasValue(stored) && profile.name;
  const cell = cellInput("nomInflightRam", "Contrôle Inflight RAM — Nom", hasValue(stored) ? stored : (auto || ""));
  return auto ? cell.replace('class="cell"', 'class="cell is-auto"').replace("</div>", '<span class="auto-tag" aria-hidden="true">auto</span></div>') : cell;
}

function setTickValue(cell, val, isAuto) {
  cell.querySelector('input[type="hidden"]').value = val;
  cell.querySelectorAll(".tick").forEach((b) => b.setAttribute("aria-pressed", String(b.dataset.val === val)));
  cell.classList.toggle("is-auto", !!isAuto && val !== "");
}


/** Re-applies the auto rules to one cabin after its PAX réel changed. */
function refreshFromPax(paxInput) {
  if (!canEditController || !currentModel) return;
  const cab = paxInput.id.split("-")[1]; // "ccl" | "ycl"
  const newLive = liveSnapshot();
  if (JSON.stringify(newLive) === JSON.stringify(lastLive)) return;   // nothing actually changed (keyup/change repeats)
  const oldCtx = makeCtx(currentFlight, lastLive);
  const newCtx = makeCtx(currentFlight, newLive);
  lastLive = newLive;
  const sec = currentModel.sections.find((x) => x.id === cab);
  if (!sec) return;
  content.querySelectorAll(`.chk-cell[data-section="${cab}"]`).forEach((cell) => {
    const item = sec.items.find((i) => i.id === cell.dataset.item);
    const slot = item?.slots.find((sl) => sl.key === cell.dataset.slot);
    if (!item || !slot) return;
    const next = autoValue(item, slot, newCtx);
    if (next === undefined) return;
    const prev = autoValue(item, slot, oldCtx);
    const cur = cell.querySelector("input")?.value ?? "";
    const untouched = cur === "" || cell.classList.contains("is-auto") || String(cur) === String(prev ?? "");
    if (!untouched || String(next) === String(cur)) return;
    if (item.kind === "count") { cell.querySelector("input").value = next; cell.classList.add("is-auto"); }
    else setTickValue(cell, next, true);
  });
}

function wireChecklist() {
  if (!canEditController) return;
  // Manual ✔/❌: tap to choose, tap the active one again to clear (an empty item shows the auto value again after saving).
  content.querySelectorAll(".tick-cell .tick").forEach((b) => b.addEventListener("click", () => {
    const cell = b.closest(".tick-cell");
    const cur = cell.querySelector('input[type="hidden"]').value;
    setTickValue(cell, cur === b.dataset.val ? "" : b.dataset.val, false);
  }));
  // Typing over an auto value makes it a manual one.
  content.querySelectorAll(".chk-cell input[type=number], .cell.is-auto input").forEach((i) =>
    i.addEventListener("input", () => i.closest(".cell").classList.remove("is-auto")));

  // PAX réel typed (e.g. Récap says 15, controller enters 18): refresh every auto item of that cabin right away.
  // An item is refreshed only if it is empty, still marked "auto", or still equal to what the rules gave BEFORE
  // this change (so a value the controller typed by hand is never overwritten).
  lastLive = liveSnapshot();
  if (!content.dataset.paxWired) {          // one delegated listener for the whole page, whatever re-renders happen
    content.dataset.paxWired = "1";
    // "input" = typing/spinner, "change" = keyboard "done"/blur, "paste"/"keyup" = keyboards that don't fire "input" reliably.
    for (const evt of ["input", "change", "keyup", "paste"]) {
      content.addEventListener(evt, (e) => {
        const t = e.target;
        if (!(t instanceof HTMLInputElement) || !/^pax-(ccl|ycl)-(aller|retour)-reel$/.test(t.id)) return;
        // "paste" fires before the value changes: look again right after.
        if (evt === "paste") setTimeout(() => refreshFromPax(t), 0); else refreshFromPax(t);
      });
    }
  }

  // "Calcul" (whole cabin) / "Détecter auto" (one PEQ group): re-run the rules with the PAX réel currently typed.
  content.querySelectorAll("[data-auto-section]").forEach((btn) => btn.addEventListener("click", () => {
    const only = btn.dataset.autoItems ? new Set(btn.dataset.autoItems.split(",")) : null;
    const live = liveSnapshot();
    const ctx = makeCtx(currentFlight, live);
    const sec = currentModel.sections.find((x) => x.id === btn.dataset.autoSection);
    let n = 0;
    content.querySelectorAll(`.chk-cell[data-section="${sec.id}"]`).forEach((cell) => {
      if (only && !only.has(cell.dataset.item)) return;
      const item = sec.items.find((i) => i.id === cell.dataset.item);
      const slot = item?.slots.find((sl) => sl.key === cell.dataset.slot);
      const v = item && slot ? autoValue(item, slot, ctx) : undefined;
      if (v === undefined) return;
      if (item.kind === "count") { cell.querySelector("input").value = v; cell.classList.add("is-auto"); }
      else setTickValue(cell, v, true);
      n++;
    });
    showToast(n ? `Valeurs détectées appliquées (${n})` : "Rien à détecter pour cette section.", n ? "success" : "info");
  }));
}

function dis() { return canEditController ? "" : "disabled"; }

/** Turns arbitrary text (special-meal codes, column titles, etc.) into a safe,
 *  unique-enough HTML id fragment for label/for pairing. */
function slug(s) {
  return String(s ?? "").toLowerCase().replace(/[^a-z0-9]+/g, "-").replace(/^-+|-+$/g, "") || "x";
}

/** Equipment count: a SELECT from 0 to `max` ("—" = not filled). A value saved earlier that is outside the range is kept as an extra option. */
function cellSelect(key, label, value, max) {
  const id = `fld-${slug(key)}`;
  const cur = value === null || value === undefined ? "" : String(value).trim();
  const opts = Array.from({ length: max + 1 }, (_, i) => String(i));
  if (cur !== "" && !opts.includes(cur)) opts.push(cur);
  return `<div class="cell"><label for="${id}">${label}</label><select id="${id}" data-field="${key}">
    <option value="" ${cur === "" ? "selected" : ""}>—</option>
    ${opts.map((o) => `<option value="${esc(o)}" ${o === cur ? "selected" : ""}>${esc(o)}</option>`).join("")}</select></div>`;
}

function cellInput(key, label, value, type = "text") {
  const id = `fld-${slug(key)}`;
  return `<div class="cell"><label for="${id}">${label}</label><input id="${id}" data-field="${key}" type="${type}" value="${esc(value)}"></div>`;
}

/** Renders one PEQ / C/CL / Y/CL block of Viande–Poulet–Poisson–Veg (Aller/Retour) inputs,
 *  plus a "Calculer" button where the checklist gives an automatic rule:
 *   - C/CL: DC25/DC21/DCC → percentage matrix (DC25 = 60/40/10%, DC21 & DCC = 40/40/30/10% (120%));
 *           any other code prestation (CF27, CC27, BF, ...) → plain PAX / 3 split.
 *   - PEQ : PAX / 3 spread across Viande / Poulet / Poisson.
 *   - Y/CL: no documented numeric rule, so "Calculer" just auto-fills "-" in every field. */
function prodGroup(title, cabinKey, imported, controller, hasRetour = true) {
  const legacy = cabinKey === "ccl" ? { viande: controller.viande, poulet: controller.poulet, poisson: controller.poisson, veg: controller.veg } : {};
  const prod = (controller.prod && controller.prod[cabinKey]) || legacy || {};
  const codePrestation = imported?.codePrestation || "";
  const inputType = cabinKey === "ycl" ? "text" : "number";

  let paxAllerPrevu, paxRetourPrevu, calcKind = null;
  if (cabinKey === "peq") {
    paxAllerPrevu = imported?.allerPrevu;
    paxRetourPrevu = imported?.retourPrevu;
    calcKind = "third";
  } else {
    paxAllerPrevu = imported?.paxAllerPrevu;
    paxRetourPrevu = imported?.paxRetourPrevu;
    if (cabinKey === "ccl") calcKind = "matrix";
    else if (cabinKey === "ycl") calcKind = "dash";
  }

  const calcBtn = (calcKind && canEditController)
    ? `<button type="button" class="btn ghost small" data-calc="${cabinKey}" data-calc-kind="${calcKind}" data-code="${esc(codePrestation)}" data-pax-aller-prevu="${esc(paxAllerPrevu)}" data-pax-retour-prevu="${esc(paxRetourPrevu)}">Calculer</button>`
    : "";

  const rows = PROD_ITEMS.map((item) => `
    <div class="cell"><label for="fld-prod-${cabinKey}-${item}-aller">${PROD_LABELS[item]} — Aller</label>
      <input id="fld-prod-${cabinKey}-${item}-aller" data-field="prod.${cabinKey}.${item}.aller" type="${inputType}" value="${esc(prod[item]?.aller)}" ${dis()}></div>
    ${hasRetour ? `
    <div class="cell"><label for="fld-prod-${cabinKey}-${item}-retour">${PROD_LABELS[item]} — Retour</label>
      <input id="fld-prod-${cabinKey}-${item}-retour" data-field="prod.${cabinKey}.${item}.retour" type="${inputType}" value="${esc(prod[item]?.retour)}" ${dis()}></div>` : ""}
  `).join("");

  return `
    <div class="prod-group">
      <div class="prod-group-title">
        <span>${title}${codePrestation ? ` <span class="prod-code">— ${ro(codePrestation)}</span>` : ""}</span>
        ${calcBtn}
      </div>
      <div class="field-grid">${rows}</div>
    </div>`;
}

/** « Cycle » line(s) of a cabin block, straight from the Récap: per leg, the cycle token (1go / 1back…) and the
 *  code(s) presta flown on it. Nothing is shown when the Récap gave no cycle for this block. */
function cycleRows(imported) {
  const info = cycleInfo(imported);
  if (!info.hasCycle) return "";
  const line = (leg) => info[leg].codes.length
    ? `<span class="cyc-line"><b>${LEG_LABEL[leg]}</b> <span class="cyc-tok">${esc(info[leg].cycles.join(" "))}</span> · ${esc(info[leg].codes.join(", "))}</span>` : "";
  return `<div class="kv-row cyc-row"><span class="k">Cycle</span><span class="v">${line("aller")}${line("retour")}</span></div>`;
}

/** « Fiche technique » buttons of a block, following the Récap cycle: every code presta (of the aller and/or
 *  retour leg) that has an uploaded PDF gets a button — PEQ → DC99, C/CL → DC25, Y/CL → DC55, any code works as
 *  long as the admin uploaded <CODE>.pdf. When aller and retour use different codes, each button says which leg. */
function techSheetButtons(imported) {
  const { entries, legCount } = matchTechSheetsByCycle(cycleInfo(imported), techSheetCodes);
  if (!entries.length) return "";
  return `<div class="ts-row">${entries.map(({ code, legs }) => {
    const legTag = legs.length === 1 && legCount > 1 ? ` · ${LEG_LABEL[legs[0]]}` : "";
    const codeTag = entries.length > 1 ? ` ${esc(code)}` : "";
    return `<button type="button" class="btn ghost small ts-btn" data-tech-sheet="${esc(code)}" data-leg="${legs.length === 1 && legCount > 1 ? legs[0] : ""}" title="Fiche technique ${esc(code)}">${icon("fileText", 14)} Fiche technique${codeTag}${legTag}</button>`;
  }).join("")}</div>`;
}

function cabinColumn(title, imported, specialKey, controller, hasRetour = true) {
  const codeP = imported?.codePrestation || "";
  const specials = imported?.specialMeals || [];
  const specialsReel = controller.specialMealsReel || {};
  const showPax = specialKey !== null;
  const colSlug = slug(specialKey || title);
  return `
    <div class="col">
      <div class="col-title">${title}</div>
      <div class="kv-row"><span class="k">Code Prestation</span><span class="v">${ro(codeP)}</span></div>
      ${cycleRows(imported)}
      ${techSheetButtons(imported)}
      ${!showPax ? `
        <div class="kv-row"><span class="k">NBR PNC /A</span><span class="v">${ro(imported?.allerPrevu)}</span></div>
        ${hasRetour ? `<div class="kv-row"><span class="k">NBR PNC /R</span><span class="v">${ro(imported?.retourPrevu)}</span></div>` : ""}` : ""}
      ${showPax ? `
        <div class="pax-box">
          <div class="pax-title">PAX Aller</div>
          <div class="pax-line"><span class="cell-label">Prévu</span><span class="prevu">${ro(imported?.paxAllerPrevu)}</span>
            <label class="sr-only" for="pax-${colSlug}-aller-reel">PAX Aller — Réel (${title})</label>
            <input id="pax-${colSlug}-aller-reel" class="reel" type="number" data-field="pax.${specialKey}.aller" value="${esc(controller[specialKey==="yCl"?"paxAllerReel":"paxAllerReelCcl"] )}" placeholder="Réel"></div>
          ${hasRetour ? `
          <div class="pax-title" style="margin-top:6px">PAX Retour</div>
          <div class="pax-line"><span class="cell-label">Prévu</span><span class="prevu">${ro(imported?.paxRetourPrevu)}</span>
            <label class="sr-only" for="pax-${colSlug}-retour-reel">PAX Retour — Réel (${title})</label>
            <input id="pax-${colSlug}-retour-reel" class="reel" type="number" data-field="pax.${specialKey}.retour" value="${esc(controller[specialKey==="yCl"?"paxRetourReel":"paxRetourReelCcl"])}" placeholder="Réel"></div>` : ""}
        </div>` : ""}
      ${specials.length ? `
        <div class="pax-box">
          <div class="pax-title">Special Meals</div>
          ${specials.map((s) => `
            <div class="pax-line">
              <span class="cell-label">${s.code}</span>
              <span class="prevu" title="${hasRetour ? "Prévu Aller/Retour" : "Prévu Aller"}">${ro(s.allerPrevu)}${hasRetour ? `/${ro(s.retourPrevu)}` : ""}</span>
              <label class="sr-only" for="special-${colSlug}-${slug(s.code)}">${s.code} — Réel (${title})</label>
              <input id="special-${colSlug}-${slug(s.code)}" class="reel" type="number" data-field="special.${s.code}" value="${esc(specialsReel[s.code])}" placeholder="Réel">
            </div>`).join("")}
        </div>` : ""}
    </div>`;
}

function rawTable(label, block) {
  if (!block || !block.raw || !block.raw.length) return "";
  return `
    <div class="panel" style="margin-top:10px">
      <div class="panel-title">${label.toUpperCase()} — lignes brutes du Récap</div>
      <table class="raw-table">
        <thead><tr><th>Code</th><th>Cycle</th><th class="num">Nombre</th></tr></thead>
        <tbody>${block.raw.map((it) => `<tr><td>${esc(it.code)}</td><td>${esc(it.cycle)}</td><td class="num">${ro(it.count)}</td></tr>`).join("")}</tbody>
      </table>
    </div>`;
}

async function save(f) {
  const changes = {};
  content.querySelectorAll("[data-field]").forEach((el) => {
    const key = el.getAttribute("data-field");
    let value = el.value === "" ? null : el.value;
    if (el.type === "number" && value !== null) value = Number(value);

    if (key.startsWith("checklist.")) {
      changes.checklist = changes.checklist || { ...(f.controller?.checklist || {}) };
      changes.checklist[key.slice("checklist.".length)] = value;
    } else if (key.startsWith("special.")) {
      changes.specialMealsReel = changes.specialMealsReel || { ...(f.controller?.specialMealsReel || {}) };
      changes.specialMealsReel[key.slice("special.".length)] = value;
    } else if (key.startsWith("pax.")) {
      const [, cabin, leg] = key.split(".");
      if (cabin === "yCl") {
        if (leg === "aller") changes.paxAllerReel = value;
        else changes.paxRetourReel = value;
      } else {
        if (leg === "aller") changes.paxAllerReelCcl = value;
        else changes.paxRetourReelCcl = value;
      }
    } else if (key.startsWith("prod.")) {
      const [, cabinKey, item, leg] = key.split(".");
      changes.prod = changes.prod || { ...(f.controller?.prod || {}) };
      changes.prod[cabinKey] = { ...(changes.prod[cabinKey] || f.controller?.prod?.[cabinKey] || {}) };
      changes.prod[cabinKey][item] = { ...(changes.prod[cabinKey][item] || f.controller?.prod?.[cabinKey]?.[item] || {}) };
      changes.prod[cabinKey][item][leg] = value;
    } else {
      changes[key] = value;
    }
  });

  const wasCompleted = flightStatus(f) === "completed";

  const btn = document.getElementById("saveBtn");
  btn.disabled = true;
  btn.textContent = "Enregistrement…";
  try {
    await updateControllerFields(f.id, changes, f, profile);
    const updated = await getFlight(f.id);
    const newStatus = flightStatus(updated);
    const STATUS_LABELS = { pending: "en attente", in_progress: "en cours", completed: "terminé" };
    showToast(`Enregistré — Statut : ${STATUS_LABELS[newStatus] || newStatus}`, "success");
    // Controller finished the flight (both legs now filled in) — give an audible cue,
    // once, right at the moment it flips to "completed".
    if (profile.role === "controller" && !wasCompleted && newStatus === "completed") {
      playCompletionChime();
    }
    render(updated);
  } catch (err) {
    console.error("Erreur d'enregistrement", err);
    showToast("Erreur d'enregistrement : " + err.message, "error", 6000);
    btn.disabled = false;
    btn.textContent = "Enregistrer";
  }
}

/** Short two-tone chime (Web Audio, no asset file needed) played once when a controller's
 *  save completes a flight (both Aller and Retour réel filled in). */
function playCompletionChime() {
  try {
    const Ctx = window.AudioContext || window.webkitAudioContext;
    if (!Ctx) return;
    const ctx = new Ctx();
    const now = ctx.currentTime;
    [660, 880].forEach((freq, i) => {
      const start = now + i * 0.15;
      const osc = ctx.createOscillator();
      const gain = ctx.createGain();
      osc.type = "sine";
      osc.frequency.value = freq;
      gain.gain.setValueAtTime(0, start);
      gain.gain.linearRampToValueAtTime(0.28, start + 0.02);
      gain.gain.exponentialRampToValueAtTime(0.001, start + 0.32);
      osc.connect(gain).connect(ctx.destination);
      osc.start(start);
      osc.stop(start + 0.34);
    });
    setTimeout(() => ctx.close(), 900);
  } catch (err) {
    // Autoplay/audio restrictions or an unsupported browser — fail silently,
    // this is a nice-to-have cue, not a functional requirement.
  }
}

async function removeFlight(f) {
  if (!(await confirmDialog({ title: "Supprimer ce vol ?", message: `Le vol ${f.flightNumber} du ${f.date || ""} sera supprimé définitivement, avec toutes les données saisies par les contrôleurs.`, confirmText: "Supprimer", danger: true }))) return;
  try { await deleteFlight(f.id); }
  catch (err) { showToast("Suppression impossible : " + err.message, "error", 5000); return; }
  location.href = "flights.html";
}
