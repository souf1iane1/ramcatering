import { requireAuth, showToast } from "./auth.js";
import { icon } from "./icons.js";
import { listFlights, flightStatus, hasRetourLeg } from "./data.js";
import { ringHtml } from "./ring.js";
import { exportFlightsXlsx, exportFlightsPdf } from "./export.js";
import { plansCache, loadPlans, planningNames, assignDay } from "./assign.js";
import { openFlightEditor } from "./flight-editor.js";
import { confirmDialog } from "./confirm.js";
import { openManualSplit } from "./manual-split.js";
import { listUsers, saveShiftPlan, deleteShiftPlan, deleteFlight } from "./api.js";
import { SHIFTS, SHIFT_ORDER, sameController, loadTime, sortInShift, rangeLabel } from "./shifts.js";

const { profile, user } = await requireAuth("flights.html");
const isAdmin = profile?.role === "admin";
const shiftFilter = document.getElementById("shiftFilter");
const planPanel = document.getElementById("planPanel");
if (!isAdmin) { shiftFilter.value = ""; shiftFilter.style.display = "none"; } // controllers: shift is detected automatically

// Controllers the admin can pick from (every account with the "controller" role).
let controllerNames = [];
if (isAdmin) {
  try {
    controllerNames = (await listUsers("controller")).map((u) => u.name).filter(Boolean).sort((a, b) => a.localeCompare(b));
  } catch (e) { console.warn("controllers list:", e); }
}


const list = document.getElementById("list");
const search = document.getElementById("search");
const statusFilter = document.getElementById("statusFilter");
const catFilter = document.getElementById("catFilter");
const dateFilter = document.getElementById("dateFilter");

let flights = await listFlights();

// Display/import safety: AT only.
flights = flights.filter(f => /^AT\d{3,4}$/i.test(String(f.flightNumber || "").replace(/\s+/g, "")));
flights.forEach(f => f.status = flightStatus(f));

const dates = [...new Set(flights.map(f => getFlightDate(f)).filter(Boolean))].sort().reverse();

// Default to the newest recap date.
if (dateFilter && dates.length) {
  dateFilter.value = !isAdmin && dates.includes(toISO(new Date())) ? toISO(new Date()) : dates[0];
  dateFilter.max = dates[0];
  dateFilter.min = dates[dates.length - 1];
}

[search, statusFilter, catFilter, dateFilter, shiftFilter].filter(Boolean).forEach(el => {
  el.addEventListener("input", render);
  el.addEventListener("change", render);
});

// ---- Admin: select flights and delete them (or delete everything currently shown) ----
const selectModeBtn = document.getElementById("selectModeBtn");
const selectBar = document.getElementById("selectBar");
let selectMode = false;
let editMode = false;
const picked = new Set();
const addFlightBtn = document.getElementById("addFlightBtn");
const editModeBtn = document.getElementById("editModeBtn");
const manualSplitBtn = document.getElementById("manualSplitBtn");
let curDay = { date: "", flights: [], plans: {} }; // the day currently displayed (set by render)
if (isAdmin) {
  manualSplitBtn.hidden = false; manualSplitBtn.innerHTML = `${icon("userCheck", 14)} Répartir manuellement`;
  manualSplitBtn.addEventListener("click", () => {
    if (!curDay.date || !curDay.flights.length) { showToast("Aucun vol à répartir pour cette date.", "error", 3000); return; }
    openManualSplit({ date: curDay.date, flights: curDay.flights, controllerNames, plans: curDay.plans, onSaved: async (fns = []) => { await render(); flashFlights(fns); } });
  });
}
if (!isAdmin) { // controllers never see the admin tools: remove them from the page altogether
  [manualSplitBtn, addFlightBtn, editModeBtn, selectModeBtn, selectBar].forEach((el) => el?.remove());
}
if (isAdmin) {
  addFlightBtn.hidden = false; addFlightBtn.innerHTML = `${icon("plus", 14)} Ajouter un vol`;
  editModeBtn.hidden = false; editModeBtn.innerHTML = `${icon("edit", 14)} Modifier des vols`;
  addFlightBtn.addEventListener("click", () => openFlightEditor({ defaultDate: dateFilter?.value || "", onSaved: afterEditorSave }));
  editModeBtn.addEventListener("click", () => { editMode = !editMode; if (editMode) { selectMode = false; picked.clear(); } updateModeButtons(); render(); });
}
function updateModeButtons() {
  editModeBtn?.classList.toggle("amber", editMode);
  selectModeBtn?.classList.toggle("amber", selectMode);
}
/** Briefly highlights flights (by number) and scrolls to the first one — shows what a manual split just changed. */
function flashFlights(fns) {
  const rows = [...list.querySelectorAll(".flight-row")].filter((r) => fns.includes((r.querySelector(".flight-num")?.textContent || "").trim()));
  rows.forEach((r) => { r.classList.remove("flash"); void r.offsetWidth; r.classList.add("flash"); });
  rows[0]?.scrollIntoView({ block: "center", behavior: "smooth" });
}
/** After adding/editing a flight: refresh our copy of the list and show the flight's day. */
function afterEditorSave(saved, isNew) {
  saved.status = flightStatus(saved);
  const i = flights.findIndex((x) => x.id === saved.id);
  if (i >= 0) flights[i] = saved; else flights.push(saved);
  const d = getFlightDate(saved);
  if (dateFilter && d) {
    const all = flights.map((x) => getFlightDate(x)).filter(Boolean).sort();
    dateFilter.min = all[0]; dateFilter.max = all[all.length - 1];
    if (isNew) dateFilter.value = d;
  }
  render();
}
if (isAdmin && selectModeBtn) {
  selectModeBtn.hidden = false;
  selectModeBtn.innerHTML = `${icon("trash", 14)} Supprimer des vols`;
  selectModeBtn.addEventListener("click", () => setSelectMode(!selectMode));
}
function setSelectMode(on) {
  selectMode = on && isAdmin;
  if (selectMode) editMode = false;
  picked.clear();
  updateModeButtons();
  render();
}
function renderSelectBar() {
  if (!selectBar) return;
  if (editMode) {
    selectBar.hidden = false;
    selectBar.innerHTML = `<span class="sel-count">${icon("edit", 16)} Mode modification : cliquez sur un vol pour modifier ses informations.</span>
      <button type="button" class="btn ghost small" data-act="stopEdit">Terminer</button>`;
    return;
  }
  selectBar.hidden = !selectMode;
  if (!selectMode) { selectBar.innerHTML = ""; return; }
  const n = picked.size, total = lastFiltered.length;
  selectBar.innerHTML = `
    <span class="sel-count">${n} vol${n > 1 ? "s" : ""} sélectionné${n > 1 ? "s" : ""} / ${total} affiché${total > 1 ? "s" : ""}</span>
    <button type="button" class="btn ghost small" data-act="all">${icon("checkSquare", 14)} Tout sélectionner</button>
    <button type="button" class="btn ghost small" data-act="none" ${n ? "" : "disabled"}>Désélectionner</button>
    <button type="button" class="btn danger small" data-act="delSel" ${n ? "" : "disabled"}>${icon("trash", 14)} Supprimer la sélection (${n})</button>
    <button type="button" class="btn ghost danger small" data-act="delAll" ${total ? "" : "disabled"}>${icon("trash", 14)} Supprimer tous les vols affichés (${total})</button>
    <button type="button" class="btn ghost small" data-act="cancel">Annuler</button>`;
}
selectBar?.addEventListener("click", (e) => {
  const act = e.target.closest("[data-act]")?.dataset.act;
  if (!act) return;
  if (act === "all") { lastFiltered.forEach((f) => picked.add(f.id)); refreshPicked(); }
  else if (act === "none") { picked.clear(); refreshPicked(); }
  else if (act === "cancel") setSelectMode(false);
  else if (act === "stopEdit") { editMode = false; updateModeButtons(); render(); }
  else if (act === "delSel") deleteMany(flights.filter((f) => picked.has(f.id)), "la sélection");
  else if (act === "delAll") deleteMany([...lastFiltered], "tous les vols affichés");
});
function refreshPicked() {
  list.querySelectorAll(".flight-row").forEach((row) => {
    const on = picked.has(row.dataset.id);
    row.classList.toggle("picked", on);
    const cb = row.querySelector(".sel"); if (cb) cb.checked = on;
  });
  renderSelectBar();
}
list.addEventListener("click", (e) => {
  if (editMode) {
    const row = e.target.closest(".flight-row");
    if (!row) return;
    e.preventDefault(); // open the editor instead of the flight page
    const fl = flights.find((x) => x.id === row.dataset.id);
    if (fl) openFlightEditor({ flight: fl, onSaved: afterEditorSave });
    return;
  }
  if (!selectMode) return;
  const row = e.target.closest(".flight-row");
  if (!row) return;
  e.preventDefault(); // select instead of opening the flight
  const id = row.dataset.id;
  if (picked.has(id)) picked.delete(id); else picked.add(id);
  refreshPicked();
});
async function deleteMany(items, label) {
  if (!items.length) return;
  const n = items.length;
  const ok = await confirmDialog({
    title: n > 1 ? `Supprimer ${n} vols ?` : "Supprimer ce vol ?",
    message: `Vous allez supprimer définitivement ${label} (${n} vol${n > 1 ? "s" : ""}).`,
    items: items.map((f) => f.flightNumber),
    confirmText: n > 1 ? `Supprimer ${n} vols` : "Supprimer",
    danger: true,
  });
  if (!ok) return;
  selectBar.querySelectorAll("button").forEach((b) => { b.disabled = true; });
  const counter = selectBar.querySelector(".sel-count");
  let done = 0;
  const failed = [];
  const queue = [...items];
  const worker = async () => {
    while (queue.length) {
      const f = queue.shift();
      try { await deleteFlight(f.id); flights = flights.filter((x) => x.id !== f.id); picked.delete(f.id); done++; if (counter) counter.textContent = `Suppression en cours… ${done}/${n}`; }
      catch (err) { failed.push(`${f.flightNumber} (${err.message})`); }
    }
  };
  await Promise.all([worker(), worker(), worker(), worker()]);
  if (failed.length) showToast(`${done} supprimé(s), ${failed.length} échec(s) : ${failed.slice(0, 3).join(", ")}`, "error", 7000);
  else showToast(`${done} vol${done > 1 ? "s" : ""} supprimé${done > 1 ? "s" : ""}.`, "success", 3500);
  if (!flights.some((f) => getFlightDate(f) === dateFilter?.value)) {
    // the displayed day is now empty: move to the newest remaining recap date
    const left = [...new Set(flights.map((f) => getFlightDate(f)).filter(Boolean))].sort().reverse();
    if (dateFilter && left.length) { dateFilter.value = left[0]; dateFilter.max = left[0]; dateFilter.min = left[left.length - 1]; }
  }
  setSelectMode(false);
}

let renderToken = 0; // declared before the first render() call (was a TDZ error)
let lastFiltered = [];
for (const [id, fn] of [["exportXlsBtn", exportFlightsXlsx], ["exportPdfBtn", exportFlightsPdf]]) {
  document.getElementById(id)?.addEventListener("click", async (e) => {
    const b = e.currentTarget; b.disabled = true;
    try { await fn(lastFiltered); } catch (err) { console.error(err); showToast("Export impossible : " + err.message, "error", 5000); }
    finally { b.disabled = false; }
  });
}

render();

function getFlightDate(f) {
  const raw = f?.date;
  if (raw && typeof raw === "object" && typeof raw.toDate === "function") {
    return toISO(raw.toDate());
  }
  if (raw instanceof Date) return toISO(raw);
  const v = String(raw || "").trim();

  // ISO date
  if (/^\d{4}-\d{2}-\d{2}$/.test(v)) return v;

  // DD/MM/YYYY
  let m = v.match(/^(\d{2})[\/-](\d{2})[\/-](\d{4})$/);
  if (m) return `${m[3]}-${m[2]}-${m[1]}`;

  // If date is absent, recover it from the flight id: YYYY-MM-DD_AT208
  const id = String(f?.id || "");
  m = id.match(/^(\d{4}-\d{2}-\d{2})_AT\d{3,4}$/i);
  return m ? m[1] : "";
}

function toISO(d) {
  const y = d.getFullYear();
  const m = String(d.getMonth() + 1).padStart(2, "0");
  const day = String(d.getDate()).padStart(2, "0");
  return `${y}-${m}-${day}`;
}

function displayDate(iso) {
  const m = String(iso || "").match(/^(\d{4})-(\d{2})-(\d{2})$/);
  return m ? `${m[3]}/${m[2]}/${m[1]}` : (iso || "");
}

async function render() {
  const token = ++renderToken;
  const q = search?.value.trim().toUpperCase() || "";
  const status = statusFilter?.value || "";
  const category = catFilter?.value || "";
  const selectedDate = dateFilter?.value || "";
  const shiftSel = shiftFilter?.value || "";

  const ofDate = flights.filter((f) => !selectedDate || getFlightDate(f) === selectedDate);
  const { saved: plans, effective } = await assignDay(ofDate, selectedDate, getFlightDate);
  if (token !== renderToken) return; // a newer render started meanwhile
  curDay = { date: selectedDate, flights: ofDate, plans };

  // A controller only sees the flights assigned to him by the planning (shift detected automatically).
  const hasAssign = ofDate.some((f) => f.assignedTo);
  const mine = isAdmin ? ofDate : (hasAssign ? ofDate.filter((f) => sameController(f.assignedTo, profile?.name)) : ofDate);

  const filtered = mine.filter((f) => {
    const qOK = !q || String(f.flightNumber || "").toUpperCase().includes(q);
    const statusOK = !status || f.status === status;
    const catOK = !category || f.aircraftCategory === category;
    const shiftOK = !shiftSel || f.shift === shiftSel;
    return qOK && statusOK && catOK && shiftOK;
  });

  // Group by shift (Matin → Après-midi → Nuit), chronological inside each shift.
  const groups = [...SHIFT_ORDER, null].map((k) => ({ k, items: sortInShift(filtered.filter((f) => f.shift === k), k) })).filter((g) => g.items.length);
  lastFiltered = groups.flatMap((g) => g.items);

  list.innerHTML = groups.length
    ? groups.map((g) => groupHtml(g, effective[g.k], ofDate.filter((f) => f.shift === g.k))).join("")
    : `<div class="empty-state">Aucun vol pour ${selectedDate ? displayDate(selectedDate) : "ces critères"}.</div>`;

  renderSelectBar();
  if (isAdmin) planPanel.innerHTML = ""; // admin: just the flights (split is done with « Répartir manuellement »)
  else renderMyShift(mine, hasAssign, selectedDate);
}

/** Controller banner: detected shift(s) + personal progress ring. */
function renderMyShift(mine, hasAssign, date) {
  if (!date) { planPanel.innerHTML = ""; return; }
  if (!hasAssign) { planPanel.innerHTML = `<div class="my-shift"><span>Aucun planning enregistré pour le ${displayDate(date)} — tous les vols sont affichés.</span></div>`; return; }
  if (!mine.length) { planPanel.innerHTML = `<div class="my-shift"><span>Aucun vol affecté pour le ${displayDate(date)} (repos ou pas de vacation).</span></div>`; return; }
  const shifts = SHIFT_ORDER.filter((k) => mine.some((f) => f.shift === k)).map((k) => SHIFTS[k].label).join(" + ");
  const done = mine.filter((f) => f.status === "completed").length;
  planPanel.innerHTML = `<div class="my-shift">${ringHtml(done, mine.length, 56)}
    <span><strong>Votre shift : ${shifts}</strong><br>${done} / ${mine.length} vols contrôlés</span></div>`;
}

function groupHtml({ k, items }, plan, allOfShift) {
  const info = SHIFTS[k];
  const parts = plan?.controllers?.length
    ? plan.controllers.filter((n) => isAdmin || sameController(n, profile?.name)).map((n) => ({ name: n, flights: sortInShift(items.filter((f) => f.assignedTo === n), k), all: allOfShift.filter((f) => f.assignedTo === n) })).filter((p) => p.flights.length)
        .map((p) => `<span class="plan-chip">${ringHtml(p.all.filter((f) => f.status === "completed").length, p.all.length, 34)}
          <span>${icon("user", 13)} ${esc(p.name)} · ${p.flights.length} vol${p.flights.length > 1 ? "s" : ""} (${rangeLabel(p.flights)})</span></span>`).join("")
    : "";
  if (isAdmin) return `<section class="shift-group">${items.map(rowHtml).join("")}</section>`; // admin: just the flights
  return `<section class="shift-group">
    <div class="shift-head shift-${k || "none"}">
      <strong>${info ? info.label : "Sans horaire"}</strong>
      <span class="shift-time">${info ? info.range : ""}</span>
      <span class="shift-range">${rangeLabel(items)}</span>
      <span class="shift-count">${items.length} vol${items.length > 1 ? "s" : ""}</span>
    </div>
    ${parts ? `<div class="plan-chips">${parts}</div>` : ""}
    ${items.map(rowHtml).join("")}
  </section>`;
}

const esc = (v) => String(v ?? "").replace(/[&<>"']/g, (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]));

function rowHtml(f) {
  const a = f.controller?.paxAllerReel != null;
  const r = f.controller?.paxRetourReel != null;
  const retour = hasRetourLeg(f);
  const d = getFlightDate(f);
  return `
    <a class="flight-row${selectMode || editMode ? " selecting" : ""}${selectMode && picked.has(f.id) ? " picked" : ""}" data-id="${esc(f.id)}" href="flight.html?id=${encodeURIComponent(f.id)}">
      ${editMode ? `<span class="row-edit" title="Modifier">${icon("edit", 16)}</span>` : ""}
      ${selectMode ? `<input type="checkbox" class="sel" ${picked.has(f.id) ? "checked" : ""} aria-label="Sélectionner ${esc(f.flightNumber)}">` : ""}
      <span class="flight-num">${f.flightNumber}</span>
      <span class="flight-meta">${displayDate(d)} · Chargt ${loadTime(f) || "--:--"} · Dép ${f.heureDepart || "--:--"} · ${f.aircraftType || "?"} · ${f.numEnregistrement || ""}</span>
      <span class="flight-cat">${String(f.aircraftCategory || "").replace("_", " ")}</span>
      <span class="leg-marks"><span class="${a ? "done" : ""}">A${a ? icon("check", 12) : icon("circle", 12)}</span>${retour ? `<span class="${r ? "done" : ""}">R${r ? icon("check", 12) : icon("circle", 12)}</span>` : ""}</span>
      ${isAdmin && f.assignedTo ? `<span class="assigned-name">${icon("arrowRight", 13)} ${esc(f.assignedTo)}</span>` : ""}
      ${profile?.role === "admin" && f.updatedByName ? `<span class="controller-name">${icon("user", 13)} ${f.updatedByName}</span>` : ""}
      <span class="status-badge ${f.status}">${String(f.status || "").replace("_"," ")}</span>
    </a>`;
}
