// Circular progress ("cycle") showing the share of flights already controlled, 0% -> 100%.
export function ringHtml(done, total, size = 44) {
  const pct = total ? Math.round((done / total) * 100) : 0;
  const c = 2 * Math.PI * 18;
  const cls = pct >= 100 ? "ok" : pct >= 50 ? "mid" : "low";
  return `<span class="ring ${cls}" style="--s:${size}px" role="img" aria-label="${pct}% — ${done} sur ${total} vols contrôlés" title="${done} / ${total} vols contrôlés">
    <svg viewBox="0 0 44 44" aria-hidden="true"><circle class="ring-bg" cx="22" cy="22" r="18"/>
    <circle class="ring-fg" cx="22" cy="22" r="18" transform="rotate(-90 22 22)" style="--c:${c.toFixed(1)};stroke-dasharray:${c.toFixed(1)};stroke-dashoffset:${(c * (1 - pct / 100)).toFixed(1)}"/></svg>
    <b>${pct}%</b></span>`;
}
