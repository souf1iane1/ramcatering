import * as api from "./api.js";

/** Uploads one parsed Récap. The server writes the recap record and upserts every flight,
 *  updating only the `imported` half and leaving any existing `controller` data untouched. */
export async function saveRecapUpload({ fileName, date, flights }) {
  return api.uploadRecap({ fileName, date: date || null, flights });
}

export const listFlights = () => api.listFlights();
export const getFlight = (flightId) => api.getFlight(flightId);

/** A flight only has a "Retour" leg if the imported Récap actually carried "back"
 *  cycle data for it (see excel-parser.js: retourPrevu stays null when no "back"
 *  line exists for that flight). Flights with none — GO-only, one-way — never get
 *  a retour leg, so their completion never depends on filling in a Retour value.
 *  (The server applies the same rule when it stores `status`.) */
export function hasRetourLeg(flight) {
  const im = flight?.imported || {};
  const vals = [
    im.yCl?.paxRetourPrevu, im.cCl?.paxRetourPrevu,
    im.peq?.retourPrevu, im.bob?.retourPrevu,
  ];
  return vals.some((v) => v !== null && v !== undefined);
}

export function flightStatus(flight) {
  const c = flight.controller || {};
  const allerDone = c.paxAllerReel !== null && c.paxAllerReel !== undefined && c.paxAllerReel !== "";
  const retourDone = c.paxRetourReel !== null && c.paxRetourReel !== undefined && c.paxRetourReel !== "";

  // GO-only flight (no Retour leg in the Récap): there's no second leg to wait for, so
  // the moment a controller has saved anything on it at all, it's done.
  if (!hasRetourLeg(flight)) return flight.updatedByName ? "completed" : "pending";

  if (allerDone && retourDone) return "completed";
  if (allerDone || retourDone) return "in_progress";
  return "pending";
}

/** Saves controller fields. The server merges them, recomputes the status and appends one
 *  audit-log entry per changed field. (`flight` / `user` kept for call-site compatibility.) */
export async function updateControllerFields(flightId, changes) {
  return api.updateController(flightId, changes);
}

export const listAuditLogs = (max = 200) => api.listAuditLogs(max);
export const listRecaps = (max = 20) => api.listRecaps(max);
