import { requireAuth, showToast } from "./auth.js";
import { icon } from "./icons.js";
import { listLoadingPlans, uploadLoadingPlan, deleteLoadingPlan, listTechSheets, uploadTechSheet, deleteTechSheet, ApiError } from "./api.js";
import { confirmDialog } from "./confirm.js";
import { openLoadingPlanViewer } from "./loading-plan-viewer.js";
import { planCodeFromFileName, isValidPlanCode, MAX_PLAN_BYTES } from "./loading-plans.js";

await requireAuth("admin/loading-plans.html");

const esc = (v) => String(v ?? "").replace(/[&<>"']/g, (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]));
const fmtSize = (n) => (n == null ? "" : n < 1024 * 1024 ? `${Math.round(n / 1024)} Ko` : `${(n / 1024 / 1024).toFixed(1)} Mo`);
const fmtDate = (iso) => { const ts = iso?.toDate ? iso.toDate() : null; if (!ts) return ""; const p = (n) => String(n).padStart(2, "0"); return `${p(ts.getDate())}/${p(ts.getMonth() + 1)}/${ts.getFullYear()} ${p(ts.getHours())}:${p(ts.getMinutes())}`; };

function fileToBase64(file) {
  return new Promise((resolve, reject) => {
    const r = new FileReader();
    r.onload = () => resolve(String(r.result).split(",")[1] || "");
    r.onerror = () => reject(new Error("Lecture du fichier impossible."));
    r.readAsDataURL(file);
  });
}

/** Wires one upload zone + list. Used twice: « Plan de chargement » (by aircraft type) and « Fiche technique » (by code presta). */
async function setupStore({ prefix, kind, list: listFn, upload, remove, example, nameHint, deleteTitle, deleteMsg, deletedToast, savedWhat, empty }) {
  const dropzone = document.getElementById(`${prefix}Dropzone`);
  const fileInput = document.getElementById(`${prefix}FileInput`);
  const dzText = document.getElementById(`${prefix}DzText`);
  const msg = document.getElementById(`${prefix}Msg`);
  const list = document.getElementById(`${prefix}List`);
  const dzDefault = dzText.textContent;

  ["dragover", "dragleave", "drop"].forEach((evt) =>
    dropzone.addEventListener(evt, (e) => {
      e.preventDefault();
      dropzone.classList.toggle("drag", evt === "dragover");
      if (evt === "drop" && e.dataTransfer.files.length) handleFiles([...e.dataTransfer.files]);
    })
  );
  fileInput.addEventListener("change", () => { if (fileInput.files.length) handleFiles([...fileInput.files]); fileInput.value = ""; });

  async function handleFiles(files) {
    msg.innerHTML = "";
    const errors = [];
    let okCount = 0;
    for (const file of files) {
      const type = planCodeFromFileName(file.name);
      if (!/\.pdf$/i.test(file.name)) { errors.push(`${file.name} : seuls les PDF sont acceptés.`); continue; }
      if (!isValidPlanCode(type)) { errors.push(`${file.name} : nom de fichier invalide — ${nameHint}`); continue; }
      if (file.size > MAX_PLAN_BYTES) { errors.push(`${file.name} : trop volumineux (max ${Math.round(MAX_PLAN_BYTES / 1024 / 1024)} Mo).`); continue; }
      dzText.textContent = `Envoi de « ${file.name} »…`;
      try {
        const dataBase64 = await fileToBase64(file);
        await upload(type, file.name, dataBase64);
        okCount++;
      } catch (err) {
        errors.push(`${file.name} : ${err instanceof ApiError ? err.message : "échec de l'envoi."}`);
      }
    }
    dzText.textContent = dzDefault;
    if (okCount) showToast(`${okCount} ${savedWhat} enregistré(s).`, "success");
    if (errors.length) msg.innerHTML = `<div class="error-msg">${errors.map(esc).join("<br>")}</div>`;
    await refresh();
  }

  async function refresh() {
    let items = [];
    try { items = (await listFn()) ?? []; } catch (err) {
      list.innerHTML = `<div class="error-msg">${esc(err instanceof ApiError ? err.message : "Chargement impossible.")}</div>`;
      return;
    }
    if (!Array.isArray(items) || !items.length) { list.innerHTML = `<div class="empty-state">${esc(empty)}</div>`; return; }
    list.innerHTML = `<div class="lp-admin-list">${items.map((p) => `
      <div class="lp-admin-row" data-type="${esc(p.type)}">
        <div class="lp-admin-type">${esc(p.type)}</div>
        <div class="lp-admin-meta">
          <span class="lp-admin-name">${esc(p.fileName)}</span>
          <span class="lp-admin-sub">${esc(fmtSize(p.sizeBytes))} · ${esc(p.uploadedBy)} · ${esc(fmtDate(p.uploadedAt))}</span>
        </div>
        <div class="lp-admin-actions">
          <button type="button" class="btn ghost small lp-view" title="Voir">${icon("fileText", 14)} Voir</button>
          <button type="button" class="btn ghost small lp-del" title="Supprimer">${icon("trash", 14)}</button>
        </div>
      </div>`).join("")}</div>`;

    list.querySelectorAll(".lp-view").forEach((btn) =>
      btn.addEventListener("click", () => {
        const type = btn.closest(".lp-admin-row").dataset.type;
        openLoadingPlanViewer({ type, label: type, kind });
      })
    );
    list.querySelectorAll(".lp-del").forEach((btn) =>
      btn.addEventListener("click", async () => {
        const type = btn.closest(".lp-admin-row").dataset.type;
        const ok = await confirmDialog({ title: deleteTitle, message: deleteMsg(type), confirmText: "Supprimer", danger: true });
        if (!ok) return;
        try {
          await remove(type);
          showToast(deletedToast(type), "success");
          await refresh();
        } catch (err) {
          showToast(err instanceof ApiError ? err.message : "Suppression impossible.", "error");
        }
      })
    );
  }

  await refresh();
}

await setupStore({
  prefix: "lp", kind: "plan", list: listLoadingPlans, upload: uploadLoadingPlan, remove: deleteLoadingPlan,
  nameHint: "nommez-le d'après le type d'appareil (ex. 788.pdf, 788M.pdf, 73H.pdf).",
  deleteTitle: "Supprimer ce plan ?",
  deleteMsg: (t) => `Le plan de chargement « ${t} » sera supprimé. Les contrôleurs n'y auront plus accès.`,
  deletedToast: (t) => `Plan ${t} supprimé.`,
  savedWhat: "plan(s)", empty: "Aucun plan de chargement en ligne pour l'instant.",
});

await setupStore({
  prefix: "ts", kind: "fiche", list: listTechSheets, upload: uploadTechSheet, remove: deleteTechSheet,
  nameHint: "nommez-le d'après le code prestation (ex. DC25.pdf, BC55.pdf, CF99.pdf).",
  deleteTitle: "Supprimer cette fiche ?",
  deleteMsg: (t) => `La fiche technique « ${t} » sera supprimée. Les contrôleurs n'y auront plus accès.`,
  deletedToast: (t) => `Fiche ${t} supprimée.`,
  savedWhat: "fiche(s)", empty: "Aucune fiche technique en ligne pour l'instant.",
});
