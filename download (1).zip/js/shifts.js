// Shift logic + splitting of a shift's flights between controllers.
//
// SHIFT OF A FLIGHT = its POSITION in the Récap (see RECAP_ANCHORS / assignRecapShifts below), computed once at
// import and stored on the flight (f.recapShift / f.recapPart). Only a flight that has no stored value (added by
// hand, imported before this rule, anchor flight missing from the recap) falls back on the loading-time ranges.
//
// LOADING TIME = Heure MAD + 1h, EXCEPT for 786 / 787 / 788 / 789 aircraft (loading time = Heure MAD, no +1h).
//
// SHIFTS (by loading time):
//   morning   : 06:00 → 13:40
//   afternoon : 13:45 → 21:25
//   night     : 21:30 → 05:45   (crosses midnight; the WHOLE night is always Nuit: 21:30→23:59 and 00:00→05:45)
//   A flight in the hand-over minutes between two shifts goes to the INCOMING shift:
//   05:46–05:59 -> morning, 13:41–13:44 -> afternoon, 21:26–21:29 -> night.
// Night flights loaded after midnight use the planning column of the previous day (see planDateFor).
export const SHIFTS = {
  morning:   { label: "Matin",      range: "06:00–13:40" },
  afternoon: { label: "Après-midi", range: "13:45–21:25" },
  night:     { label: "Nuit",       range: "21:30–05:45" },
};
const MORNING_START = 6 * 60;          // 06:00
const MORNING_END = 13 * 60 + 40;      // 13:40
const AFTERNOON_END = 21 * 60 + 25;    // 21:25
const NIGHT_END = 5 * 60 + 45;         // 05:45
export const SHIFT_ORDER = ["morning", "afternoon", "night"];

export function minutesOf(t) {
  const m = String(t ?? "").match(/(\d{1,2})\s*[:hH]\s*(\d{2})/);
  return m ? +m[1] * 60 + +m[2] : null;
}
/** Current calendar day + minutes since midnight in Morocco (injectable for tests). */
export function nowCasa(d = new Date()) {
  const p = Object.fromEntries(new Intl.DateTimeFormat("en-GB", { timeZone: "Africa/Casablanca", hourCycle: "h23",
    year: "numeric", month: "2-digit", day: "2-digit", hour: "2-digit", minute: "2-digit" }).formatToParts(d).map((x) => [x.type, x.value]));
  return { iso: `${p.year}-${p.month}-${p.day}`, minutes: +p.hour * 60 + +p.minute };
}
/** Which night window applies when looking at recap day `iso` right now: "evening" | "early" | "both". */
export function nightWindowFor(iso, now = nowCasa()) {
  if (!iso) return "both";
  if (iso === now.iso) return now.minutes < MORNING_START ? "early" : "evening";
  if (iso === addDays(now.iso, 1)) return "early";
  return "both";
}

/** Anchor flights of the Récap (rows are in the recap's own order). A shift runs from its first anchor flight
 *  to its last one; with several candidates, the first present one opens the block, the last present one closes it.
 *    nightEarly : start of the recap  -> AT1410 / AT1422 / AT409   (night that began the evening before)
 *    morning    : AT1435 -> AT215
 *    afternoon  : AT968  -> AT511
 *    nightLate  : AT587  -> end of the recap (AT248 or later)     (night that begins this evening) */
export const RECAP_ANCHORS = {
  nightEarly: { shift: "night",     part: "early", from: ["AT808", "AT250", "AT706"], to: ["AT1410", "AT1422", "AT409"] },
  morning:    { shift: "morning",   part: "",      from: ["AT1435"],                  to: ["AT215"] },
  afternoon:  { shift: "afternoon", part: "",      from: ["AT968"],                   to: ["AT511"] },
  nightLate:  { shift: "night",     part: "late",  from: ["AT587"],                   to: null },
};

/** Sets f.recapShift ("morning"|"afternoon"|"night"|null) and f.recapPart ("early"|"late"|"") on the flights of
 *  ONE recap, given IN RECAP ORDER. Flights outside every anchored block get null (-> loading-time fallback).
 *  Returns { missing: [block names whose anchors were not found], fallback: [flight numbers left to the time rule] }. */
export function assignRecapShifts(flights, anchors = RECAP_ANCHORS) {
  const nums = flights.map((f) => String(f?.flightNumber || "").replace(/\s+/g, "").toUpperCase());
  const first = (list) => nums.findIndex((n) => list.includes(n));
  const last = (list) => { for (let i = nums.length - 1; i >= 0; i--) if (list.includes(nums[i])) return i; return -1; };
  const blocks = [], missing = [];
  for (const [name, a] of Object.entries(anchors)) {
    const s = first(a.from), e = a.to ? last(a.to) : nums.length - 1;
    if (s >= 0 && e >= s) blocks.push({ ...a, s, e }); else missing.push(name);
  }
  const fallback = [];
  flights.forEach((f, i) => {
    const b = blocks.find((x) => i >= x.s && i <= x.e);
    f.recapShift = b ? b.shift : null;
    f.recapPart = b ? b.part : "";
    f.recapIdx = i; // position in the recap (used by « Répartition manuelle » to search INTO … TO …)
    if (!b) fallback.push(nums[i]);
  });
  return { missing, fallback };
}
/** By loading time (see the ranges above) — FALLBACK only, see flightShift. `win` is kept for compatibility and ignored: the whole night is Nuit. */
export function shiftOf(time) {
  const m = minutesOf(time);
  if (m == null) return null;
  if (m <= NIGHT_END) return "night";
  if (m <= MORNING_END) return "morning";
  if (m <= AFTERNOON_END) return "afternoon";
  return "night";
}
const hhmm = (m) => `${String(Math.floor(m / 60) % 24).padStart(2, "0")}:${String(m % 60).padStart(2, "0")}`;
/** 786 / 787 / 788 / 789 aircraft: no +1h on the loading time. */
export const noHourShift = (f) => /(^|\D)78[6-9](\D|$)/.test(String(f?.aircraftType ?? ""));
/** Loading time in minutes (may reach 1440+ after midnight): Heure MAD + 1h (+0 for 786-789), else the departure time. */
export function loadMinutes(f) {
  const mad = minutesOf(f?.heureMAD);
  if (mad != null) return mad + (noHourShift(f) ? 0 : 60);
  return minutesOf(f?.heureDepart);
}
/** Loading time "HH:MM" (falls back to the departure time, unchanged, when MAD is missing). */
export function loadTime(f) {
  const m = loadMinutes(f);
  return m != null ? hhmm(m) : "";
}
/** Calendar day (ISO) of a flight's recap: f.date (ISO or dd/mm/yyyy), else the id prefix. */
export function recapDayOf(f) {
  const v = String(f?.date || "").trim();
  if (/^\d{4}-\d{2}-\d{2}/.test(v)) return v.slice(0, 10);
  let m = v.match(/^(\d{2})[\/-](\d{2})[\/-](\d{4})$/);
  if (m) return `${m[3]}-${m[2]}-${m[1]}`;
  m = String(f?.id || "").match(/^(\d{4}-\d{2}-\d{2})_/);
  return m ? m[1] : "";
}
/** Shift of a flight: the one stored from the recap order, else (no stored value) the loading-time ranges. */
export const flightShift = (f) => (SHIFT_ORDER.includes(f?.recapShift) ? f.recapShift : shiftOf(loadTime(f)));

export const addDays = (iso, n) => { const d = new Date(iso + "T00:00:00Z"); d.setUTCDate(d.getUTCDate() + n); return d.toISOString().slice(0, 10); };
/** Calendar date of the planning column that applies to a flight: a night shift starts on the evening of
 *  day D, so flights loaded after midnight (up to 05:35) belong to the night of D-1. */
export function planDateFor(f, iso, shift) {
  if (shift !== "night" || !iso) return iso;
  if (f?.recapShift === "night") {            // position in the recap tells which night it is
    if (f.recapPart === "early") return addDays(iso, -1);
    if (f.recapPart === "late") return iso;
  }
  const load = loadMinutes(f);
  if (load == null || load >= 1440) return iso;
  return load < MORNING_START ? addDays(iso, -1) : iso;
}
/** Planning cell text -> shift key ("matin", "après-midi", "Nuit"); anything else (repos, congé…) -> null. */
export function shiftFromWord(w) {
  const t = String(w || "").normalize("NFD").replace(/[\u0300-\u036f]/g, "").toLowerCase().trim();
  if (t.startsWith("matin")) return "morning";
  if (t.startsWith("apres") || t.startsWith("aprem")) return "afternoon";
  if (t.startsWith("nuit")) return "night";
  return null;
}

/** Splits flights between controllers: balanced counts, and two flights with the SAME loading time never go
 *  to the same controller (unless there are more simultaneous flights than controllers -> counted in `conflicts`). */
export function splitNoOverlap(sorted, names) {
  const parts = names.map((name) => ({ name, flights: [] }));
  const slots = [];
  for (const f of sorted) {
    const t = loadTime(f), g = slots[slots.length - 1];
    if (g && g.t === t) g.items.push(f); else slots.push({ t, items: [f] });
  }
  let conflicts = 0, last = -1;
  for (const { items } of slots) {
    const used = new Set();
    for (const f of items) {
      let pool = parts.map((_, i) => i).filter((i) => !used.has(i));
      if (!pool.length) { conflicts++; pool = parts.map((_, i) => i); }
      pool.sort((x, y) => parts[x].flights.length - parts[y].flights.length || (y === last) - (x === last) || x - y);
      parts[pool[0]].flights.push(f); used.add(pool[0]); last = pool[0];
    }
  }
  return { parts, conflicts };
}
export const shiftLabel = (k) => SHIFTS[k]?.label || "";

/** Flight number typed by a person (\"1435\", \"at 1435\", \"AT1435\") -> \"AT1435\"; \"\" when not a flight number. */
export const normFlightNo = (v) => { const m = String(v || "").toUpperCase().match(/^\s*(?:AT)?\s*(\d{3,4})\s*$/); return m ? "AT" + m[1] : ""; };
/** Splits \"AT808 OR AT250, AT706\" into [\"AT808\",\"AT250\",\"AT706\"]; returns null if a token is not a flight number. */
export function parseFlightList(text) {
  const toks = String(text || "").split(/[\s,;/|]+|\bOR\b|\bOU\b/i).filter(Boolean);
  const out = toks.map(normFlightNo);
  return out.length && out.every(Boolean) ? out : toks.length ? null : [];
}
/** Recap order: flights sorted by f.recapIdx when EVERY flight has one, else null (recap imported before this feature). */
export const byRecapOrder = (list) => (list.length && list.every((f) => Number.isInteger(f.recapIdx)) ? [...list].sort((a, b) => a.recapIdx - b.recapIdx) : null);
/** « INTO a [OR b…] TO c [OR d…] » on a list in recap order -> { items } or { error }.
 *  INTO empty = from the start; TO empty = until the end (\"or later\"). First present INTO flight opens, last present TO flight closes. */
export function searchRange(ordered, intoText, toText) {
  const into = parseFlightList(intoText), to = parseFlightList(toText);
  if (into === null || to === null) return { error: "Numéro de vol invalide (ex. AT1435)." };
  if (!into.length && !to.length) return { items: ordered };
  const nums = ordered.map((f) => f.flightNumber);
  let s = 0, e = ordered.length - 1;
  if (into.length) { s = nums.findIndex((n) => into.includes(n)); if (s < 0) return { error: `${into.join(" / ")} introuvable parmi les vols affichés.` }; }
  if (to.length) { e = -1; for (let i = nums.length - 1; i >= 0; i--) if (to.includes(nums[i])) { e = i; break; } if (e < 0) return { error: `${to.join(" / ")} introuvable parmi les vols affichés.` }; }
  if (e < s) return { error: "Le vol « To » est avant le vol « Into » dans le Récap." };
  return { items: ordered.slice(s, e + 1) };
}

/** Chronological order inside a shift (night runs past midnight: 23:00 comes before 01:00). */
export function sortInShift(list, shift) {
  const key = (f) => { let m = minutesOf(loadTime(f)) ?? 0; if ((shift === "night" || shift === "afternoon") && m < MORNING_START) m += 1440; return m; };
  return [...list].sort((a, b) => key(a) - key(b) || String(a.flightNumber).localeCompare(String(b.flightNumber)));
}
/** Splits an ordered flight list into N consecutive blocks (sizes differ by at most 1). */
export function splitFlights(sorted, names) {
  const n = names.length, base = Math.floor(sorted.length / n), extra = sorted.length % n;
  let i = 0;
  return names.map((name, k) => {
    const size = base + (k < extra ? 1 : 0);
    const flights = sorted.slice(i, i + size); i += size;
    return { name, flights };
  });
}
export const rangeLabel = (fl) => !fl.length ? "—" : fl.length === 1 ? fl[0].flightNumber : `${fl[0].flightNumber} → ${fl[fl.length - 1].flightNumber}`;

const norm = (s) => String(s || "").normalize("NFD").replace(/[\u0300-\u036f]/g, "").toLowerCase().replace(/[^a-z0-9 ]/g, " ").replace(/\s+/g, " ").trim();
/** Does the account name ("Hiba", "Riham Sadki") match a planning name ("Sadki Riham", "RIHAB")? Equal, contained, or one shared word (3+ letters). */
export function sameController(a, b) {
  const x = norm(a), y = norm(b);
  if (!x || !y) return false;
  if (x === y || x.includes(y) || y.includes(x)) return true;
  const wy = new Set(y.split(" ").filter((w) => w.length >= 3));
  return x.split(" ").some((w) => w.length >= 3 && wy.has(w));
}
