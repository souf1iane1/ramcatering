import { requireAuth, showToast } from "./auth.js";
import { listPlanning, savePlanning } from "./api.js";
import { shiftFromWord, SHIFTS } from "./shifts.js";

const { user } = await requireAuth("admin/planning.html");

const dropzone = document.getElementById("dropzone");
const fileInput = document.getElementById("fileInput");
const dzText = document.getElementById("dzText");
const saveBar = document.getElementById("saveBar");
const saveInfo = document.getElementById("saveInfo");
const saveBtn = document.getElementById("saveBtn");
const table = document.getElementById("planTable");

const esc = (v) => String(v ?? "").replace(/[&<>"']/g, (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]));
let parsed = null, fileName = "";

// Show what is already saved.
await showSaved();

["dragover", "dragleave", "drop"].forEach((evt) => dropzone.addEventListener(evt, (e) => {
  e.preventDefault();
  dropzone.classList.toggle("drag", evt === "dragover");
  if (evt === "drop" && e.dataTransfer.files[0]) handleFile(e.dataTransfer.files[0]);
}));
fileInput.addEventListener("change", () => fileInput.files[0] && handleFile(fileInput.files[0]));

async function handleFile(file) {
  try {
    if (!window.XLSX) throw new Error("Bibliothèque Excel non chargée (connexion ?)");
    const wb = XLSX.read(await file.arrayBuffer(), { type: "array" });
    parsed = parsePlanning(wb);
    fileName = file.name;
    dzText.textContent = file.name;
    const days = Object.keys(parsed).length;
    saveInfo.textContent = `${days} jours détectés · ${new Set(Object.values(parsed).flatMap((d) => [...d.morning, ...d.afternoon, ...d.night, ...d.off])).size} contrôleurs`;
    saveBar.hidden = false;
    renderTable(parsed);
  } catch (e) {
    console.error(e);
    parsed = null; saveBar.hidden = true;
    showToast("Planning illisible : " + e.message, "error", 6000);
  }
}

/** Finds the row of dates, the controller names (left of the first date) and each cell's shift. */
function parsePlanning(wb) {
  const ws = wb.Sheets[wb.SheetNames[0]];
  const rows = XLSX.utils.sheet_to_json(ws, { header: 1, raw: true, defval: null });
  const isoOf = (v) => {
    if (typeof v === "number" && v > 30000) return new Date(Math.round((v - 25569) * 86400000)).toISOString().slice(0, 10);
    const m = String(v ?? "").match(/^(\d{1,2})[\/.-](\d{1,2})[\/.-](\d{4})$/);
    return m ? `${m[3]}-${m[2].padStart(2, "0")}-${m[1].padStart(2, "0")}` : null;
  };
  let dateRow = -1, cols = [];
  rows.some((r, i) => { const c = r.map((v, j) => [j, isoOf(v)]).filter(([, d]) => d); if (c.length >= 5) { dateRow = i; cols = c; return true; } return false; });
  if (dateRow < 0) throw new Error("ligne des dates introuvable");

  const firstCol = cols[0][0], out = {};
  cols.forEach(([, d]) => { out[d] = { date: d, morning: [], afternoon: [], night: [], off: [] }; });
  for (let i = dateRow + 1; i < rows.length; i++) {
    const r = rows[i];
    const name = r.slice(0, firstCol).find((v) => typeof v === "string" && v.trim());
    if (!name) continue;
    // the summary block under the table ("matin 2 3 3…") starts with a shift word in the name column
    if (shiftFromWord(name) || /^repos/i.test(name.trim())) break;
    cols.forEach(([j, d]) => {
      const cell = r[j];
      if (typeof cell !== "string" || !cell.trim()) return;
      const k = shiftFromWord(cell);
      out[d][k || "off"].push(name.trim());
    });
  }
  return out;
}

function renderTable(data) {
  const days = Object.values(data).sort((a, b) => a.date.localeCompare(b.date));
  const today = new Date().toISOString().slice(0, 10);
  const cell = (arr) => arr.length ? arr.map(esc).join(", ") : "—";
  table.innerHTML = `<div class="plan-table-wrap"><table class="plan-table">
    <thead><tr><th>Date</th><th>${SHIFTS.morning.label}</th><th>${SHIFTS.afternoon.label}</th><th>${SHIFTS.night.label}</th><th>Repos</th></tr></thead>
    <tbody>${days.map((d) => `<tr class="${d.date === today ? "today" : ""}">
      <td>${new Date(d.date + "T00:00:00Z").toLocaleDateString("fr-FR", { weekday: "short", day: "2-digit", month: "2-digit", timeZone: "UTC" })}</td>
      <td>${cell(d.morning)}</td><td>${cell(d.afternoon)}</td><td>${cell(d.night)}</td><td class="off">${cell(d.off)}</td></tr>`).join("")}</tbody></table></div>`;
}

async function showSaved() {
  try {
    const data = {};
    (await listPlanning()).forEach((d) => { data[d.date] = d; });
    if (Object.keys(data).length) { renderTable(data); table.insertAdjacentHTML("afterbegin", '<p class="subtitle">Planning enregistré</p>'); }
  } catch (e) { console.warn(e); }
}

saveBtn.addEventListener("click", async () => {
  if (!parsed) return;
  saveBtn.disabled = true;
  try {
    const days = Object.values(parsed);
    for (let i = 0; i < days.length; i += 300) { // the API accepts up to 400 days per request
      await savePlanning(days.slice(i, i + 300), fileName);
    }
    showToast(`Planning enregistré (${days.length} jours).`, "success");
    saveBar.hidden = true; parsed = null;
  } catch (e) { console.error(e); showToast("Enregistrement impossible : " + e.message, "error", 6000); }
  finally { saveBtn.disabled = false; }
});
