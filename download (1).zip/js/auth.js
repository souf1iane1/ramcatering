import { me, logout } from "./api.js";
import { icon } from "./icons.js";

const PAGE_ROLES = {
  "dashboard.html": ["admin", "controller"],
  "flights.html": ["admin", "controller"],
  "flight.html": ["admin", "controller"],
  "admin/upload.html": ["admin"],
  "admin/loading-plans.html": ["admin"],
  "admin/users.html": ["admin"],
  "admin/audit.html": ["admin"],
  "admin/controllers.html": ["admin"],
  "admin/planning.html": ["admin"],
  "profile.html": ["admin", "controller"],
  "my-planning.html": ["controller"],
};

const NAV_LINKS = {
  admin: [
    ["dashboard.html", "Dashboard"], ["flights.html", "Flights"],
    ["admin/upload.html", "Upload Récap"], ["admin/loading-plans.html", "Plans & fiches"], ["admin/planning.html", "Planning"], ["admin/controllers.html", "Contrôleurs"],
    ["admin/users.html", "Users"], ["admin/audit.html", "Audit"],
  ],
  controller: [
    ["dashboard.html", "My Flights"], ["flights.html", "All Flights"], ["my-planning.html", "My Planning"],
  ],
};

function relPrefix() {
  return location.pathname.includes("/admin/") ? "../" : "";
}

/** NAV_LINKS stores every link as if it were written from the site root (e.g. "admin/audit.html").
 *  This resolves that root-relative token into the correct path from wherever the page actually
 *  is right now — e.g. from inside /admin/, "admin/audit.html" becomes "audit.html" (not
 *  "admin/admin/audit.html"), and "dashboard.html" becomes "../dashboard.html". */
function resolveHref(rootRelativeHref) {
  const inAdmin = location.pathname.includes("/admin/");
  if (rootRelativeHref.startsWith("admin/")) {
    return inAdmin ? rootRelativeHref.slice("admin/".length) : rootRelativeHref;
  }
  return inAdmin ? "../" + rootRelativeHref : rootRelativeHref;
}

// Icons for the mobile bottom tab bar, keyed by the link's filename (see js/icons.js).
const TAB_ICON = {
  "dashboard.html": "dashboard", "flights.html": "plane", "upload.html": "upload", "users.html": "users",
  "audit.html": "shield", "planning.html": "calendar", "controllers.html": "userCheck", "my-planning.html": "calendar",
  "loading-plans.html": "fileText",
};

function iconFor(href) {
  const key = href.split("/").pop();
  return icon(TAB_ICON[key] || "dashboard", 22);
}

/** Resolves once with { user, profile } after verifying the current page is allowed for the role.
 *  Redirects to login (no session) or dashboard (wrong role) as needed.
 *  `user` and `profile` are the same object: { uid, name, email, role }. */
export async function requireAuth(pageKey) {
  const prefix = relPrefix();
  let profile;
  try {
    profile = await me();
    if (!profile) { // one retry: right after login some mobile browsers attach the new cookie a beat late
      await new Promise((r) => setTimeout(r, 400));
      profile = await me();
    }
  } catch (err) {
    console.error("[auth] /api/auth/me failed:", err);
    showFatalError(`Impossible de joindre le serveur : ${err.message}`);
    return new Promise(() => {});
  }
  if (!profile) {
    location.href = prefix + "login.html";
    return new Promise(() => {}); // never resolves: stop the page script while redirecting
  }
  const allowed = PAGE_ROLES[pageKey] || [];
  if (!allowed.includes(profile.role)) {
    location.href = prefix + "dashboard.html";
    return new Promise(() => {});
  }
  renderTopbar(profile, pageKey);
  return { user: profile, profile };
}

function showFatalError(message) {
  const mount = document.getElementById("content") || document.body;
  const box = document.createElement("div");
  box.style.cssText = "margin:2rem auto;max-width:640px;padding:1rem 1.25rem;border:1px solid #d33;background:#fdeaea;color:#900;border-radius:8px;font:14px/1.5 sans-serif;";
  box.innerHTML = `<strong>Couldn't finish signing you in.</strong><br>${message}`;
  mount.prepend(box);
}

/** Shows a small floating confirmation/error banner. Used instead of alert(), which some
 *  installed-PWA or in-app-webview contexts suppress silently — leaving the user with no
 *  feedback at all after tapping Save. Safe to call from any page. */
export function showToast(message, type = "info", duration = 3200) {
  let stack = document.querySelector(".toast-stack");
  if (!stack) {
    stack = document.createElement("div");
    stack.className = "toast-stack";
    document.body.appendChild(stack);
  }
  const el = document.createElement("div");
  el.className = `toast ${type}`;
  el.textContent = message;
  stack.appendChild(el);
  setTimeout(() => {
    el.classList.add("hide");
    setTimeout(() => el.remove(), 200);
  }, duration);
}

const escHtml = (v) => String(v ?? "").replace(/[&<>"']/g, (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]));

/** "Jean Dupont" -> "JD", "ahmed" -> "A", "" -> "?" */
export function initialsOf(profile) {
  const src = (profile?.name || profile?.email || "?").trim();
  const parts = src.split(/[\s@._-]+/).filter(Boolean);
  const letters = parts.length > 1 ? parts[0][0] + parts[1][0] : (parts[0] || "?").slice(0, 2);
  return letters.toUpperCase();
}

function renderTopbar(profile, pageKey) {
  const mount = document.getElementById("topbar");
  if (!mount) return;
  const links = NAV_LINKS[profile.role] || [];
  const navHtml = links
    .map(([href, label]) => {
      const isActive = pageKey.endsWith(href.split("/").pop());
      return `<a href="${resolveHref(href)}" class="${isActive ? "active" : ""}">${label}</a>`;
    })
    .join("");
  mount.innerHTML = `
    <a class="brand" href="${relPrefix()}dashboard.html" aria-label="Royal Air Maroc — Check-list"><img class="brand-logo" src="${relPrefix()}assets/logo-white-sm.png" alt="Royal Air Maroc" width="48" height="35"> <span class="brand-full">Check-list</span></a>
    <nav>${navHtml}</nav>
    <div class="user">
      <span class="clock" id="navClock" aria-live="off"><span class="clock-date"></span><span class="clock-time"></span></span>
      <a class="user-link ${pageKey === "profile.html" ? "active" : ""}" href="${relPrefix()}profile.html" title="Mon profil" aria-label="Mon profil">
        <span class="avatar" id="navAvatar">${escHtml(initialsOf(profile))}</span>
        <span class="user-name" id="navUserName">${escHtml(profile.name || profile.email)}</span>
      </a>
      <span class="role-pill ${profile.role}">${profile.role}</span>
      <button type="button" class="theme-toggle" data-theme-toggle></button>
      <button class="linklike" id="logoutBtn">Log out</button>
    </div>`;
  startClock();
  window.clTheme?.wire();
  document.getElementById("logoutBtn").addEventListener("click", async () => {
    try { await logout(); } catch (e) { console.warn("logout:", e); }
    location.href = relPrefix() + "login.html";
  });

  renderTabbar(links, pageKey);
}

/** Live date + time in the navbar (device local time, updates every second). */
function startClock() {
  const box = document.getElementById("navClock");
  if (!box) return;
  const dEl = box.querySelector(".clock-date"), tEl = box.querySelector(".clock-time");
  const tick = () => {
    const now = new Date();
    dEl.textContent = now.toLocaleDateString("fr-FR", { weekday: "short", day: "2-digit", month: "2-digit", year: "numeric" });
    tEl.textContent = now.toLocaleTimeString("fr-FR", { hour: "2-digit", minute: "2-digit", second: "2-digit" });
  };
  tick();
  clearInterval(window.__navClockTimer);
  window.__navClockTimer = setInterval(tick, 1000);
}

/** Native-app-style bottom tab bar, shown only on phone-width screens (see CSS).
 *  Reuses the same role-based links as the desktop topbar nav. */
function renderTabbar(links, pageKey) {
  let mount = document.getElementById("tabbar");
  if (!mount) {
    mount = document.createElement("div");
    mount.id = "tabbar";
    mount.className = "tabbar";
    document.body.appendChild(mount);
  }
  mount.innerHTML = links
    .map(([href, label]) => {
      const isActive = pageKey.endsWith(href.split("/").pop());
      return `<a href="${resolveHref(href)}" class="tabbar-item ${isActive ? "active" : ""}">
        <span class="tabbar-icon">${iconFor(href)}</span>
        <span class="tabbar-label">${label}</span>
      </a>`;
    })
    .join("");
}