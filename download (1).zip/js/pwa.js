// Check-list — PWA bootstrap.
// Included (non-module, defer) on every page. Registers the service worker
// and shows a lightweight "install app" nudge on platforms that support it
// (Android/desktop Chrome/Edge via beforeinstallprompt) or that need manual
// instructions (iOS Safari has no install prompt API).

(function () {
  "use strict";

  function relPrefix() {
    return location.pathname.includes("/admin/") ? "../" : "";
  }

  // ---------- Service worker ----------
  if ("serviceWorker" in navigator) {
    window.addEventListener("load", () => {
      navigator.serviceWorker.register(relPrefix() + "sw.js").then((reg) => {
        // After being offline (or backgrounded for hours) pick up a newer version straight away.
        const check = () => reg.update().catch(() => {});
        window.addEventListener("online", check);
        document.addEventListener("visibilitychange", () => { if (document.visibilityState === "visible") check(); });
      }).catch((err) => {
        console.warn("[pwa] service worker registration failed:", err);
      });
    });
  }

  // ---------- Install prompt (Android / desktop Chrome, Edge) ----------
  let deferredPrompt = null;
  const isStandalone =
    window.matchMedia("(display-mode: standalone)").matches || window.navigator.standalone === true;

  window.addEventListener("beforeinstallprompt", (e) => {
    e.preventDefault();
    deferredPrompt = e;
    if (!isStandalone && !wasDismissedRecently("android")) showBanner("android");
  });

  window.addEventListener("appinstalled", () => {
    deferredPrompt = null;
    hideBanner();
  });

  // ---------- iOS Safari manual instructions ----------
  const isIos = /iphone|ipad|ipod/i.test(navigator.userAgent);
  const isSafari = /safari/i.test(navigator.userAgent) && !/crios|fxios|edgios/i.test(navigator.userAgent);
  if (isIos && isSafari && !isStandalone && !wasDismissedRecently("ios")) {
    // Give the page a moment to settle before nudging.
    setTimeout(() => showBanner("ios"), 1200);
  }

  function wasDismissedRecently(kind) {
    const raw = localStorage.getItem("rc_install_dismissed_" + kind);
    if (!raw) return false;
    const days = (Date.now() - Number(raw)) / 86400000;
    return days < 14;
  }

  function dismiss(kind) {
    localStorage.setItem("rc_install_dismissed_" + kind, String(Date.now()));
    hideBanner();
  }

  function hideBanner() {
    const el = document.getElementById("pwaInstallBanner");
    if (el) el.remove();
  }

  function showBanner(kind) {
    if (document.getElementById("pwaInstallBanner")) return;
    const el = document.createElement("div");
    el.id = "pwaInstallBanner";
    el.className = "install-banner";
    if (kind === "android") {
      el.innerHTML = `
        <span>Installer Check-list sur cet appareil ?</span>
        <span class="install-banner-actions">
          <button type="button" class="btn amber small" id="pwaInstallBtn">Installer</button>
          <button type="button" class="linklike" id="pwaDismissBtn" aria-label="Fermer"><svg class="ico" viewBox="0 0 24 24" width="16" height="16" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M18 6 6 18M6 6l12 12"/></svg></button>
        </span>`;
    } else {
      el.innerHTML = `
        <span>Pour installer l'app : appuyez sur <strong>Partager</strong> puis <strong>Sur l'écran d'accueil</strong>.</span>
        <span class="install-banner-actions">
          <button type="button" class="linklike" id="pwaDismissBtn" aria-label="Fermer"><svg class="ico" viewBox="0 0 24 24" width="16" height="16" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M18 6 6 18M6 6l12 12"/></svg></button>
        </span>`;
    }
    document.body.appendChild(el);

    const installBtn = document.getElementById("pwaInstallBtn");
    if (installBtn) {
      installBtn.addEventListener("click", async () => {
        hideBanner();
        if (!deferredPrompt) return;
        deferredPrompt.prompt();
        await deferredPrompt.userChoice;
        deferredPrompt = null;
      });
    }
    document.getElementById("pwaDismissBtn").addEventListener("click", () => dismiss(kind));
  }
})();
