// Parses a Récap exported as PDF (the same table as the Excel file, printed to PDF).
// Needs pdf.js (`pdfjsLib` global, loaded by admin/upload.html) — or pass the library in for tests.
//
// How it works: pdf.js gives every text fragment with its position. We
//   1. find the header band (the lines made of header words: "Numéro de vol", "FC presta", …) and cluster its
//      fragments into columns (wrapped labels like "nombr"+"e" are re-joined),
//   2. start a new flight row at every flight number found in the "Numéro de vol" column. The cell alignment
//      varies between exports (top-aligned OR vertically centred), so the border between two rows is not
//      assumed to be at the flight number: it is the widest empty gap between the two flight numbers,
//   3. drop each fragment in its column (by left edge) and join the lines of a cell with "\n",
// which gives exactly the rows the Excel importer reads — so both formats share one parser.
import { parseRecapRows } from "./excel-parser.js";

const Y_TOL = 2.5;      // pt: fragments closer than this vertically are on the same line
const HEAD_X_TOL = 7;   // pt: header fragments whose centres are this close belong to one column
const FLIGHT_RE = /^[A-Z0-9]{2}\s*\d{2,4}$/i;

const cx = (it) => it.x + it.w / 2;

function fixLabel(label) {
  return label
    .replace(/nombr\s+e\b/gi, "nombre")
    .replace(/enregistre\s+ment/gi, "enregistrement")
    .replace(/\s+/g, " ")
    .trim();
}

/** Joins fragments that sit on one visual line, in x order. */
function joinLine(frags) {
  frags.sort((a, b) => a.x - b.x);
  let out = "";
  let prevEnd = null;
  for (const f of frags) {
    if (prevEnd !== null && f.x - prevEnd > 1.2) out += " ";
    out += f.str;
    prevEnd = f.x + f.w;
  }
  return out.trim();
}

/** Groups fragments into lines (top → bottom): [{ y, text }]. */
function toLineObjs(frags) {
  const sorted = [...frags].sort((a, b) => b.y - a.y);
  const lines = [];
  for (const f of sorted) {
    const last = lines[lines.length - 1];
    if (last && Math.abs(last.y - f.y) <= Y_TOL) last.items.push(f);
    else lines.push({ y: f.y, items: [f] });
  }
  return lines.map((l) => ({ y: l.y, text: joinLine(l.items) }));
}
const toLines = (frags) => toLineObjs(frags).map((l) => l.text);

async function readPages(buffer, lib) {
  const doc = await lib.getDocument({ data: new Uint8Array(buffer) }).promise;
  const pages = [];
  for (let p = 1; p <= doc.numPages; p++) {
    const page = await doc.getPage(p);
    const tc = await page.getTextContent();
    const [x0, y0, x1, y1] = page.view || [0, 0, 842, 595];
    const W = x1 - x0, H = y1 - y0;
    let items = tc.items
      .filter((i) => i.str && i.str.trim() !== "")
      .map((i) => ({ str: i.str.trim(), x: i.transform[4], y: i.transform[5], w: i.width || 0 }));
    // the page number printed alone at the top centre of the page is not data: only the TOPMOST fragment,
    // when it is a bare number sitting on the page's centre line (real counts such as "110" are never topmost)
    const topY = items.length ? Math.max(...items.map((i) => i.y)) : 0;
    items = items.filter((i) => !(i.y === topY && /^\d{1,3}$/.test(i.str) && i.y > y0 + H - 40 && Math.abs(i.x + i.w / 2 - (x0 + W / 2)) < 8));
    pages.push(items);
  }
  return pages;
}

// Words that make up the header labels. Used to find the header band without relying on where the first flight
// row starts (centred cells make the first flight's cells begin ABOVE its flight number).
const HEADER_WORD = /^(num[ée]ro|de vol|vol|heure|d[ée]part|mad|(?:fc|jc|yc|peq|bob)(?: (?:presta|cycle|nombre?))?|presta|cycle|nombre?|nombr|e|d'enregistre|enregistre|ment|machine|note)$/i;
const HEADER_MAX_H = 30; // pt: a header band is never taller than this

/** The header band of a page: { top, bottom } (y of its first / last line), or null when the page has none. */
function headerBand(items, titleY = Infinity) {
  const vocab = items.filter((i) => i.y < titleY - Y_TOL && HEADER_WORD.test(i.str));
  if (vocab.length < 6) return null;
  const top = Math.max(...vocab.map((i) => i.y));
  const inBand = vocab.filter((i) => i.y >= top - HEADER_MAX_H);
  if (inBand.length < 6) return null;
  return { top, bottom: Math.min(...inBand.map((i) => i.y)) };
}

/** @param {ArrayBuffer} buffer  @returns {Promise<{date:string|null, flights: object[]}>} */
export async function parseRecapPdf(buffer, lib = globalThis.pdfjsLib) {
  if (!lib) throw new Error("Le lecteur PDF n'a pas pu être chargé (connexion internet requise). Réessayez ou utilisez le fichier Excel.");
  const pages = await readPages(buffer, lib);
  if (!pages.some((p) => p.length)) {
    throw new Error("Ce PDF ne contient pas de texte (scan/image). Utilisez le PDF généré depuis Excel ou le fichier Excel.");
  }

  // ---- 1. header band + columns (first page that has the "Numéro de vol" header) ----
  const first = pages.findIndex((items) => items.some((i) => /^num[ée]ro$/i.test(i.str) || /num[ée]ro de vol/i.test(i.str)));
  if (first === -1) throw new Error("En-tête du fichier Récap introuvable dans le PDF (colonne « Numéro de vol » manquante).");
  const p0 = pages[first];
  if (!p0.some((i) => /^AT\s*\d{3,4}$/i.test(i.str) || FLIGHT_RE.test(i.str))) throw new Error("Aucun numéro de vol trouvé dans le PDF.");

  const titleFrags = p0.filter((i) => /r[ée]cap/i.test(i.str));
  const titleY = titleFrags.length ? Math.max(...titleFrags.map((i) => i.y)) : Infinity;
  const band = headerBand(p0, titleY);
  if (!band) throw new Error("En-tête du fichier Récap introuvable dans le PDF (lignes « FC presta », « YC cycle »… manquantes).");
  const headerFrags = p0.filter((i) => i.y < titleY - Y_TOL && i.y <= band.top + Y_TOL && i.y >= band.bottom - Y_TOL);
  const titleText = toLines(p0.filter((i) => i.y > band.top + Y_TOL)).join(" ");

  // cluster header fragments into columns by centre x
  const byX = [...headerFrags].sort((a, b) => cx(a) - cx(b));
  const clusters = [];
  for (const f of byX) {
    const c = clusters[clusters.length - 1];
    if (c && cx(f) - c.mean <= HEAD_X_TOL) { c.items.push(f); c.mean = c.items.reduce((s, i) => s + cx(i), 0) / c.items.length; }
    else clusters.push({ items: [f], mean: cx(f) });
  }
  const columns = clusters.map((c) => ({
    center: c.mean,
    label: fixLabel(toLines(c.items).join(" ")),
  }));

  // ---- 2/3. flight rows over all pages ----
  const headerRow = columns.map((c) => c.label);
  const flightCol = columns.findIndex((c) => /num[ée]ro de vol/i.test(c.label));
  if (flightCol === -1) throw new Error("Colonne « Numéro de vol » introuvable dans le PDF.");

  // Body cells are left-aligned while header labels are centred over their cell, so a fragment belongs to the
  // first column whose header centre lies at or to the right of the fragment's left edge
  // (the previous column's centre is always left of this cell's content).
  const colOf = (item) => {
    for (let i = 0; i < columns.length; i++) if (columns[i].center + 1 >= item.x) return i;
    return columns.length - 1;
  };

  const warnings = [];
  const rows = [[titleText], headerRow];
  for (let pi = first; pi < pages.length; pi++) {
    const items = pages[pi];
    // body = everything under the header band (first page) / under a repeated header or title (other pages)
    let cut = Infinity;
    if (pi === first) cut = band.bottom - Y_TOL;
    else {
      const rep = headerBand(items);
      const t = items.filter((i) => /r[ée]cap/i.test(i.str));
      if (rep) cut = rep.bottom - Y_TOL;
      else if (t.length) cut = Math.min(...t.map((i) => i.y)) - Y_TOL;
    }
    const body = items.filter((i) => i.y < cut);
    const starts = body.filter((i) => colOf(i) === flightCol && FLIGHT_RE.test(i.str)).sort((a, b) => b.y - a.y);
    if (!starts.length) continue;

    // Row borders: between two consecutive flight numbers the row border is the widest empty gap between the
    // text lines found there (true whatever the vertical alignment of the cells). Several lines share a y.
    const ys = [...new Set(body.map((i) => Math.round(i.y * 10) / 10))].sort((a, b) => b - a);
    const borders = starts.slice(0, -1).map((st, k) => {
      const hi = st.y, lo = starts[k + 1].y;
      const inside = ys.filter((y) => y <= hi + 0.05 && y >= lo - 0.05);
      let best = { gap: -1, mid: (hi + lo) / 2 };
      for (let j = 0; j < inside.length - 1; j++) {
        const g = inside[j] - inside[j + 1];
        if (g > best.gap) best = { gap: g, mid: (inside[j] + inside[j + 1]) / 2 };
      }
      return best.mid;
    });
    const bandTop = (k) => (k === 0 ? Infinity : borders[k - 1]);
    const bandBottom = (k) => (k === starts.length - 1 ? -Infinity : borders[k]);

    starts.forEach((_, k) => {
      const cells = columns.map(() => []);
      body.forEach((it) => {
        if (it.y <= bandTop(k) && it.y > bandBottom(k)) cells[colOf(it)].push(it);
      });
      const lineObjs = cells.map((frags) => toLineObjs(frags));
      // A long "presta" code that the PDF wrapped onto a second visual line has no matching line in the sibling
      // "cycle" column. Glue continuations back onto the line above, so presta / cycle / nombre stay aligned
      // line for line. Cells are either top-aligned (first lines level) or centred (shifted by half the extra
      // lines): try both; if neither gives the right number of lines, leave the cell untouched.
      columns.forEach((col, ci) => {
        const m = col.label.match(/^(.*)\spresta$/i);
        if (!m) return;
        const find = (suffix) => columns.findIndex((c) => c.label.toLowerCase() === `${m[1]} ${suffix}`.toLowerCase());
        const ref = find("cycle") >= 0 ? find("cycle") : find("nombre");
        if (ref < 0 || !lineObjs[ref].length || lineObjs[ci].length <= lineObjs[ref].length) return;
        const refYs = lineObjs[ref].map((l) => l.y);
        const src = lineObjs[ci];
        const pitch = src.length > 1 ? (src[0].y - src[src.length - 1].y) / (src.length - 1) : 8;
        const attempt = (shift0) => {
          const merged = [];
          let idx = 0, shift = shift0, prev = null;
          for (const l of src) {
            const isNew = !prev || (idx < refYs.length && Math.abs(l.y - (refYs[idx] - shift)) <= Y_TOL);
            if (isNew) { merged.push({ ...l }); idx++; }
            else { merged[merged.length - 1].text += l.text; shift += prev.y - l.y; }
            prev = l;
          }
          return merged;
        };
        const extra = src.length - refYs.length;
        const ok = [attempt(0), attempt(-(extra * pitch) / 2)].find((mg) => mg.length === refYs.length);
        if (ok) lineObjs[ci] = ok;
      });
      // consistency check: presta / cycle / nombre of a cabin must have the same number of lines
      // (BOB is skipped: its columns only hold a stray "MSG" flag in these exports)
      const issues = [];
      ["fc", "jc", "yc", "peq"].forEach((cab) => {
        const n = ["presta", "cycle", "nombre"].map((suf) => {
          const i = columns.findIndex((c) => c.label.toLowerCase() === `${cab} ${suf}`);
          return i >= 0 ? lineObjs[i].length : 0;
        });
        if (Math.max(...n) > 0 && !(n[0] === n[1] && n[1] === n[2])) issues.push(cab.toUpperCase());
      });
      if (issues.length) warnings.push(`${lineObjs[flightCol][0]?.text || "?"} (${issues.join(", ")})`);
      rows.push(lineObjs.map((ls) => ls.map((l) => l.text).join("\n")));
    });
  }

  const res = parseRecapRows(rows);
  return { ...res, warnings };
}
