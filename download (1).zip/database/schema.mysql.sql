-- Check-list — MySQL / MariaDB schema (utf8mb4).
-- Import once:  mysql -u USER -p DBNAME < database/schema.mysql.sql

CREATE TABLE IF NOT EXISTS users (
  id            INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  name          VARCHAR(120) NOT NULL,
  email         VARCHAR(190) NOT NULL,
  password_hash VARCHAR(255) NOT NULL,
  role          ENUM('admin','controller') NOT NULL DEFAULT 'controller',
  active        TINYINT(1) NOT NULL DEFAULT 1,
  created_at    DATETIME NOT NULL,
  UNIQUE KEY uq_users_email (email),
  KEY idx_users_role_name (role, name)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS sessions (
  id            VARCHAR(128) NOT NULL PRIMARY KEY,
  data          MEDIUMTEXT NOT NULL,
  last_activity INT UNSIGNED NOT NULL,
  KEY idx_sessions_activity (last_activity)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS login_attempts (
  id           INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  ip           VARCHAR(45) NOT NULL,
  email        VARCHAR(190) NOT NULL,
  attempted_at INT UNSIGNED NOT NULL,
  KEY idx_attempts (ip, email, attempted_at)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS recaps (
  id               INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  file_name        VARCHAR(255) NOT NULL,
  recap_date       VARCHAR(32) NULL,
  uploaded_by      INT UNSIGNED NOT NULL,
  uploaded_by_name VARCHAR(120) NOT NULL,
  uploaded_at      DATETIME NOT NULL,
  flight_count     INT UNSIGNED NOT NULL DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- id looks like "2026-10-22_AT208". `core` holds the imported Récap half
-- (heureDepart, heureMAD, aircraftType, aircraftCategory, numEnregistrement, note, imported);
-- `controller` holds everything the controllers type in. Both are JSON text
-- (LONGTEXT on purpose: MySQL's JSON type re-orders object keys).
CREATE TABLE IF NOT EXISTS flights (
  id                VARCHAR(64) NOT NULL PRIMARY KEY,
  flight_number     VARCHAR(16) NOT NULL,
  flight_date       VARCHAR(32) NULL,
  status            ENUM('pending','in_progress','completed') NOT NULL DEFAULT 'pending',
  core              LONGTEXT NOT NULL,
  controller        LONGTEXT NOT NULL,
  recap_id          INT UNSIGNED NULL,
  created_at        DATETIME NOT NULL,
  created_by        INT UNSIGNED NULL,
  updated_at        DATETIME NOT NULL,
  updated_by        INT UNSIGNED NULL,
  updated_by_name   VARCHAR(120) NULL,
  KEY idx_flights_number (flight_number),
  KEY idx_flights_date (flight_date)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS shift_plans (
  id          VARCHAR(64) NOT NULL PRIMARY KEY,      -- "2026-10-22_morning"
  plan_date   VARCHAR(10) NOT NULL,
  shift       VARCHAR(16) NOT NULL,
  data        LONGTEXT NOT NULL,                     -- {controllers:[], assignments:{}}
  updated_by  VARCHAR(190) NOT NULL DEFAULT '',
  updated_at  DATETIME NOT NULL,
  KEY idx_shift_plans_date (plan_date)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS planning (
  plan_date    VARCHAR(10) NOT NULL PRIMARY KEY,
  data         LONGTEXT NOT NULL,                    -- {morning:[], afternoon:[], night:[], off:[]}
  source       VARCHAR(255) NOT NULL DEFAULT '',
  uploaded_by  VARCHAR(190) NOT NULL DEFAULT '',
  uploaded_at  DATETIME NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- « Plan de chargement » : one PDF per aircraft family/type code (e.g. "788", "73H", "7M8", "E90", "AT7"),
-- uploaded once by an admin and matched to a flight from its Type A/C (see js/loading-plans.js: matchLoadingPlan).
CREATE TABLE IF NOT EXISTS loading_plans (
  type         VARCHAR(16) NOT NULL PRIMARY KEY,
  file_name    VARCHAR(255) NOT NULL,
  mime         VARCHAR(100) NOT NULL DEFAULT 'application/pdf',
  size_bytes   INT UNSIGNED NOT NULL,
  data         LONGBLOB NOT NULL,
  uploaded_by  VARCHAR(190) NOT NULL DEFAULT '',
  uploaded_at  DATETIME NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- « Fiche technique » : one PDF per code prestation (e.g. "DC25", "BC55", "CF99", "DC99"), uploaded by an admin and
-- matched to the code presta of a flight's PEQ / C/CL / Y/CL block (see js/tech-sheets.js: matchTechSheets).
CREATE TABLE IF NOT EXISTS tech_sheets (
  type         VARCHAR(16) NOT NULL PRIMARY KEY,
  file_name    VARCHAR(255) NOT NULL,
  mime         VARCHAR(100) NOT NULL DEFAULT 'application/pdf',
  size_bytes   INT UNSIGNED NOT NULL,
  data         LONGBLOB NOT NULL,
  uploaded_by  VARCHAR(190) NOT NULL DEFAULT '',
  uploaded_at  DATETIME NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS audit_logs (
  id         INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  user_email VARCHAR(190) NOT NULL,
  role       VARCHAR(16) NULL,
  flight_id  VARCHAR(64) NOT NULL,
  field      VARCHAR(64) NOT NULL,
  old_value  LONGTEXT NULL,
  new_value  LONGTEXT NULL,
  created_at DATETIME NOT NULL,
  KEY idx_audit_created (created_at),
  KEY idx_audit_flight (flight_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
