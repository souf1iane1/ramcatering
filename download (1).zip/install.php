<?php
declare(strict_types=1);
/**
 * Check-list — one-time web installer.
 *   1. asks for the MySQL credentials and writes api/config.php
 *   2. creates the tables (database/schema.<driver>.sql)
 *   3. creates the first admin account
 * It refuses to run once any user exists, and deletes itself when finished.
 * If it is still on the server afterwards, DELETE IT.
 */
session_start();
$root = __DIR__;
$cfgFile = $root . '/api/config.php';

function h($s): string { return htmlspecialchars((string) $s, ENT_QUOTES, 'UTF-8'); }

function connect(string $dsn, string $user, string $pass): PDO {
    return new PDO($dsn, $user, $pass, [PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION, PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC]);
}

function user_count(PDO $pdo): int {
    try { return (int) $pdo->query('SELECT COUNT(*) FROM users')->fetchColumn(); }
    catch (Throwable) { return 0; } // table doesn't exist yet
}

function import_schema(PDO $pdo, string $root): void {
    $driver = $pdo->getAttribute(PDO::ATTR_DRIVER_NAME);
    $file = "$root/database/schema.$driver.sql";
    if (!is_file($file)) throw new RuntimeException("No schema file for the '$driver' driver (expected database/schema.$driver.sql).");
    $sql = preg_replace('/^\s*--.*$/m', '', (string) file_get_contents($file));
    foreach (array_filter(array_map('trim', explode(';', $sql))) as $stmt) $pdo->exec($stmt);
}

// ---- load an existing config, if any
$pdo = null; $dbError = null;
if (is_file($cfgFile)) {
    try {
        $cfg = require $cfgFile;
        $pdo = connect((string) ($cfg['db_dsn'] ?? ''), (string) ($cfg['db_user'] ?? ''), (string) ($cfg['db_pass'] ?? ''));
    } catch (Throwable $e) { $dbError = $e->getMessage(); }
}

// ---- lock: already installed
if ($pdo && user_count($pdo) > 0) {
    http_response_code(403);
    page('Already installed', '<p>This site is already set up, so the installer is disabled.</p><p><b>Delete <code>install.php</code> from the server.</b></p><p><a href="login.html">Go to login</a></p>');
    exit;
}

$_SESSION['t'] ??= bin2hex(random_bytes(16));
$error = null; $done = null;

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (!hash_equals($_SESSION['t'], (string) ($_POST['t'] ?? ''))) { http_response_code(400); exit('Bad token — reload the page.'); }
    try {
        if (($_POST['action'] ?? '') === 'db') {
            $dsn = trim((string) ($_POST['dsn'] ?? ''));
            if ($dsn === '') {
                $host = trim((string) $_POST['host']); $name = trim((string) $_POST['dbname']);
                if ($host === '' || $name === '') throw new RuntimeException('Host and database name are required.');
                $dsn = "mysql:host=$host;dbname=$name;charset=utf8mb4";
            }
            $user = (string) ($_POST['dbuser'] ?? ''); $pass = (string) ($_POST['dbpass'] ?? '');
            $test = connect($dsn, $user, $pass);              // fails here if credentials are wrong
            import_schema($test, $root);
            $conf = ['db_dsn' => $dsn, 'db_user' => $user, 'db_pass' => $pass,
                     'session_name' => 'checklist_sid', 'remember_days' => 30, 'session_idle_hours' => 12,
                     'cookie_secure' => 'auto', 'timezone' => 'UTC'];
            $php = "<?php\n// Written by install.php\nreturn " . var_export($conf, true) . ";\n";
            if (@file_put_contents($cfgFile, $php, LOCK_EX) === false) {
                $done = 'manual'; $manual = $php;   // api/ not writable: show the file to paste
            } else {
                @chmod($cfgFile, 0640);
                header('Location: install.php'); exit;
            }
        } elseif (($_POST['action'] ?? '') === 'admin' && $pdo) {
            $name = trim((string) $_POST['name']); $email = strtolower(trim((string) $_POST['email']));
            $pw = (string) $_POST['password'];
            if ($name === '' || mb_strlen($name) > 120) throw new RuntimeException('Enter a name (120 characters max).');
            if (!filter_var($email, FILTER_VALIDATE_EMAIL)) throw new RuntimeException('Invalid email address.');
            if (strlen($pw) < 8) throw new RuntimeException('Password must be at least 8 characters.');
            if ($pw !== (string) $_POST['password2']) throw new RuntimeException('The two passwords do not match.');
            try { $pdo->query('SELECT 1 FROM users LIMIT 1'); } catch (Throwable) { import_schema($pdo, $root); } // safety net if step 1 was skipped
            if (user_count($pdo) > 0) throw new RuntimeException('An account already exists.');
            $st = $pdo->prepare('INSERT INTO users (name, email, password_hash, role, active, created_at) VALUES (?,?,?,?,1,?)');
            $st->execute([$name, $email, password_hash($pw, PASSWORD_DEFAULT), 'admin', gmdate('Y-m-d H:i:s')]);
            $_SESSION = []; // fresh token next time
            $deleted = @unlink(__FILE__);
            page('Installed ✓', '<p>Admin account <b>' . h($email) . '</b> created.</p>'
                . ($deleted ? '<p>The installer deleted itself.</p>' : '<p><b>Now delete <code>install.php</code> from the server</b> (it could not remove itself).</p>')
                . '<p><a class="btn" href="login.html">Go to login</a></p>');
            exit;
        }
    } catch (Throwable $e) { $error = $e->getMessage(); }
}

// ---- render the right step
$t = h($_SESSION['t']);
$err = $error ? '<div class="err">' . h($error) . '</div>' : '';

if ($done === 'manual') {
    page('Create config manually', '<p>Could not write <code>api/config.php</code> (folder not writable). Create it with this content, then reload this page:</p><pre>' . h($manual) . '</pre>');
} elseif (!$pdo) {
    $note = $dbError ? '<div class="err">The existing api/config.php does not work: ' . h($dbError) . '</div>' : '';
    page('Step 1 — Database', $note . $err . <<<HTML
<form method="post" autocomplete="off">
  <input type="hidden" name="t" value="$t"><input type="hidden" name="action" value="db">
  <label>Database host<input name="host" value="localhost"></label>
  <label>Database name<input name="dbname" required></label>
  <label>Database user<input name="dbuser"></label>
  <label>Database password<input name="dbpass" type="password"></label>
  <details><summary>Advanced: custom PDO DSN</summary><label>DSN (overrides host/name)<input name="dsn" placeholder="mysql:host=...;dbname=...;charset=utf8mb4"></label></details>
  <button>Connect &amp; create tables</button>
</form>
HTML);
} else {
    page('Step 2 — First admin', $err . <<<HTML
<p>Database connected and tables created. Create the administrator account:</p>
<form method="post" autocomplete="off">
  <input type="hidden" name="t" value="$t"><input type="hidden" name="action" value="admin">
  <label>Full name<input name="name" required></label>
  <label>Email<input name="email" type="email" required></label>
  <label>Password (8+ characters)<input name="password" type="password" minlength="8" required></label>
  <label>Repeat password<input name="password2" type="password" minlength="8" required></label>
  <button>Create admin</button>
</form>
HTML);
}

function page(string $title, string $body): void {
    echo '<!doctype html><html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">'
       . '<meta name="robots" content="noindex"><title>Check-list installer</title><style>'
       . 'body{margin:0;background:#0e1a2b;color:#e8eef7;font:15px/1.5 system-ui,sans-serif;display:flex;justify-content:center;padding:32px 16px}'
       . '.card{background:#15263d;border-radius:12px;padding:24px;max-width:460px;width:100%}h1{margin:0 0 16px;font-size:20px}'
       . 'label{display:block;margin:12px 0;font-size:13px;color:#a9b8cf}input{display:block;width:100%;box-sizing:border-box;margin-top:4px;padding:10px;border-radius:8px;border:1px solid #2c4262;background:#0e1a2b;color:#fff;font-size:15px}'
       . 'button,.btn{display:inline-block;margin-top:12px;padding:11px 18px;border:0;border-radius:8px;background:#f5a623;color:#111;font-weight:600;font-size:15px;cursor:pointer;text-decoration:none}'
       . '.err{background:#4a1f24;border:1px solid #a33;padding:10px;border-radius:8px;margin-bottom:12px}pre{white-space:pre-wrap;background:#0e1a2b;padding:10px;border-radius:8px;font-size:12px}a{color:#f5a623}details{margin-top:8px;font-size:13px}'
       . '</style></head><body><div class="card"><h1>' . h($title) . '</h1>' . $body . '</div></body></html>';
}
