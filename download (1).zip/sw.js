const CACHE_VERSION = "check-list-v64";
const APP_SHELL = [
  "./",
  "index.html",
  "splash.html",
  "login.html",
  "404.html",
  "privacy.html",
  "terms.html",
  "dashboard.html",
  "flights.html",
  "flight.html",
  "admin/upload.html",
  "admin/planning.html",
  "js/planning.js",
  "admin/users.html",
  "admin/audit.html",
  "css/style.css",
  "js/api.js",
  "js/checklist-rules.js",
  "js/pw-toggle.js",
  "profile.html",
  "my-planning.html",
  "js/my-planning.js",
  "js/profile.js",
  "js/auth.js",
  "js/data.js",
  "js/dashboard.js",
  "js/flights-list.js",
  "js/flight-detail.js",
  "js/export.js",
  "js/shifts.js",
  "js/ring.js",
  "js/pdf-parser.js",
  "js/icons.js",
  "js/theme.js",
  "js/confirm.js",
  "js/flight-editor.js",
  "js/tech-sheets.js",
  "js/loading-plans.js",
  "js/loading-plan-viewer.js",
  "js/manual-split.js",
  "js/assign.js",
  "js/upload.js",
  "js/excel-parser.js",
  "js/admin-users.js",
  "js/audit.js",
  "js/pwa.js",
  "manifest.webmanifest",
  "assets/logo.png",
  "assets/logo-sm.png",
  "assets/logo-white.png",
  "assets/logo-white-sm.png",
  "assets/icons/icon-192.png",
  "assets/icons/icon-512.png",
  "assets/icons/icon-maskable-192.png",
  "assets/icons/icon-maskable-512.png",
  "assets/icons/apple-touch-icon.png",
  "assets/icons/favicon-32.png",
];


// Files the app cannot work without: install fails (and the previous version keeps running) unless
// ALL of them are fetched. Icons are optional.
const isOptional = (u) => u.startsWith("assets/icons/");

self.addEventListener("install", (event) => {
  event.waitUntil(
    caches.open(CACHE_VERSION).then(async (cache) => {
      const core = APP_SHELL.filter((u) => !isOptional(u));
      await cache.addAll(core.map((u) => new Request(u, { cache: "reload" }))); // no .catch: all-or-nothing
      await Promise.all(APP_SHELL.filter(isOptional).map((u) => cache.add(new Request(u, { cache: "reload" })).catch(() => {})));
    })
  );
  self.skipWaiting();
});

self.addEventListener("activate", (event) => {
  event.waitUntil(
    caches.keys().then((keys) => Promise.all(keys.filter((k) => k !== CACHE_VERSION).map((k) => caches.delete(k))))
      .then(() => self.clients.claim())
  );
});

const NETWORK_TIMEOUT_MS = 6000;

/** Fresh copy from the network (revalidated against the server); cache only on failure/timeout. */
function networkFirst(req) {
  return new Promise((resolve) => {
    let settled = false;
    const fromCache = () => caches.match(req, { ignoreSearch: true }).then((hit) => hit || (req.mode === "navigate" ? caches.match("index.html") : undefined));
    const timer = setTimeout(() => {
      fromCache().then((hit) => { if (hit && !settled) { settled = true; resolve(hit); } });
    }, NETWORK_TIMEOUT_MS);

    fetch(req, { cache: "no-cache" })
      .then((res) => {
        clearTimeout(timer);
        if (res.ok) {
          const copy = res.clone();
          caches.open(CACHE_VERSION).then((cache) => cache.put(req, copy)).catch(() => {});
        }
        if (!settled) { settled = true; resolve(res); }
      })
      .catch(() => {
        clearTimeout(timer);
        fromCache().then((hit) => { if (!settled) { settled = true; resolve(hit || Response.error()); } });
      });
  });
}

self.addEventListener("fetch", (event) => {
  const req = event.request;
  if (req.method !== "GET") return;
  const url = new URL(req.url);
  if (url.origin !== self.location.origin) return;      // CDN scripts etc.: always live
  if (url.pathname.includes("/api/")) return;           // PHP API: never cached
  if (url.pathname.endsWith("/sw.js")) return;          // let the browser update the worker itself
  event.respondWith(networkFirst(req));
});
