<?php
// Create (or reset) a user from the command line — use this for your FIRST admin:
//   php tools/create_admin.php "Full Name" admin@example.com 'S3cretPassw0rd' [admin|controller]
if (PHP_SAPI !== 'cli') { http_response_code(404); exit; }
require __DIR__ . '/../api/bootstrap.php';

[, $name, $email, $password] = $argv + [null, null, null, null];
$role = $argv[4] ?? 'admin';
if (!$name || !$email || !$password) { fwrite(STDERR, "Usage: php tools/create_admin.php \"Name\" email password [admin|controller]\n"); exit(1); }
if (!filter_var($email, FILTER_VALIDATE_EMAIL)) { fwrite(STDERR, "Invalid email.\n"); exit(1); }
if (strlen($password) < 8) { fwrite(STDERR, "Password must be at least 8 characters.\n"); exit(1); }
if (!in_array($role, ['admin', 'controller'], true)) { fwrite(STDERR, "Role must be admin or controller.\n"); exit(1); }

$email = strtolower(trim($email));
$hash = password_hash($password, PASSWORD_DEFAULT);
if (q('SELECT 1 FROM users WHERE email = ?', [$email])->fetch()) {
    q('UPDATE users SET name = ?, password_hash = ?, role = ?, active = 1 WHERE email = ?', [$name, $hash, $role, $email]);
    echo "Updated existing user $email ($role).\n";
} else {
    q('INSERT INTO users (name, email, password_hash, role, active, created_at) VALUES (?,?,?,?,1,?)', [$name, $email, $hash, $role, now_db()]);
    echo "Created $role $email.\n";
}
