<?php
// Local development only:   php -S localhost:8000 -t . tools/dev-router.php
// Mimics the Apache rewrite in api/.htaccess for PHP's built-in server.
$path = parse_url($_SERVER['REQUEST_URI'], PHP_URL_PATH);
if (preg_match('#^/api/(.*)$#', $path, $m) && !is_file(__DIR__ . '/../api/' . $m[1])) {
    $_GET['route'] = $m[1];
    require __DIR__ . '/../api/index.php';
    return true;
}
return false; // serve static files normally
