<?php
declare(strict_types=1);

/**
 * Check-list JSON API  (replaces Firebase Auth + Firestore).
 *
 *   POST   auth/login            {email, password, remember}
 *   POST   auth/logout
 *   GET    auth/me
 *   GET    auth/diag             (cookie/session diagnostics, no private data)
 *   PATCH  auth/profile          {name}                       (own profile)
 *   POST   auth/password         {currentPassword,newPassword} (own password)
 *
 *   GET    users[?role=controller]          admin
 *   POST   users                            admin  {name,email,password,role}
 *   PATCH  users/{id}                       admin  {role?, active?, password?}
 *   DELETE users/{id}                       admin  (not yourself, not the last admin)
 *
 *   GET    flights                          admin|controller
 *   GET    flight?id=ID                     admin|controller
 *   DELETE flight?id=ID                     admin
 *   POST   flight                           admin  {flightNumber,date,core:{...},controller:{...}}   (add a flight by hand)
 *   PATCH  flight?id=ID                     admin  {core:{...},controller:{...}}                     (edit a flight)
 *   PATCH  flight/controller?id=ID          controller  {changes:{field:value,...}}
 *
 *   POST   recaps                           admin  {fileName,date,flights:[...]}
 *   GET    recaps[?limit=20]                admin|controller
 *   GET    audit-logs[?limit=200]           admin
 *
 *   GET    shift-plans[?date=YYYY-MM-DD]    admin|controller
 *   PUT    shift-plans                      admin  {date,shift,controllers,assignments}
 *   DELETE shift-plans?id=DATE_SHIFT        admin
 *
 *   GET    planning[?dates=a,b]             admin|controller
 *   PUT    planning                         admin  {source, days:[{date,morning,...}]}
 *
 *   GET    loading-plans                           admin|controller  (metadata only, no PDF bytes)
 *   POST   loading-plans                           admin  {type,fileName,dataBase64}  (upsert by type)
 *   DELETE loading-plans?type=XXX                  admin
 *   GET    loading-plan?type=XXX                   admin|controller  -> raw PDF bytes
 *
 *   « Fiche technique » — one PDF per code prestation (DC25, BC55, CF99…), same shape as loading plans:
 *   GET    tech-sheets                             admin|controller  (metadata only)
 *   POST   tech-sheets                             admin  {type,fileName,dataBase64}  (upsert by code)
 *   DELETE tech-sheets?type=XXX                    admin
 *   GET    tech-sheet?type=XXX                     admin|controller  -> raw PDF bytes
 */

require __DIR__ . '/bootstrap.php';

const SHIFT_KEYS = ['morning', 'afternoon', 'night'];
const CORE_FIELDS = ['heureDepart', 'heureMAD', 'aircraftType', 'aircraftCategory', 'numEnregistrement', 'note', 'imported', 'recapShift', 'recapPart', 'recapIdx'];
const EMPTY_CONTROLLER_JSON = '{"paxAllerReel":null,"paxRetourReel":null,"paxAllerReelCcl":null,"paxRetourReelCcl":null,'
    . '"hotMealAllerReel":null,"hotMealRetourReel":null,"specialMealsReel":{},'
    . '"viande":{"aller":"","retour":""},"poulet":{"aller":"","retour":""},"poisson":{"aller":"","retour":""},"veg":{"aller":"","retour":""},'
    . '"tiroir":"","verseuses":"","armoirs":"","chargeursFours":"","trolleys11":"","trolleys12":"",'
    . '"miseADispo":"","dep":"","finCtrl":"","qssAs":"","remarks":"","checklist":{}}';
const MAX_CONTROLLER_BYTES = 262144; // 256 KB per flight

// ---------------------------------------------------------------- flight helpers (ports of data.js)

/** A flight only has a "Retour" leg if the Récap carried "back" data for it. */
function has_retour_leg(?stdClass $core): bool {
    $im = $core->imported ?? null;
    if (!($im instanceof stdClass)) return false;
    $vals = [
        $im->yCl->paxRetourPrevu ?? null, $im->cCl->paxRetourPrevu ?? null,
        $im->peq->retourPrevu ?? null,    $im->bob->retourPrevu ?? null,
    ];
    foreach ($vals as $v) if ($v !== null) return true;
    return false;
}

function flight_status(stdClass $core, stdClass $c, ?string $updatedByName): string {
    $filled = static fn($v) => $v !== null && $v !== '';
    $allerDone = $filled($c->paxAllerReel ?? null);
    $retourDone = $filled($c->paxRetourReel ?? null);
    if (!has_retour_leg($core)) return $updatedByName ? 'completed' : 'pending';
    if ($allerDone && $retourDone) return 'completed';
    if ($allerDone || $retourDone) return 'in_progress';
    return 'pending';
}

function flight_doc(array $r): array {
    $core = jdecode($r['core']) ?? new stdClass();
    $doc = [
        'id' => $r['id'], 'flightNumber' => $r['flight_number'], 'date' => $r['flight_date'],
    ];
    foreach (CORE_FIELDS as $k) $doc[$k] = $core->$k ?? null;
    $doc += [
        'controller' => jdecode($r['controller']) ?? new stdClass(),
        'status' => $r['status'],
        'recapId' => $r['recap_id'] !== null ? (string) $r['recap_id'] : null,
        'createdAt' => iso($r['created_at']), 'createdBy' => $r['created_by'] !== null ? (string) $r['created_by'] : null,
        'updatedAt' => iso($r['updated_at']), 'updatedBy' => $r['updated_by'] !== null ? (string) $r['updated_by'] : null,
        'updatedByName' => $r['updated_by_name'],
    ];
    return $doc;
}

function flight_id_param(): string {
    $id = (string) ($_GET['id'] ?? '');
    if ($id === '' || strlen($id) > 64) fail(400, 'Identifiant de vol invalide.');
    return $id;
}

// ---------------------------------------------------------------- handlers

function h_login(): never {
    $b = body();
    $email = strtolower(trim((string) ($b->email ?? '')));
    $password = (string) ($b->password ?? '');
    $remember = !empty($b->remember);
    if ($email === '' || $password === '') fail(400, 'Email et mot de passe requis.');

    // Throttle: 8 failures / 15 min per (ip, email).
    $ip = substr((string) ($_SERVER['REMOTE_ADDR'] ?? ''), 0, 45);
    q('DELETE FROM login_attempts WHERE attempted_at < ?', [time() - 900]);
    $n = (int) q('SELECT COUNT(*) c FROM login_attempts WHERE ip = ? AND email = ? AND attempted_at >= ?', [$ip, $email, time() - 900])->fetch()['c'];
    if ($n >= 8) fail(429, 'Trop de tentatives. Réessayez dans quelques minutes.');

    $u = q('SELECT * FROM users WHERE email = ?', [$email])->fetch();
    // Always run a hash check so response time doesn't reveal whether the email exists.
    $ok = password_verify($password, $u['password_hash'] ?? password_hash('dummy-password', PASSWORD_DEFAULT));
    if (!$u || !$ok) {
        q('INSERT INTO login_attempts (ip, email, attempted_at) VALUES (?, ?, ?)', [$ip, $email, time()]);
        fail(401, 'Email ou mot de passe incorrect.');
    }
    if (!(int) $u['active']) fail(403, 'Ce compte est désactivé.');
    if (!in_array($u['role'], ['admin', 'controller'], true)) fail(403, "Rôle invalide : {$u['role']}");

    q('DELETE FROM login_attempts WHERE ip = ? AND email = ?', [$ip, $email]);
    if (password_needs_rehash($u['password_hash'], PASSWORD_DEFAULT)) {
        q('UPDATE users SET password_hash = ? WHERE id = ?', [password_hash($password, PASSWORD_DEFAULT), $u['id']]);
    }

    $sid = create_session((int) $u['id'], $remember);
    // `token` is the same id as the cookie; the login page only keeps it if the browser refuses cookies.
    json_out(profile_of($u) + ['token' => $sid]);
}

function h_logout(): never {
    foreach (offered_session_ids() as $sid) q('DELETE FROM sessions WHERE id = ?', [$sid]);
    clear_session_cookie();
    json_out(['ok' => true]);
}

function h_me(): never { json_out(profile_of(require_login())); }

/** Safe diagnostics for "login works but I'm not signed in" problems. No user data. */
function h_diag(): never {
    $name = (string) cfg('session_name');
    $cookie = $_COOKIE[$name] ?? null;
    $header = $_SERVER['HTTP_X_AUTH_TOKEN'] ?? null;
    $ids = offered_session_ids();
    $found = false;
    foreach ($ids as $sid) if (q('SELECT 1 FROM sessions WHERE id = ?', [$sid])->fetch()) $found = true;
    json_out([
        'version' => API_VERSION,
        'cookieReceived' => $cookie !== null, 'tokenHeaderReceived' => $header !== null, 'sessionInDb' => $found,
        'https' => is_https(), 'secureCookie' => cookie_secure(),
        'forwardedProto' => $_SERVER['HTTP_X_FORWARDED_PROTO'] ?? null,
        'serverTime' => gmdate('c'),
    ]);
}

function h_profile_update(): never {
    $u = require_login();
    $name = trim((string) (body()->name ?? ''));
    if ($name === '' || mb_strlen($name) > 120) fail(400, 'Nom requis (120 caractères max).');
    q('UPDATE users SET name = ? WHERE id = ?', [$name, $u['id']]);
    json_out(profile_of(q('SELECT * FROM users WHERE id = ?', [$u['id']])->fetch()));
}

function h_password_change(): never {
    $u = require_login();
    $b = body();
    $current = (string) ($b->currentPassword ?? '');
    $new = (string) ($b->newPassword ?? '');
    if (strlen($new) < 8) fail(400, 'Le nouveau mot de passe doit contenir au moins 8 caractères.');

    // Same throttle as login, so a stolen session can't be used to guess the current password.
    $ip = substr((string) ($_SERVER['REMOTE_ADDR'] ?? ''), 0, 45);
    $key = 'pw:' . $u['email'];
    q('DELETE FROM login_attempts WHERE attempted_at < ?', [time() - 900]);
    $n = (int) q('SELECT COUNT(*) c FROM login_attempts WHERE ip = ? AND email = ? AND attempted_at >= ?', [$ip, $key, time() - 900])->fetch()['c'];
    if ($n >= 8) fail(429, 'Trop de tentatives. Réessayez dans quelques minutes.');

    if (!password_verify($current, $u['password_hash'])) {
        q('INSERT INTO login_attempts (ip, email, attempted_at) VALUES (?, ?, ?)', [$ip, $key, time()]);
        fail(403, 'Mot de passe actuel incorrect.');
    }
    if (hash_equals($current, $new)) fail(400, "Le nouveau mot de passe doit être différent de l'actuel.");
    q('DELETE FROM login_attempts WHERE ip = ? AND email = ?', [$ip, $key]);
    q('UPDATE users SET password_hash = ? WHERE id = ?', [password_hash($new, PASSWORD_DEFAULT), $u['id']]);
    // Sign out every device, then keep this one signed in with a fresh session.
    $remember = (bool) (auth_state()['remember'] ?? false);
    delete_sessions_of_user((int) $u['id']);
    $sid = create_session((int) $u['id'], $remember);
    json_out(['ok' => true, 'token' => $sid]);
}

function h_users_list(): never {
    require_role('admin');
    $role = $_GET['role'] ?? null;
    if ($role !== null && !in_array($role, ['admin', 'controller'], true)) fail(400, 'Rôle invalide.');
    $sql = 'SELECT * FROM users' . ($role ? ' WHERE role = ?' : '') . ' ORDER BY ' . ($role ? 'name' : 'email');
    json_out(array_map('profile_of', q($sql, $role ? [$role] : [])->fetchAll()));
}

function h_users_create(): never {
    require_role('admin');
    $b = body();
    $name = trim((string) ($b->name ?? ''));
    $email = strtolower(trim((string) ($b->email ?? '')));
    $password = (string) ($b->password ?? '');
    $role = (string) ($b->role ?? 'controller');
    if ($name === '' || mb_strlen($name) > 120) fail(400, 'Nom requis (120 caractères max).');
    if (!filter_var($email, FILTER_VALIDATE_EMAIL) || strlen($email) > 190) fail(400, 'Email invalide.');
    if (strlen($password) < 8) fail(400, 'Le mot de passe doit contenir au moins 8 caractères.');
    if (!in_array($role, ['admin', 'controller'], true)) fail(400, 'Rôle invalide.');
    if (q('SELECT 1 FROM users WHERE email = ?', [$email])->fetch()) fail(409, 'Cet email est déjà utilisé.');
    q('INSERT INTO users (name, email, password_hash, role, active, created_at) VALUES (?, ?, ?, ?, 1, ?)',
      [$name, $email, password_hash($password, PASSWORD_DEFAULT), $role, now_db()]);
    $row = q('SELECT * FROM users WHERE email = ?', [$email])->fetch();
    json_out(profile_of($row), 201);
}

function h_users_update(string $id): never {
    $me = require_role('admin');
    $target = q('SELECT * FROM users WHERE id = ?', [$id])->fetch();
    if (!$target) fail(404, 'Utilisateur introuvable.');
    if ((int) $target['id'] === owner_id() && (int) $me['id'] !== owner_id()) {
        fail(403, 'Le compte propriétaire (premier administrateur) ne peut pas être modifié par un autre administrateur.');
    }
    $b = body();
    $sets = []; $params = [];
    if (isset($b->role)) {
        if (!in_array($b->role, ['admin', 'controller'], true)) fail(400, 'Rôle invalide.');
        if ((int) $target['id'] === (int) $me['id'] && $b->role !== 'admin') fail(400, 'Vous ne pouvez pas retirer votre propre rôle admin.');
        $sets[] = 'role = ?'; $params[] = $b->role;
    }
    if (isset($b->active)) {
        if ((int) $target['id'] === (int) $me['id'] && !$b->active) fail(400, 'Vous ne pouvez pas désactiver votre propre compte.');
        $sets[] = 'active = ?'; $params[] = $b->active ? 1 : 0;
    }
    $passwordReset = isset($b->password);
    $deactivating = isset($b->active) && !$b->active;
    if ($passwordReset) {
        // Password reset from the admin dashboard is intentionally limited to controller accounts.
        $effectiveRole = isset($b->role) ? (string) $b->role : (string) $target['role'];
        if ($target['role'] !== 'controller' || $effectiveRole !== 'controller') fail(400, 'La réinitialisation est réservée aux comptes Controller.');
        $newPassword = (string) $b->password;
        if (strlen($newPassword) < 8) fail(400, 'Le mot de passe doit contenir au moins 8 caractères.');
        if (strlen($newPassword) > 4096) fail(400, 'Le mot de passe est trop long.');
        $sets[] = 'password_hash = ?'; $params[] = password_hash($newPassword, PASSWORD_DEFAULT);
    }
    if (!$sets) fail(400, 'Rien à modifier.');
    $params[] = $id;
    tx(static function () use ($sets, $params, $passwordReset, $deactivating, $target, $me, $id): void {
        q('UPDATE users SET ' . implode(', ', $sets) . ' WHERE id = ?', $params);
        if ($passwordReset) {
            // Never store the password or its hash in the audit log.
            q('INSERT INTO audit_logs (user_email, role, flight_id, field, old_value, new_value, created_at) VALUES (?,?,?,?,?,?,?)', [
                $me['email'], $me['role'], 'USER-' . $id, 'password_reset', null,
                json_encode(['action' => 'password_reset', 'target_email' => $target['email']], JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES), now_db()
            ]);
        }
        if ($passwordReset || $deactivating) delete_sessions_of_user((int) $id);
    });
    json_out(profile_of(q('SELECT * FROM users WHERE id = ?', [$id])->fetch()));
}

function h_users_delete(string $id): never {
    $me = require_role('admin');
    if (!ctype_digit($id)) fail(400, 'Identifiant invalide.');
    $target = q('SELECT * FROM users WHERE id = ?', [$id])->fetch();
    if (!$target) fail(404, 'Utilisateur introuvable.');
    if ((int) $target['id'] === owner_id()) fail(403, 'Le compte propriétaire (premier administrateur) ne peut pas être supprimé.');
    if ((int) $target['id'] === (int) $me['id']) fail(400, 'Vous ne pouvez pas supprimer votre propre compte.');
    if ($target['role'] === 'admin') {
        $admins = (int) q("SELECT COUNT(*) FROM users WHERE role = 'admin' AND active = 1 AND id <> ?", [$id])->fetchColumn();
        if ($admins < 1) fail(400, 'Impossible de supprimer le dernier administrateur.');
    }
    tx(static function () use ($target, $me, $id): void {
        delete_sessions_of_user((int) $id);
        q('DELETE FROM users WHERE id = ?', [$id]);
        q('INSERT INTO audit_logs (user_email, role, flight_id, field, old_value, new_value, created_at) VALUES (?,?,?,?,?,?,?)', [
            $me['email'], $me['role'], 'USER-' . $id, 'user_deleted',
            json_encode(['name' => $target['name'], 'email' => $target['email'], 'role' => $target['role']], JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES),
            null, now_db()
        ]);
    });
    json_out(['ok' => true]);
}

function h_flights_list(): never {
    require_role('admin', 'controller');
    json_out(array_map('flight_doc', q('SELECT * FROM flights ORDER BY flight_number')->fetchAll()));
}

function h_flight_get(): never {
    require_role('admin', 'controller');
    $r = q('SELECT * FROM flights WHERE id = ?', [flight_id_param()])->fetch();
    if (!$r) fail(404, 'Vol introuvable.');
    json_out(flight_doc($r));
}

function h_flight_delete(): never {
    require_role('admin');
    $st = q('DELETE FROM flights WHERE id = ?', [flight_id_param()]);
    if ($st->rowCount() === 0) fail(404, 'Vol introuvable.');
    json_out(['ok' => true]);
}

function h_flight_controller_update(): never {
    $u = require_role('controller'); // same as the old rules: only controllers write controller data
    $id = flight_id_param();
    $changes = body()->changes ?? null;
    if (!($changes instanceof stdClass) || !get_object_vars($changes)) fail(400, 'Aucune modification.');
    foreach (array_keys(get_object_vars($changes)) as $k) {
        if (!preg_match('/^[A-Za-z][A-Za-z0-9_]{0,63}$/', (string) $k)) fail(400, "Champ invalide : $k");
    }

    $doc = tx(function () use ($u, $id, $changes) {
        $r = q('SELECT * FROM flights WHERE id = ?' . (is_mysql() ? ' FOR UPDATE' : ''), [$id])->fetch();
        if (!$r) fail(404, 'Vol introuvable.');
        $core = jdecode($r['core']) ?? new stdClass();
        $old = jdecode($r['controller']) ?? new stdClass();
        $new = clone $old;
        foreach ($changes as $k => $v) $new->$k = $v;
        $newJson = jencode($new);
        if (strlen($newJson) > MAX_CONTROLLER_BYTES) fail(413, 'Données trop volumineuses.');

        $by = $u['name'] ?: $u['email'];
        $status = flight_status($core, $new, $by); // this save is what sets updatedByName
        q('UPDATE flights SET controller = ?, status = ?, updated_at = ?, updated_by = ?, updated_by_name = ? WHERE id = ?',
          [$newJson, $status, now_db(), $u['id'], $by, $id]);

        $now = now_db();
        foreach ($changes as $field => $value) {
            $oldValue = $old->$field ?? null;
            if (jencode($oldValue) === jencode($value)) continue;
            q('INSERT INTO audit_logs (user_email, role, flight_id, field, old_value, new_value, created_at) VALUES (?,?,?,?,?,?,?)',
              [$u['email'], $u['role'], $id, (string) $field, jencode($oldValue), jencode($value), $now]);
        }
        return flight_doc(q('SELECT * FROM flights WHERE id = ?', [$id])->fetch());
    });
    json_out($doc);
}

// ---------------------------------------------------------------- admin: edit / add a flight by hand

const EDIT_BLOCKS = [
    'peq' => ['codePrestation' => 's', 'allerPrevu' => 'n', 'retourPrevu' => 'n'],
    'cCl' => ['codePrestation' => 's', 'paxAllerPrevu' => 'n', 'paxRetourPrevu' => 'n'],
    'yCl' => ['codePrestation' => 's', 'paxAllerPrevu' => 'n', 'paxRetourPrevu' => 'n'],
];
const EDIT_CONTROLLER_FIELDS = ['paxAllerReel', 'paxRetourReel', 'paxAllerReelCcl', 'paxRetourReelCcl'];
const EDIT_CATEGORIES = ['LONG_COURRIER', 'MOYEN_COURRIER', 'COURT_COURRIER'];

function edit_str(mixed $v, int $max = 120): string {
    return mb_substr(trim((string) ($v ?? '')), 0, $max);
}
function edit_count(mixed $v): ?int {
    if ($v === null || $v === '') return null;
    if (!is_numeric($v) || (float) $v < 0 || (float) $v > 100000) fail(400, 'Nombre invalide : ' . (is_scalar($v) ? (string) $v : '?'));
    return (int) $v;
}
function edit_time(mixed $v): string {
    $s = trim((string) ($v ?? ''));
    if ($s === '') return '';
    if (!preg_match('/^(\d{1,2}):(\d{2})$/', $s, $m) || (int) $m[1] > 23 || (int) $m[2] > 59) fail(400, "Heure invalide : $s (format HH:MM).");
    return sprintf('%02d:%02d', (int) $m[1], (int) $m[2]);
}
function edit_audit(array $u, string $flightId, string $field, $old, $new): void {
    q('INSERT INTO audit_logs (user_email, role, flight_id, field, old_value, new_value, created_at) VALUES (?,?,?,?,?,?,?)',
      [$u['email'], $u['role'], $flightId, $field, jencode($old), jencode($new), now_db()]);
}

/** Applies the admin's edits to the "core" (Récap half) of a flight. Returns [field, old, new] for each change. */
function apply_core_patch(stdClass $core, stdClass $patch): array {
    $log = [];
    $set = static function (stdClass $o, string $k, $new, string $path) use (&$log): void {
        $old = $o->$k ?? null;
        if (jencode($old) === jencode($new)) return;
        $o->$k = $new;
        $log[] = [$path, $old, $new];
    };
    foreach (['heureDepart', 'heureMAD'] as $k) if (property_exists($patch, $k)) $set($core, $k, edit_time($patch->$k), "admin.$k");
    // the admin changed a time by hand: the shift detected from the recap order no longer applies -> time rule
    if (count($log) && (($core->recapShift ?? null) !== null)) { $core->recapShift = null; $core->recapPart = null; }
    foreach (['aircraftType', 'numEnregistrement'] as $k) if (property_exists($patch, $k)) $set($core, $k, edit_str($patch->$k, 40), "admin.$k");
    if (property_exists($patch, 'note')) $set($core, 'note', edit_str($patch->note, 500), 'admin.note');
    if (property_exists($patch, 'aircraftCategory')) {
        $c = (string) ($patch->aircraftCategory ?? '');
        if ($c !== '' && !in_array($c, EDIT_CATEGORIES, true)) fail(400, 'Catégorie invalide.');
        $set($core, 'aircraftCategory', $c, 'admin.aircraftCategory');
    }
    $pi = $patch->imported ?? null;
    if ($pi instanceof stdClass) {
        if (!($core->imported ?? null) instanceof stdClass) $core->imported = new stdClass();
        foreach (EDIT_BLOCKS as $blk => $fields) {
            $pb = $pi->$blk ?? null;
            if (!($pb instanceof stdClass)) continue;
            if (!($core->imported->$blk ?? null) instanceof stdClass) $core->imported->$blk = new stdClass();
            foreach ($fields as $f => $type) {
                if (!property_exists($pb, $f)) continue;
                $val = $type === 'n' ? edit_count($pb->$f) : edit_str($pb->$f, 200);
                $set($core->imported->$blk, $f, $val, "admin.imported.$blk.$f");
            }
            // Special Meals of a cabin: [{code, allerPrevu, retourPrevu}] (one entry per code, max 40)
            if (in_array($blk, ['cCl', 'yCl'], true) && property_exists($pb, 'specialMeals') && is_array($pb->specialMeals)) {
                $list = [];
                $seen = [];
                foreach (array_slice($pb->specialMeals, 0, 40) as $sm) {
                    if (!($sm instanceof stdClass)) continue;
                    $code = strtoupper(preg_replace('/[^A-Za-z0-9]/', '', edit_str($sm->code ?? '', 20)));
                    if ($code === '' || isset($seen[$code])) continue;
                    $seen[$code] = true;
                    $o = new stdClass();
                    $o->code = $code;
                    $o->allerPrevu = edit_count($sm->allerPrevu ?? null);
                    $o->retourPrevu = edit_count($sm->retourPrevu ?? null);
                    $list[] = $o;
                }
                $set($core->imported->$blk, 'specialMeals', $list, "admin.imported.$blk.specialMeals");
            }
        }
    }
    return $log;
}

function apply_controller_patch(stdClass $ctl, stdClass $patch): array {
    $log = [];
    foreach (EDIT_CONTROLLER_FIELDS as $k) {
        if (!property_exists($patch, $k)) continue;
        $new = edit_count($patch->$k);
        $old = $ctl->$k ?? null;
        if (jencode($old) === jencode($new)) continue;
        $ctl->$k = $new;
        $log[] = ["admin.$k", $old, $new];
    }
    return $log;
}

function h_flight_admin_update(): never {
    $u = require_role('admin');
    $id = flight_id_param();
    $b = body();
    $pc = $b->core ?? null;
    $pk = $b->controller ?? null;
    if (!($pc instanceof stdClass) && !($pk instanceof stdClass)) fail(400, 'Aucune modification.');

    $doc = tx(function () use ($u, $id, $pc, $pk) {
        $r = q('SELECT * FROM flights WHERE id = ?' . (is_mysql() ? ' FOR UPDATE' : ''), [$id])->fetch();
        if (!$r) fail(404, 'Vol introuvable.');
        $core = jdecode($r['core']) ?? new stdClass();
        $ctl = jdecode($r['controller']) ?? new stdClass();
        $log = array_merge(
            $pc instanceof stdClass ? apply_core_patch($core, $pc) : [],
            $pk instanceof stdClass ? apply_controller_patch($ctl, $pk) : []
        );
        if (!$log) return flight_doc($r); // nothing actually changed
        $status = flight_status($core, $ctl, $r['updated_by_name']);
        q('UPDATE flights SET core = ?, controller = ?, status = ?, updated_at = ?, updated_by = ? WHERE id = ?',
          [jencode($core), jencode($ctl), $status, now_db(), $u['id'], $id]);
        foreach ($log as [$field, $old, $new]) edit_audit($u, $id, $field, $old, $new);
        return flight_doc(q('SELECT * FROM flights WHERE id = ?', [$id])->fetch());
    });
    json_out($doc);
}

function h_flight_create(): never {
    $u = require_role('admin');
    $b = body();
    $num = strtoupper(preg_replace('/\s+/', '', (string) ($b->flightNumber ?? '')));
    if (!preg_match('/^AT\d{3,4}$/', $num)) fail(400, 'Numéro de vol invalide (ex. AT208).');
    $date = (string) ($b->date ?? '');
    if (!preg_match('/^(\d{4})-(\d{2})-(\d{2})$/', $date, $m) || !checkdate((int) $m[2], (int) $m[3], (int) $m[1])) fail(400, 'Date invalide (AAAA-MM-JJ).');
    $id = $date . '_' . $num;

    $doc = tx(function () use ($u, $b, $id, $num, $date) {
        if (q('SELECT 1 FROM flights WHERE id = ?' . (is_mysql() ? ' FOR UPDATE' : ''), [$id])->fetch()) fail(409, "Le vol $num existe déjà pour le $date.");
        $core = new stdClass();
        foreach (CORE_FIELDS as $k) $core->$k = null;
        foreach (['heureDepart', 'heureMAD', 'aircraftType', 'aircraftCategory', 'numEnregistrement', 'note'] as $k) $core->$k = '';
        $core->imported = json_decode('{"cCl":{"codePrestation":"","paxAllerPrevu":null,"paxRetourPrevu":null,"specialMeals":[],"raw":[]},'
            . '"yCl":{"codePrestation":"","paxAllerPrevu":null,"paxRetourPrevu":null,"specialMeals":[],"raw":[]},'
            . '"peq":{"codePrestation":"","allerPrevu":null,"retourPrevu":null,"raw":[]},'
            . '"bob":{"codePrestation":"","allerPrevu":null,"retourPrevu":null,"raw":[]}}');
        $ctl = json_decode(EMPTY_CONTROLLER_JSON);
        if (($b->core ?? null) instanceof stdClass) apply_core_patch($core, $b->core);
        if (($b->controller ?? null) instanceof stdClass) apply_controller_patch($ctl, $b->controller);
        $now = now_db();
        q('INSERT INTO flights (id, flight_number, flight_date, status, core, controller, recap_id, created_at, created_by, updated_at, updated_by)
           VALUES (?,?,?,?,?,?,?,?,?,?,?)',
          [$id, $num, $date, flight_status($core, $ctl, null), jencode($core), jencode($ctl), null, $now, $u['id'], $now, $u['id']]);
        edit_audit($u, $id, 'admin.flightCreated', null, $num . ' ' . $date);
        return flight_doc(q('SELECT * FROM flights WHERE id = ?', [$id])->fetch());
    });
    json_out($doc, 201);
}

function h_recap_upload(): never {
    $u = require_role('admin');
    $b = body();
    $flights = $b->flights ?? null;
    if (!is_array($flights)) fail(400, 'Liste de vols manquante.');
    if (count($flights) > 3000) fail(413, 'Trop de vols dans un seul import.');
    $fileName = mb_substr((string) ($b->fileName ?? ''), 0, 255);
    $date = isset($b->date) && $b->date !== null ? mb_substr((string) $b->date, 0, 32) : null;
    $by = $u['name'] ?: $u['email'];

    $res = tx(function () use ($u, $by, $fileName, $date, $flights) {
        $now = now_db();
        q('INSERT INTO recaps (file_name, recap_date, uploaded_by, uploaded_by_name, uploaded_at, flight_count) VALUES (?,?,?,?,?,?)',
          [$fileName, $date, $u['id'], $by, $now, count($flights)]);
        $recapId = (int) db()->lastInsertId();
        $created = $updated = 0;

        foreach ($flights as $f) {
            if (!($f instanceof stdClass)) continue;
            $num = strtoupper((string) ($f->flightNumber ?? ''));
            // Safety layer: never store non-AT flights, even if the client parser is bypassed.
            if (!preg_match('/^AT\d{3,4}$/', $num)) continue;
            $fdate = isset($f->date) && $f->date !== null && $f->date !== '' ? mb_substr((string) $f->date, 0, 32) : null;
            $id = ($fdate ?? 'unknown') . '_' . $num;
            if (strlen($id) > 64) continue;

            $core = new stdClass();
            foreach (CORE_FIELDS as $k) $core->$k = $f->$k ?? null;
            // shift detected from the recap order (client side): keep only valid values
            $core->recapShift = in_array($core->recapShift, SHIFT_KEYS, true) ? $core->recapShift : null;
            $core->recapPart = in_array($core->recapPart, ['early', 'late'], true) ? $core->recapPart : null;
            $core->recapIdx = is_int($core->recapIdx) && $core->recapIdx >= 0 && $core->recapIdx < 5000 ? $core->recapIdx : null;
            $coreJson = jencode($core);

            $exists = q('SELECT 1 FROM flights WHERE id = ?' . (is_mysql() ? ' FOR UPDATE' : ''), [$id])->fetch();
            if ($exists) {
                // Re-import only refreshes the Récap half; controller data and status are untouched.
                q('UPDATE flights SET core = ?, recap_id = ?, updated_at = ?, updated_by = ? WHERE id = ?',
                  [$coreJson, $recapId, $now, $u['id'], $id]);
                $updated++;
            } else {
                q('INSERT INTO flights (id, flight_number, flight_date, status, core, controller, recap_id, created_at, created_by, updated_at, updated_by)
                   VALUES (?,?,?,?,?,?,?,?,?,?,?)',
                  [$id, $num, $fdate, 'pending', $coreJson, EMPTY_CONTROLLER_JSON, $recapId, $now, $u['id'], $now, $u['id']]);
                $created++;
            }
        }
        return ['recapId' => (string) $recapId, 'created' => $created, 'updated' => $updated, 'total' => count($flights)];
    });
    json_out($res, 201);
}

function h_recaps_list(): never {
    require_role('admin', 'controller');
    $limit = max(1, min(200, (int) ($_GET['limit'] ?? 20)));
    $rows = q("SELECT * FROM recaps ORDER BY uploaded_at DESC, id DESC LIMIT $limit")->fetchAll();
    json_out(array_map(static fn($r) => [
        'id' => (string) $r['id'], 'fileName' => $r['file_name'], 'date' => $r['recap_date'],
        'uploadedBy' => (string) $r['uploaded_by'], 'uploadedByName' => $r['uploaded_by_name'],
        'uploadedAt' => iso($r['uploaded_at']), 'flightCount' => (int) $r['flight_count'],
    ], $rows));
}

function h_audit_list(): never {
    require_role('admin');
    $limit = max(1, min(1000, (int) ($_GET['limit'] ?? 200)));
    $rows = q("SELECT * FROM audit_logs ORDER BY created_at DESC, id DESC LIMIT $limit")->fetchAll();
    json_out(array_map(static fn($r) => [
        'id' => (string) $r['id'], 'user' => $r['user_email'], 'role' => $r['role'],
        'flightId' => $r['flight_id'], 'field' => $r['field'],
        'oldValue' => jdecode($r['old_value']), 'newValue' => jdecode($r['new_value']),
        'timestamp' => iso($r['created_at']),
    ], $rows));
}

function plan_doc(array $r): array {
    $d = jdecode($r['data']) ?? new stdClass();
    return [
        'id' => $r['id'], 'date' => $r['plan_date'], 'shift' => $r['shift'],
        'controllers' => $d->controllers ?? [], 'assignments' => $d->assignments ?? new stdClass(),
        'updatedBy' => $r['updated_by'], 'updatedAt' => iso($r['updated_at']),
    ];
}

function valid_date(string $d): bool { return (bool) preg_match('/^\d{4}-\d{2}-\d{2}$/', $d); }

function h_plans_list(): never {
    require_role('admin', 'controller');
    $date = $_GET['date'] ?? null;
    if ($date !== null && !valid_date((string) $date)) fail(400, 'Date invalide.');
    $rows = $date ? q('SELECT * FROM shift_plans WHERE plan_date = ?', [$date])->fetchAll() : q('SELECT * FROM shift_plans')->fetchAll();
    json_out(array_map('plan_doc', $rows));
}

function h_plans_save(): never {
    $u = require_role('admin');
    $b = body();
    $date = (string) ($b->date ?? ''); $shift = (string) ($b->shift ?? '');
    if (!valid_date($date) || !in_array($shift, SHIFT_KEYS, true)) fail(400, 'Date ou shift invalide.');
    $controllers = $b->controllers ?? [];
    $assignments = $b->assignments ?? new stdClass();
    if (!is_array($controllers) || !($assignments instanceof stdClass)) fail(400, 'Répartition invalide.');
    $id = "{$date}_{$shift}";
    $data = jencode(['controllers' => $controllers, 'assignments' => $assignments]);
    $by = $u['email']; $now = now_db();
    tx(function () use ($id, $date, $shift, $data, $by, $now) {
        if (q('SELECT 1 FROM shift_plans WHERE id = ?', [$id])->fetch())
            q('UPDATE shift_plans SET data = ?, updated_by = ?, updated_at = ? WHERE id = ?', [$data, $by, $now, $id]);
        else
            q('INSERT INTO shift_plans (id, plan_date, shift, data, updated_by, updated_at) VALUES (?,?,?,?,?,?)', [$id, $date, $shift, $data, $by, $now]);
    });
    json_out(plan_doc(q('SELECT * FROM shift_plans WHERE id = ?', [$id])->fetch()));
}

function h_plans_delete(): never {
    require_role('admin');
    $id = (string) ($_GET['id'] ?? '');
    if (!preg_match('/^\d{4}-\d{2}-\d{2}_(morning|afternoon|night)$/', $id)) fail(400, 'Identifiant invalide.');
    q('DELETE FROM shift_plans WHERE id = ?', [$id]); // idempotent, like Firestore's deleteDoc
    json_out(['ok' => true]);
}

function planning_doc(array $r): array {
    $d = jdecode($r['data']) ?? new stdClass();
    $out = (array) $d;
    $out['date'] = $r['plan_date'];
    $out['source'] = $r['source'];
    $out['uploadedBy'] = $r['uploaded_by'];
    $out['uploadedAt'] = iso($r['uploaded_at']);
    return $out;
}

function h_planning_list(): never {
    require_role('admin', 'controller');
    if (isset($_GET['dates'])) {
        $dates = array_values(array_filter(explode(',', (string) $_GET['dates']), 'valid_date'));
        if (!$dates || count($dates) > 62) json_out([]);
        $in = implode(',', array_fill(0, count($dates), '?'));
        $rows = q("SELECT * FROM planning WHERE plan_date IN ($in)", $dates)->fetchAll();
    } else {
        $rows = q('SELECT * FROM planning ORDER BY plan_date')->fetchAll();
    }
    json_out(array_map('planning_doc', $rows));
}

function h_planning_save(): never {
    $u = require_role('admin');
    $b = body();
    $days = $b->days ?? null;
    if (!is_array($days) || count($days) > 400) fail(400, 'Planning invalide.');
    $source = mb_substr((string) ($b->source ?? ''), 0, 255);
    $now = now_db();
    $n = tx(function () use ($days, $source, $u, $now) {
        $n = 0;
        foreach ($days as $d) {
            if (!($d instanceof stdClass) || !valid_date((string) ($d->date ?? ''))) continue;
            $date = (string) $d->date;
            $payload = new stdClass();
            foreach (['morning', 'afternoon', 'night', 'off'] as $k) {
                $v = $d->$k ?? [];
                $payload->$k = is_array($v) ? array_values(array_map('strval', $v)) : [];
            }
            $json = jencode($payload);
            if (q('SELECT 1 FROM planning WHERE plan_date = ?', [$date])->fetch())
                q('UPDATE planning SET data = ?, source = ?, uploaded_by = ?, uploaded_at = ? WHERE plan_date = ?', [$json, $source, $u['email'], $now, $date]);
            else
                q('INSERT INTO planning (plan_date, data, source, uploaded_by, uploaded_at) VALUES (?,?,?,?,?)', [$date, $json, $source, $u['email'], $now]);
            $n++;
        }
        return $n;
    });
    json_out(['saved' => $n]);
}

// ---------------------------------------------------------------- PDF stores: "Plan de chargement" + "Fiche technique"
// Two identical stores of admin-uploaded PDFs, each keyed by a code:
//   loading_plans  keyed by aircraft family code (788, 73H, 7M8, E90, AT7…)      -> « Plan de chargement »
//   tech_sheets    keyed by code prestation (DC25, BC55, CF99, DC99…)            -> « Fiche technique »
// The server only stores/serves PDFs by their exact code; matching a flight to a code is done client-side.

const PLAN_TYPE_RE = '/^[A-Z0-9]{1,16}$/';
const MAX_PLAN_BYTES = 8 * 1024 * 1024; // 8 MB per PDF (raw, before base64) — keep JSON POSTs within shared-hosting limits
const PDF_TABLES = ['loading_plans', 'tech_sheets']; // whitelist: the table name is interpolated into SQL

/** Creates the table on databases installed before the feature existed (the installer only runs once,
 *  so an upgraded site would otherwise 500 on every call). */
function ensure_pdf_table(string $table): void {
    static $done = [];
    if (!in_array($table, PDF_TABLES, true)) fail(500, 'Table inconnue.');
    if (isset($done[$table])) return;
    if (is_mysql()) {
        db()->exec("CREATE TABLE IF NOT EXISTS $table (
            type         VARCHAR(16) NOT NULL PRIMARY KEY,
            file_name    VARCHAR(255) NOT NULL,
            mime         VARCHAR(100) NOT NULL DEFAULT 'application/pdf',
            size_bytes   INT UNSIGNED NOT NULL,
            data         LONGBLOB NOT NULL,
            uploaded_by  VARCHAR(190) NOT NULL DEFAULT '',
            uploaded_at  DATETIME NOT NULL
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci");
    } else {
        db()->exec("CREATE TABLE IF NOT EXISTS $table (
            type         TEXT NOT NULL PRIMARY KEY,
            file_name    TEXT NOT NULL,
            mime         TEXT NOT NULL DEFAULT 'application/pdf',
            size_bytes   INTEGER NOT NULL,
            data         BLOB NOT NULL,
            uploaded_by  TEXT NOT NULL DEFAULT '',
            uploaded_at  TEXT NOT NULL
        )");
    }
    $done[$table] = true;
}

/** Metadata only (no PDF bytes), for the client's own matching against a flight. */
function pdf_list(string $table): never {
    require_role('admin', 'controller');
    ensure_pdf_table($table);
    $rows = q("SELECT type, file_name, mime, size_bytes, uploaded_by, uploaded_at FROM $table ORDER BY type")->fetchAll();
    json_out(array_values(array_map(static fn($r) => [
        'type' => $r['type'], 'fileName' => $r['file_name'], 'mime' => $r['mime'],
        'sizeBytes' => (int) $r['size_bytes'], 'uploadedBy' => $r['uploaded_by'], 'uploadedAt' => iso($r['uploaded_at']),
    ], $rows)));
}

/** Upload (or replace) one PDF. `type` is the code the admin named the file after (e.g. "788.pdf" -> "788"). */
function pdf_upload(string $table): never {
    $u = require_role('admin');
    ensure_pdf_table($table);
    $b = body();
    $type = strtoupper(trim((string) ($b->type ?? '')));
    if (!preg_match(PLAN_TYPE_RE, $type)) fail(400, 'Code invalide (lettres/chiffres, 1 à 16 caractères, ex. 788, DC25, BC55).');
    $fileName = mb_substr((string) ($b->fileName ?? "$type.pdf"), 0, 255);
    $b64 = (string) ($b->dataBase64 ?? '');
    if ($b64 === '') fail(400, 'Fichier manquant.');
    $bytes = base64_decode($b64, true);
    if ($bytes === false || $bytes === '') fail(400, 'Fichier illisible.');
    if (strlen($bytes) > MAX_PLAN_BYTES) fail(413, 'Fichier trop volumineux (max ' . (MAX_PLAN_BYTES / 1024 / 1024) . ' Mo).');
    if (substr($bytes, 0, 4) !== '%PDF') fail(400, 'Le fichier doit être un PDF.');
    $mime = 'application/pdf';
    $size = strlen($bytes);
    $by = $u['name'] ?: $u['email'];
    $now = now_db();

    if (q("SELECT 1 FROM $table WHERE type = ?", [$type])->fetch()) {
        q("UPDATE $table SET file_name = ?, mime = ?, size_bytes = ?, data = ?, uploaded_by = ?, uploaded_at = ? WHERE type = ?",
          [$fileName, $mime, $size, $bytes, $by, $now, $type]);
    } else {
        q("INSERT INTO $table (type, file_name, mime, size_bytes, data, uploaded_by, uploaded_at) VALUES (?,?,?,?,?,?,?)",
          [$type, $fileName, $mime, $size, $bytes, $by, $now]);
    }
    json_out(['type' => $type, 'fileName' => $fileName, 'sizeBytes' => $size, 'uploadedBy' => $by, 'uploadedAt' => iso($now)], 201);
}

function pdf_delete(string $table): never {
    require_role('admin');
    ensure_pdf_table($table);
    $type = strtoupper(trim((string) ($_GET['type'] ?? '')));
    if (!preg_match(PLAN_TYPE_RE, $type)) fail(400, 'Code invalide.');
    q("DELETE FROM $table WHERE type = ?", [$type]);
    json_out(['deleted' => true]);
}

/** The PDF itself, by its exact code. */
function pdf_get(string $table, string $what): never {
    require_role('admin', 'controller');
    ensure_pdf_table($table);
    $type = strtoupper(trim((string) ($_GET['type'] ?? '')));
    if (!preg_match(PLAN_TYPE_RE, $type)) fail(400, 'Code invalide.');
    $row = q("SELECT file_name, mime, data FROM $table WHERE type = ?", [$type])->fetch();
    if (!$row) fail(404, "Aucun(e) $what pour $type.");
    binary_out((string) $row['data'], (string) $row['mime'], (string) $row['file_name']);
}

// ---------------------------------------------------------------- router
try {
    require_ajax_header();
    $route = trim((string) ($_GET['route'] ?? ''), '/');
    $seg = $route === '' ? [] : explode('/', $route);
    $key = $_SERVER['REQUEST_METHOD'] . ' ' . ($seg[0] ?? '') . (isset($seg[1]) ? '/' . $seg[1] : '');

    switch (true) {
        case $key === 'POST auth/login':            h_login();
        case $key === 'POST auth/logout':           h_logout();
        case $key === 'GET auth/me':                h_me();
        case $key === 'GET auth/diag':              h_diag();
        case $key === 'PATCH auth/profile':         h_profile_update();
        case $key === 'POST auth/password':         h_password_change();
        case $key === 'GET users':                  h_users_list();
        case $key === 'POST users':                 h_users_create();
        case str_starts_with($key, 'PATCH users/') && isset($seg[1]): h_users_update($seg[1]);
        case str_starts_with($key, 'DELETE users/') && isset($seg[1]): h_users_delete($seg[1]);
        case $key === 'GET flights':                h_flights_list();
        case $key === 'GET flight':                 h_flight_get();
        case $key === 'DELETE flight':              h_flight_delete();
        case $key === 'PATCH flight':               h_flight_admin_update();
        case $key === 'POST flight':                h_flight_create();
        case $key === 'PATCH flight/controller':    h_flight_controller_update();
        case $key === 'POST recaps':                h_recap_upload();
        case $key === 'GET recaps':                 h_recaps_list();
        case $key === 'GET audit-logs':             h_audit_list();
        case $key === 'GET shift-plans':            h_plans_list();
        case $key === 'PUT shift-plans':            h_plans_save();
        case $key === 'DELETE shift-plans':         h_plans_delete();
        case $key === 'GET planning':               h_planning_list();
        case $key === 'PUT planning':               h_planning_save();
        case $key === 'GET loading-plans':          pdf_list('loading_plans');
        case $key === 'POST loading-plans':         pdf_upload('loading_plans');
        case $key === 'DELETE loading-plans':       pdf_delete('loading_plans');
        case $key === 'GET loading-plan':           pdf_get('loading_plans', 'plan de chargement');
        case $key === 'GET tech-sheets':            pdf_list('tech_sheets');
        case $key === 'POST tech-sheets':           pdf_upload('tech_sheets');
        case $key === 'DELETE tech-sheets':         pdf_delete('tech_sheets');
        case $key === 'GET tech-sheet':             pdf_get('tech_sheets', 'fiche technique');
        default: fail(404, 'Route introuvable.');
    }
} catch (HttpError $e) {
    json_out(['error' => $e->getMessage()], $e->status);
} catch (Throwable $e) {
    error_log('[checklist] ' . $e::class . ': ' . $e->getMessage() . ' @ ' . $e->getFile() . ':' . $e->getLine());
    json_out(['error' => 'Erreur interne du serveur.'], 500);
}
