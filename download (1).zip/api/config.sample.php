<?php
// Copy this file to config.php and fill in your database credentials.
// (config.php is blocked from direct web access by api/.htaccess.)
return [
    'db_dsn'  => 'mysql:host=YOUR_DB_HOST;dbname=YOUR_DB_NAME;charset=utf8mb4',
    'db_user' => 'YOUR_DB_USER',
    'db_pass' => 'YOUR_DB_PASSWORD',

    'session_name'          => 'checklist_sid',
    'remember_days'         => 30,
    'session_idle_hours'    => 12,
    'cookie_secure'         => 'auto',
    'timezone'              => 'UTC',
];
