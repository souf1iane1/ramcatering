<?php
declare(strict_types=1);

/**
 * Shared plumbing: config, PDO, database-backed sessions, JSON helpers, auth guards.
 */

// ---------------------------------------------------------------- config
$CONFIG = (static function (): array {
    $file = __DIR__ . '/config.php';
    $cfg = is_file($file) ? require $file : [];
    // Environment overrides (handy for tests / containers).
    $env = [
        'db_dsn' => 'CL_DB_DSN', 'db_user' => 'CL_DB_USER', 'db_pass' => 'CL_DB_PASS',
    ];
    foreach ($env as $k => $name) {
        $v = getenv($name);
        if ($v !== false && $v !== '') $cfg[$k] = $v;
    }
    return $cfg + [
        'db_dsn' => '', 'db_user' => '', 'db_pass' => '',
        'session_name' => 'checklist_sid', 'remember_days' => 30, 'session_idle_hours' => 12,
        'cookie_secure' => 'auto', 'timezone' => 'UTC',
    ];
})();

date_default_timezone_set('UTC'); // everything stored/returned in UTC
mb_internal_encoding('UTF-8');

function cfg(string $key) { global $CONFIG; return $CONFIG[$key] ?? null; }

// ---------------------------------------------------------------- output helpers
class HttpError extends RuntimeException {
    public function __construct(public int $status, string $message) { parent::__construct($message); }
}

function fail(int $status, string $message): never { throw new HttpError($status, $message); }

function json_out($data, int $status = 200): never {
    http_response_code($status);
    header('Content-Type: application/json; charset=utf-8');
    // Some hosts/CDNs (LiteSpeed Cache, Cloudflare, ...) cache GETs by URL and ignore cookies:
    // that would serve one user's "not signed in" answer to everyone. Forbid it everywhere.
    header('Cache-Control: no-store, no-cache, must-revalidate, max-age=0, private');
    header('Pragma: no-cache');
    header('Expires: 0');
    header('Vary: Cookie');
    header('X-LiteSpeed-Cache-Control: no-cache');
    echo json_encode($data, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES | JSON_PRESERVE_ZERO_FRACTION | JSON_INVALID_UTF8_SUBSTITUTE);
    exit;
}

/** Raw binary response (a PDF, for « Plan de chargement »), instead of json_out's JSON envelope.
 *  Same no-cache headers as json_out (private data must never be cached by a shared host/CDN). */
function binary_out(string $bytes, string $mime, string $fileName): never {
    http_response_code(200);
    header('Content-Type: ' . $mime);
    header('Content-Length: ' . strlen($bytes));
    header('Content-Disposition: inline; filename="' . str_replace('"', '', $fileName) . '"');
    header('Cache-Control: no-store, no-cache, must-revalidate, max-age=0, private');
    header('Pragma: no-cache');
    header('Expires: 0');
    header('Vary: Cookie');
    header('X-LiteSpeed-Cache-Control: no-cache');
    header('X-Content-Type-Options: nosniff');
    echo $bytes;
    exit;
}

/** Parsed JSON request body as stdClass (so {} stays an object when stored back). */
function body(): stdClass {
    static $cached = null;
    if ($cached !== null) return $cached;
    $raw = file_get_contents('php://input');
    if ($raw === '' || $raw === false) return $cached = new stdClass();
    $data = json_decode($raw, false);
    if (!($data instanceof stdClass)) fail(400, 'Corps de requête JSON invalide.');
    return $cached = $data;
}

/** Timestamps: stored as UTC "Y-m-d H:i:s", returned as ISO-8601 with a Z. */
function now_db(): string { return gmdate('Y-m-d H:i:s'); }
function iso(?string $dbTime): ?string {
    if ($dbTime === null || $dbTime === '') return null;
    return str_replace(' ', 'T', $dbTime) . 'Z';
}

function jdecode(?string $json) {
    if ($json === null || $json === '') return null;
    return json_decode($json, false);
}
function jencode($v): string {
    return json_encode($v, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES | JSON_PRESERVE_ZERO_FRACTION);
}

// ---------------------------------------------------------------- database
function db(): PDO {
    static $pdo = null;
    if ($pdo) return $pdo;
    $dsn = (string) cfg('db_dsn');
    if ($dsn === '') fail(500, "Base de données non configurée (api/config.php).");
    try {
        $pdo = new PDO($dsn, (string) cfg('db_user'), (string) cfg('db_pass'), [
            PDO::ATTR_ERRMODE            => PDO::ERRMODE_EXCEPTION,
            PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
            PDO::ATTR_EMULATE_PREPARES   => false,
        ]);
    } catch (PDOException $e) {
        error_log('[checklist] DB connect failed: ' . $e->getMessage());
        fail(500, 'Connexion à la base de données impossible.');
    }
    return $pdo;
}

function is_mysql(): bool { return db()->getAttribute(PDO::ATTR_DRIVER_NAME) === 'mysql'; }

function q(string $sql, array $params = []): PDOStatement {
    $st = db()->prepare($sql);
    $st->execute($params);
    return $st;
}

/** Runs $fn inside a transaction; rolls back on any exception. */
function tx(callable $fn) {
    $pdo = db();
    $pdo->beginTransaction();
    try {
        $r = $fn();
        $pdo->commit();
        return $r;
    } catch (Throwable $e) {
        if ($pdo->inTransaction()) $pdo->rollBack();
        throw $e;
    }
}

// ---------------------------------------------------------------- sessions
// Own implementation (does NOT use PHP's session_*): one row per login in the `sessions` table,
// identified by a random 64-hex id sent as an HttpOnly cookie. If the browser refuses cookies,
// the same id can be sent in the `X-Auth-Token` header instead (the login page falls back to it).

const API_VERSION = '4';

function is_https(): bool {
    if (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off') return true;
    if (($_SERVER['SERVER_PORT'] ?? '') === '443') return true;
    if (strtolower((string) ($_SERVER['HTTP_X_FORWARDED_PROTO'] ?? '')) === 'https') return true;
    if (strtolower((string) ($_SERVER['HTTP_X_FORWARDED_SSL'] ?? '')) === 'on') return true;
    if (str_contains((string) ($_SERVER['HTTP_CF_VISITOR'] ?? ''), 'https')) return true;
    return false;
}

function cookie_secure(): bool {
    return cfg('cookie_secure') === 'auto' ? is_https() : (bool) cfg('cookie_secure');
}

function session_cookie_options(int $expires): array {
    return ['expires' => $expires, 'path' => '/', 'secure' => cookie_secure(), 'httponly' => true, 'samesite' => 'Lax'];
}

function session_ttl(bool $remember): int {
    return $remember ? (int) cfg('remember_days') * 86400 : (int) cfg('session_idle_hours') * 3600;
}

/** Creates a session row and sets the cookie. Returns the session id (also usable as X-Auth-Token). */
function create_session(int $uid, bool $remember): string {
    if (random_int(1, 50) === 1) { // opportunistic cleanup
        q('DELETE FROM sessions WHERE last_activity < ?', [time() - (int) cfg('remember_days') * 86400]);
    }
    $sid = bin2hex(random_bytes(32));
    q('INSERT INTO sessions (id, data, last_activity) VALUES (?, ?, ?)',
      [$sid, json_encode(['uid' => $uid, 'remember' => $remember]), time()]);
    setcookie((string) cfg('session_name'), $sid, session_cookie_options($remember ? time() + session_ttl(true) : 0));
    return $sid;
}

function clear_session_cookie(): void {
    setcookie((string) cfg('session_name'), '', session_cookie_options(1));
}

/** Session ids offered by this request: cookie first, then the X-Auth-Token header. */
function offered_session_ids(): array {
    $out = [];
    foreach ([$_COOKIE[(string) cfg('session_name')] ?? null, $_SERVER['HTTP_X_AUTH_TOKEN'] ?? null] as $v) {
        if (is_string($v) && preg_match('/^[a-f0-9]{64}$/', $v) && !in_array($v, $out, true)) $out[] = $v;
    }
    return $out;
}

/** The "owner" is the first administrator (the account install.php creates): the admin with the lowest id.
 *  No other admin can edit, demote, deactivate or delete it. */
function owner_id(): int {
    static $id = null;
    if ($id === null) $id = (int) q("SELECT MIN(id) FROM users WHERE role = 'admin'")->fetchColumn();
    return $id;
}

function profile_of(array $u): array {
    return [
        'uid' => (string) $u['id'], 'id' => (string) $u['id'],
        'name' => $u['name'], 'email' => $u['email'], 'role' => $u['role'],
        'active' => (bool) $u['active'], 'createdAt' => iso($u['created_at'] ?? null),
        'isOwner' => (int) $u['id'] === owner_id(),
    ];
}

/** Resolves the signed-in user for this request: ['user' => row, 'sid' => string, 'remember' => bool] or null.
 *  The user row is read fresh, so role changes / deactivation apply immediately. */
function auth_state(): ?array {
    static $state = false;
    if ($state !== false) return $state;
    foreach (offered_session_ids() as $sid) {
        $row = q('SELECT * FROM sessions WHERE id = ?', [$sid])->fetch();
        if (!$row) continue;
        $data = json_decode((string) $row['data'], true);
        $uid = is_array($data) ? (int) ($data['uid'] ?? 0) : 0;
        $remember = !empty($data['remember']);
        if (!$uid || time() - (int) $row['last_activity'] > session_ttl($remember)) {
            q('DELETE FROM sessions WHERE id = ?', [$sid]);
            continue;
        }
        $user = q('SELECT * FROM users WHERE id = ?', [$uid])->fetch();
        if (!$user || !(int) $user['active']) { q('DELETE FROM sessions WHERE id = ?', [$sid]); continue; }
        if (time() - (int) $row['last_activity'] > 60) { // sliding expiry, written at most once a minute
            q('UPDATE sessions SET last_activity = ? WHERE id = ?', [time(), $sid]);
        }
        return $state = ['user' => $user, 'sid' => $sid, 'remember' => $remember];
    }
    return $state = null;
}

function current_user(): ?array { return auth_state()['user'] ?? null; }

/** Signs a user out everywhere (used on password change/reset). */
function delete_sessions_of_user(int $uid): void {
    q('DELETE FROM sessions WHERE data LIKE ?', ['{"uid":' . $uid . ',%']);
}

function require_login(): array {
    $u = current_user();
    if (!$u) fail(401, 'Non connecté.');
    return $u;
}

/** Mirrors the old Firestore rules: only known roles may read, and writes are role-gated. */
function require_role(string ...$roles): array {
    $u = require_login();
    if (!in_array($u['role'], $roles, true)) fail(403, 'Accès refusé.');
    return $u;
}

/** CSRF defence for state-changing calls: cross-site pages cannot add this header without a CORS preflight. */
function require_ajax_header(): void {
    if (in_array($_SERVER['REQUEST_METHOD'], ['GET', 'HEAD', 'OPTIONS'], true)) return;
    if (($_SERVER['HTTP_X_REQUESTED_WITH'] ?? '') !== 'fetch') fail(403, 'Requête non autorisée.');
}
