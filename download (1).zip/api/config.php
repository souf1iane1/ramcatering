<?php
// Copy this file to config.php and fill in your database credentials.
// (config.php is blocked from direct web access by api/.htaccess.)
return [
    'db_dsn'  => 'mysql:host=sql308.infinityfree.com;dbname=if0_42902069_prestasion;charset=utf8mb4',
    'db_user' => 'if0_42902069',
    'db_pass' => 'lokk2dShKx',

    // Session cookie name and how long "Remember me" keeps a user signed in.
    'session_name'          => 'checklist_sid',
    'remember_days'         => 30,
    // Without "Remember me": the login is dropped after this many hours of inactivity
    // (and when the browser is closed).
    'session_idle_hours'    => 12,

    // Set true when the site is served over HTTPS (strongly recommended).
    // 'auto' = secure cookie only when the request itself is HTTPS.
    'cookie_secure'         => 'auto',

    'timezone'              => 'UTC',   // timestamps are stored in UTC; the browser shows local time
];
